IgeUi = new IgeClass({
	
	init: function (engine) {
		this._className = 'IgeUi';
		
		this.engine = engine;
	},
	
	//////////////////
	/* MENU METHODS */
	//////////////////

	
});