var config = {
	moduleName: 'IgeSound',
	serverSide: false,
	clientSide: true,
}