var config = {
	moduleName: 'IgeFacebook',
	serverSide: true,
	clientSide: true,
}