var config = {
	moduleName: 'IgePhysics',
	serverSide: true,
	clientSide: true,
}