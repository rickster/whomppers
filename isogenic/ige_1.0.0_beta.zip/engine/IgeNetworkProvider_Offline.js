/** IgeNetworkProvider_Offline - The offline network provider.
Allows a game to define a network provider that will not do any
network connection or transfer operations. Useful for making
single-player or offline games. {
	category:"class",
} **/
IgeNetworkProvider_Offline = new IgeClass({
	/** networkProvider - The name of this network provider. {
		category:"property",
		type:"string",
	} **/
	networkProvider: 'offline',
	
	/** setOptions - Sets the options for the network provider. {
		category:"method",
		arguments:[{
			name:"obj",
			type:"object",
			desc:"The options that you want to set for the provider.",
		}],
	} **/
	setOptions: function (obj) {},
	
	/** providerInit - Initialises the provider by loading its
	required libraries etc. {
		category:"method",
	} **/
	providerInit: function () {
		this.log('Network provider "offline" is ready!');
		this.emit('networkProviderReady');
	},
	
	/** _start - Called by IgeNetwork's start() method to ask
	the provider to start up. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"The callback method to call once the provider has started up successfully.",
		}],
	} **/
	_start: function (callback) {
		this._state = 1;
		this.emit('networkProviderUp');
		this.emit('serverConnect');
	},
	
	/** _stop - Called by IgeNetwork's stop() method to ask
	the provider to shut down. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"The callback method to call once the provider has shut down successfully.",
		}],
	} **/
	_stop: function () {
		this._state = 0;
	},
	
	/** send - The provder send method that will send data over
	the network. {
		category:"method",
		arguments:[{
			name:"command",
			type:"string",
			desc:"The command string of the command to send.",
		}, {
			name:"sendData",
			type:"object",
			desc:"The data object to send along with the command. Can be null.",
		}, {
			name:"socketId",
			type:"multi",
			desc:"The id of the socket to target the message at. If none is provided, the message will be sent to all connected clients (server only).",
		}, {
			name:"debug",
			type:"string",
			desc:"When set to the name of the command, will output debug messages as the send command is executed.",
		}],
	} **/
	send: function (command, sendData, socketId, debug) {
		if (sendData && sendData.$local != null) {
			var strippedData = this.engine.stripLocal(sendData);
		} else {
			sendData = sendData || {};
			var strippedData = sendData;
		}
		
		var cmdId = this._commandList[command];
		if (debug) { this.log('Send: Command ID is: ' + cmdId); }
		if (cmdId != null) {
			// Create and encode a new data packet
			this.emit(command, strippedData);
		}
	},
});

// Register this provider with the network class
IgeNetwork.prototype.io = IgeNetwork.prototype.io || [];
IgeNetwork.prototype.io.offline = {};
IgeNetwork.prototype.io.offline.classMethod = IgeNetworkProvider_Offline;