/** IgeEnum - Takes an array of strings and creates an array with the
string value as the key and the value as an auto-incremented integer. {
	category:"class",
	examples:[{
		name:"Create a New Enum",
		desc:"Creates a new enum with a bunch of initial key-value pairs.",
		code:"<pre>
			var newEnum = new IgeEnum([
				'police',
				'fire',
				'ambulance',
				'army'
			]);
			
			console.log(newEnum.ambulance); // Outputs 2
		</pre>",
	}, {
		name:"Read Enum Key By Value",
		desc:"Returns a key name from a given value.",
		code:"<pre>
			var newEnum = new IgeEnum([
				'police',
				'fire',
				'ambulance',
				'army'
			]);
			
			console.log(newEnum.ambulance); // Outputs 2
			console.log(newEnum.keyFromValue(2)); // Outputs 'ambulance'
		</pre>",
	}],
} **/
IgeEnum = new IgeClass({
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"array",
			name:"vals",
			desc:"An array of string values to create the enum from.",
		},
	} **/
	init: function (vals) {
		this._className = 'IgeEnum';
		
		if (vals == null) { vals = []; }
		var id = null;
		var tempEn = [];
		var enumVar = this;
		enumVar._reverse = [];
		
		var startPoint = 0;
		var endPoint = vals.length;
		
		for (v = startPoint; v < endPoint; v++) {
			if (vals[v]) {
				tempEn.push(v);
				id = (tempEn.length - 1);
				enumVar[vals[v]] = id;
				enumVar._reverse[id] = vals[v];
			}
		}
		
		enumVar._lastIndex = id;
		enumVar._vals = vals;
		
		return enumVar;
	},
	
	/** add - Adds new values to an existing Enum. {
		category:"method",
		engine_ver:"0.0.5",
		arguments: [{
			type:"array",
			name:"vals",
			desc:"An array of string values to add to the enum.",
		}],
	} **/	
	add: function (vals) {
		var currentEnum = this;
		
		// Loop the new values to add to the enum
		for (var val = 0; val < vals.length; val++) {
			// Check that the current value does not already exist
			if (currentEnum._vals.indexOf(vals[val]) == -1) {
				// The value doesn't already exist so add it
				currentEnum._vals.push(vals[val]);
			}
		}
		
		// Read the final de-duped list of values
		vals = currentEnum._vals;
		
		// Create a new blank enum object with the
		// final values
		var newEnum = new IgeEnum(vals);
		
		// Copy the new enum data to the current enum data
		for (var thing in newEnum) {
			currentEnum[thing] = newEnum[thing];
		}
	},
	
	/** keyFromValue - Returns the key that maps to the given value. {
		category:"method",
		return: {
			type:"string",
			desc:"Returns the key that the given value maps to or -1 if the key is not found.",
		},
		arguments: [{
			type:"integer",
			name:"val",
			desc:"The value to return the key name for.",
		}],
	} **/
	keyFromValue: function (val) {
		return this._vals[val] || -1;
	},
});