/** IgeBootstrap - Loads script files into memory maintaining the
original load order. {
	category:"class",
} **/
IgeBootstrap = function (callback, supressDefault) {
	this.onComplete = callback;
	this.serverFiles = null;
	this.clientFiles = null;
	this.busy = false;
	
	if (!supressDefault) {
		
		if (typeof module !== 'undefined' && module.exports) {
			this.mode = 0;
		} else if (window) {
			// Make sure that we don't cause issues trying to use the console on crappy browsers
			if (window != null && !window.console) {
				window.console = {
					log: function () {}
				};
			}
			this.mode = 1;
		} else {
			throw('Bootstrap error, cannot detect environment!');
		}
	}
};

/** init - The constructor for this class. {
	category:"method",
	argument: {
		type:"array",
		name:"fileList",
		desc:"The array of script file paths to load into memory.",
	},
} **/
IgeBootstrap.prototype.init = function (fileList) {
	if (this.mode == 0) {
		this.serverFiles = fileList;
		for (var i in this.serverFiles) { this.require(this.serverFiles[i]); }
	}
	
	if (this.mode == 1) {
		this.clientFiles = fileList;
		for (var i in this.clientFiles) { this.require(this.clientFiles[i]); }
	}	
}

/** require - Tells the bootstrap process to require loading
a script file. {
	category:"method",
	arguments: [{
		type:"string",
		name:"file",
		desc:"The script file path.",
	}, {
		type:"string",
		name:"varName",
		desc:"The name of the variable to assign the contents of the script evaluation to. Node.js only. Leave null on browsers.",
	}, {
		type:"function",
		name:"callback",
		desc:"The function to call when the required script has loaded successfully.",
	}],
} **/
IgeBootstrap.prototype.require = function (file, varName, callback) {
	
	// Check that we were passed a filename
	if (file) {
		// Check the load queues exist
		this.queue = this.queue || [];
		this.done = this.done || [];
		this.doneCount = 0;
		
		// Add the script file to the load queue
		this.queue.push([file, varName, callback]);
		//this.log('IGE *info* [IgeBootstrap] : Added to queue: ' + file);
	}	
	
}

/** process - Starts processing the list of required scripts. {
	category:"method",
} **/
IgeBootstrap.prototype.process = function () {
	
	if (!this.busy) {
		
		this.busy = true;
		
		if (this.queue.length) {
			
			this.loadFile(this.queue.shift());
			
		} else {
			
			// Set busy to false
			this.busy = false;
			
			// Loading files is complete so fire the complete function
			if (typeof this.onComplete == 'function') {
				if (this.mode == 0) {
					// Server
					this.onComplete.call();
				}
				
				if (this.mode == 1) {
					this.onComplete.apply(window);
				}
				
				// Clear the onComplete callback because we've called it
				this.onComplete = null;
			}
			
		}
		
	} else {
		this.log('IGE *info* [IgeBootstrap] : Queue busy');
	}
	
}

/** loadFile - Loads a script file into memory. {
	category:"method",
	arguments: [{
		type:"object",
		name:"fileData",
		desc:"The object containing the script file data that was defined earlier in a call to require().",
	}],
} **/
IgeBootstrap.prototype.loadFile = function (fileData) {
	
	var file = fileData[0];
	var varName = fileData[1];
	var callback = fileData[2];
	
	// Check if we have already included this file in the DOM
	if (this.done[file]) {
		this.log('IGE *info* [IgeBootstrap] : Already loaded file ' + file);
		if (this.mode == 0) {
			this.busy = false;
			this.process();
		}
		if (this.mode == 1) {
			window.igeBootstrap.busy = false;
			window.igeBootstrap.process();
		}
		return;
	}
	
	this.log('IGE *info* [IgeBootstrap] : Loading file ' + file);
	this.doneCount++;
	
	if (this.mode == 0) {
		// Server - check if the path is relative, if so, prepend the cwd
		if (file.substr(0, 2) == './' || file.substr(0, 3) == '../') { file = process.cwd() + '/' + file; } 
		
		if (varName) {
			eval(varName + ' = require("' + file + '");');
			this.log('IGE *info* [IgeBootstrap] : File loaded: ' + file);
			if (typeof callback == 'function') { callback.apply(this, fileData); }
		} else {
			require(file); // Node.js require call
			this.log('IGE *info* [IgeBootstrap] : File loaded: ' + file);
		}
		
		this.busy = false;
		this.process();
	}
	
	if (this.mode == 1) {
		// Client
		var tempScript = document.createElement('script');
		tempScript.onload = this.bind(function () {
			this.log('IGE *info* [IgeBootstrap] : File loaded: ' + file);
			// Set busy to false
			window.igeBootstrap.busy = false;
			// Call the callback to inform it that the file has loaded
			if (typeof callback == 'function') { callback.apply(this, [fileData]); }
			// Execute the process method to process the next in queue
			window.igeBootstrap.process();
		});
		
		tempScript.id = 'IgeBootstrap_' + this.doneCount + new Date().getTime();
		tempScript.type = 'text/javascript';
		tempScript.src = file + '.js';
		
		document.getElementsByTagName("head")[0].appendChild(tempScript);
	}
	
	this.done[file] = true;
	
}

/** bind - Binds a method call to the current context. {
	category:"method",
	arguments: [{
		type:"function",
		name:"Method",
		desc:"The function to bind to the current context.",
	}],
} **/
IgeBootstrap.prototype.bind = function( Method ) {
	
	if (typeof Method == 'function') {
		var _this = this;
		return(
			function(){
				return( Method.apply( _this, arguments ) );
			}
		);
	} else {
		this.log('IGE *info* [IgeBootstrap] : An attempt to use bind against a method that does not exist was made!');
		return (function () { });
	}
	
}

/** log - Logs debug messages to the console. {
	category:"method",
	arguments: [{
		type:"string",
		name:"msg",
		desc:"The message to log to the console.",
	}],
} **/
IgeBootstrap.prototype.log = function (msg) {
	var dtObj = new Date();
	var dt = '[' + dtObj.toDateString() + ' ' + dtObj.toTimeString().substr(0,8) + '] ';
	
	msg = dt + msg;
	
	// Server code
	if (this.mode == 0) {
		console.log(msg);
	}
	
	// Client code
	if (this.mode == 1) {
		if (window.igeDebug) {
			if (console != null && console.log != null) {
				console.log(msg);
			}
		}
	}
}

/** safeCall - Calls a method if it exists and avoids an exception if
it does not. {
	category:"method",
	arguments: [{
		type:"object",
		name:"obj",
		desc:"The object that might contain the method to call.",
	}, {
		type:"string",
		name:"methodName",
		desc:"The method name to test for and call if exists.",
	}, {
		type:"array",
		name:"args",
		desc:"The arguments to pass to the method if it is called.",
	}],
} **/
safeCall = function (obj, methodName, args) {
	if (obj && typeof obj[methodName] == 'function') {
		obj[methodName].apply(obj, args || []);
		return true;
	} else {
		// No method
		//this.log('Cannot call method "' + methodName + '" of passed object (object output above).', 'warning', obj);
		return false;
	}
}

// Define console if it does not already exist
if (typeof(console) == 'undefined') {
	var emptyFunc = function () {}
	console = {};
	
	console.log = emptyFunc;
	console.info = emptyFunc;
	console.warn = emptyFunc;
	console.error = emptyFunc;
	
	if (typeof(window) != 'undefined' && typeof(window.console) == 'undefined') { window.console = console; }
}

// Define some basic engine variables as null
IgeCollection = null;
IgeNetworkItem = null;

console.log('-----------------------------------------------------');
console.log('Isogenic Game Engine - http://www.isogenicengine.com');
console.log('(C)opyright 2012 Irrelon Software Limited');
console.log('-----------------------------------------------------');