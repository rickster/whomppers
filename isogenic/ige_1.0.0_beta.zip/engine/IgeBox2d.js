/** IgeBox2d - Box2D physics library for Isogenic Engine. {
	category:"class",
	urls:[{
		name:"Box2D Reference",
		url:"http://www.box2dflash.org/docs/2.1a/reference/",
	}, {
		name:"Box2D-Web - Box2D ActionScript to JavaScript conversion source location",
		url:"http://code.google.com/p/box2dweb/",
	}],
	externalLibs:[{
		name:"box2d-web",
		desc:"Box2D JavaScript Port",
		url:"http://code.google.com/p/box2dweb/",
	}],
} **/
/** ready - Fired after the module is ready to use. {
	category: "event",
} **/
/** beforeStart - Fired before the module starts the simulation. {
	category: "event",
} **/
/** afterStart - Fired after the module starts the simulation. {
	category: "event",
} **/
/** beforeStop - Fired before the module stops the simulation. {
	category: "event",
} **/
/** afterStop - Fired after the module stops the simulation. {
	category: "event",
} **/
IgeBox2d = new IgeClass({
	// Use events
	Extends: [IgeEvents, IgeState],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		engine_ver:"0.1.0",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** box2d - Holds some quick object references to the box2d library. {
		category:"property",
		engine_ver:"1.0.0",
		type:"object",
	} **/
	box2d: null,
	
	/** _lib_box2d - Holds the Node.js box2d library instance. {
		category:"property",
		engine_ver:"1.0.0",
		type:"object",
	} **/	
	_lib_box2d: null,
	
	/** _gravity - The current simulation gravity setting. {
		category:"property",
		engine_ver:"1.0.0",
		type:"array",
		index:"integer",
	} **/
	_gravity: null,
	
	/** _allowSleep - Current boolean value determining if the simulation should allow sleep states or not. {
		category:"property",
		engine_ver:"1.0.0",
		type:"bool",
	} **/
	_allowSleep: null,
	
	/** _ptm - The current pixels to metres conversion value. {
		category:"property",
		engine_ver:"1.0.0",
		type:"integer",
	} **/	
	_ptm: null,
	
	/** _active - Boolean determining if the simulation is active or not. {
		category:"property",
		engine_ver:"1.0.0",
		type:"bool",
	} **/
	_active: null,
	
	/** _world - Holds the current simulation world object. {
		category:"property",
		engine_ver:"1.0.0",
		type:"object",
	} **/
	_world: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeBox2d';
		
		this.engine = engine;
		this.engine.box2d = this;
		
		this._state = false;
		this.box2d = {};
		
		// Register an engine requirement check against this module's state method
		this.engine.registerRequirement(this.bind(this.state));
		
		// Listen to the engine events we need to know about
		this.log('Listening for entity creation...');
		this.engine.entities.on('afterCreate', this.bind(this._createEntity));
		
		this._active = false;
		
		// Load the box2d library
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Require the box2d library
			this._lib_box2d = require(igeConfig.mapUrl('/engine/lib_box2d')).Box2D;
			
			// Define some class objects
			this.box2d.b2Vec2 = this._lib_box2d.Common.Math.b2Vec2;
			this.box2d.b2BodyDef = this._lib_box2d.Dynamics.b2BodyDef;
			this.box2d.b2Body = this._lib_box2d.Dynamics.b2Body;
			this.box2d.b2FixtureDef = this._lib_box2d.Dynamics.b2FixtureDef;
			this.box2d.b2Fixture = this._lib_box2d.Dynamics.b2Fixture;
			this.box2d.b2World = this._lib_box2d.Dynamics.b2World;
			this.box2d.b2MassData = this._lib_box2d.Collision.Shapes.b2MassData;
			this.box2d.b2PolygonShape = this._lib_box2d.Collision.Shapes.b2PolygonShape;
			this.box2d.b2CircleShape = this._lib_box2d.Collision.Shapes.b2CircleShape;
			this.box2d.b2DebugDraw = this._lib_box2d.Dynamics.b2DebugDraw;
			this.box2d.b2ContactListener = this._lib_box2d.Dynamics.b2ContactListener;
			
			this.log('Loaded all data!');
			this.state(true);
			this.emit('ready');
		}
		/* CEXCLUDE */
		if (!this.engine.isServer) {
			if (typeof(Box2D) != 'undefined') {
				this.box2d.b2Vec2 = Box2D.Common.Math.b2Vec2;
				this.box2d.b2BodyDef = Box2D.Dynamics.b2BodyDef;
				this.box2d.b2Body = Box2D.Dynamics.b2Body;
				this.box2d.b2FixtureDef = Box2D.Dynamics.b2FixtureDef;
				this.box2d.b2Fixture = Box2D.Dynamics.b2Fixture;
				this.box2d.b2World = Box2D.Dynamics.b2World;
				this.box2d.b2MassData = Box2D.Collision.Shapes.b2MassData;
				this.box2d.b2PolygonShape = Box2D.Collision.Shapes.b2PolygonShape;
				this.box2d.b2CircleShape = Box2D.Collision.Shapes.b2CircleShape;
				this.box2d.b2DebugDraw = Box2D.Dynamics.b2DebugDraw;
				this.box2d.b2ContactListener = Box2D.Dynamics.b2ContactListener;
				
				this.log('Loaded all data!');
				this.state(true);
				this.emit('ready');
			} else {
				this.log('Unabled to initialise IgeBox2d because the Box2D library is not in memory... did you put ./engine/libBox2d into the clientDeploy list inside your serverConfig.js?', 'error');
			}
		}
		
		// Set the default pixels to metres ratio
		this.setPtm(30); // In Box2D set 30px = 1 metre
		this.setGravity(0, 0); // Set the default gravity to nothing
		this.setAllowSleep(true); // Set the default to allow sleep
		
		this._engineHooks();
	},
	
	/** _engineHooks - Called by the init method. Will setup listener methods for
	any engine events the class requires. {
		category:"method",
	} **/
	_engineHooks: function () {
		// Hook any engine events we need
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () { return true; },
	
	/** createWorld - Create the world for the Box2D simulation. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the simulation world object on success or false on failure.",
		},
	} **/
	createWorld: function () {
		if (!this._world) {
			// World params - gravity, allow sleep
			this._world = new this.box2d.b2World(
				this._gravity,
				this._allowSleep
			);
			this.log('World created!');
			return this._world;
		} else {
			this.log('Cannot create world because one already exists!', 'warning');
			return false;
		}
	},
	
	/** processExistingEntities - Loops through existing entities in the engine
	memory and if the entity contains box2d data, processes the box2d data to
	link the entity to a simulation entity. This method is useful for ensuring
	that even entities that were created before this class was initialised are
	still processed by the box2d simulation if they should be. This only needs
	to be called once just after initialising the class. {
		category:"method",
	} **/
	processExistingEntities: function () {
		this.log('Processing existing entity definitions...');
		var entArray = this.engine.entities.byIndex;
		var count = entArray.length;
		var processed = 0;
		
		while (count--) {
			var entity = entArray[count];
			if (typeof(entity.box2d) != 'undefined' && typeof(entity.$local.$box2d) == 'undefined') {
				this._createEntity(entity);
				processed++;
			}
		}
		
		this.log('Processed ' + processed + ' existing entities with physics data');
	},
	
	/** setGravity - Set the gravity vector. {
		category:"method",
		arguments:[{
			name:"x",
			type:"float",
			desc:"The x value of the gravity vector.",
		}, {
			name:"y",
			type:"float",
			desc:"The y value of the gravity vector.",
		}]
	} **/
	setGravity: function (x, y) {
		this._gravity = new this.box2d.b2Vec2(x, y);
	},
	
	/** setAllowSleep - Sets the box2d simulation to allow or disallow
	sleeping. {
		category:"method",
		arguments:[{
			name:"b",
			type:"bool",
			desc:"Set to true to allow entity sleeping or false to disallow.",
		}]
	} **/
	setAllowSleep: function (b) {
		this._allowSleep = b;
	},
	
	/** setPtm - Sets the box2d simulation's pixels to metres conversion
	value. {
		category:"method",
		arguments:[{
			name:"v",
			type:"integer",
			desc:"The pixel to metre conversion value. Usually set to 30 in most simulations.",
		}]
	} **/
	setPtm: function (v) {
		this._ptm = v;
	},
	
	/** createBody - Creates a box2d b2BodyDef from the specified object
	parameters. {
		category:"method",
		arguments:[{
			name:"params",
			type:"object",
			desc:"The parameters to create the body def from.",
		}]
	} **/
	createBody: function (params) {
		var tempDef = new this.box2d.b2BodyDef;
		
		// Add the parameters of the body to the new body instance
		for (param in params) {
			tempDef[param] = params[param];
		}
		
		// Scale the position by the ptm
		if (typeof(params.position) == 'object') {
			if (typeof(params.position.x) != 'undefined') {
				//tempDef.position.x = params.position.x / this._ptm;
			}
			
			if (typeof(params.position.y) != 'undefined') {
				//tempDef.position.y = params.position.y / this._ptm;
			}
		}
		
		// Convert degrees to radians
		if (typeof(tempDef.angle) != 'undefined') { tempDef.angle *= Math.PI / 180; }
		
		// Add the body to the world with the passed fixture
		return this._world.CreateBody(tempDef);
	},
	
	/* createFixture - Creates a box2D fixture with the parameters object passed.
	b2FixtureDef Reference: http://www.box2dflash.org/docs/2.1a/reference/Box2D/Dynamics/b2FixtureDef.html
	
	Viable parameters are:
		density (float) - The density, usually in kg/m^2.
		filter (b2FilterData) - Contact filtering data.
		friction (float) - The friction coefficient, usually in the range [0,1].
		isSensor (boolean) - A sensor shape collects contact information but never generates a collision response.
		restitution (float) - The restitution (elasticity) usually in the range [0,1].
		shape (b2Shape) - The shape, this must be set.
		userData (object / array) - Use this to store application specific fixture data.
	*/
	
	/** createFixture - Creates a box2d b2FixtureDef from the specified object
	parameters. {
		category:"method",
		arguments:[{
			name:"params",
			type:"object",
			desc:"The parameters to create the fixture def from.",
		}]
	} **/
	createFixture: function (params) {
		var tempDef = new this.box2d.b2FixtureDef;
		
		for (param in params) {
			if (param != 'shapeDef') {
				tempDef[param] = params[param];
			}
		}		
		return tempDef;
	},
	
	/* createShape - Creates a shape; shapes cannot be reused!
	b2Shape Reference: http://www.box2dflash.org/docs/2.1a/reference/Box2D/Collision/Shapes/b2Shape.html
	
	Viable parameters are:
		type (b2PolygonShape, b2CircleShape), params (object)
	*/
	
	/** createShape - *MAY DEPRECIATE* Creates a new shape. {
		category:"method",
		arguments:[{
			name:"shape",
			type:"object",
			desc:"The shape object to apply the params to.",
		}, {
			name:"params",
			type:"object",
			desc:"The parameters to create the shape with.",
		}]
	} **/
	createShape: function (shape, params) {
		var newShape = shape;
		for (param in params) { newShape[param] = params[param]; }
		
		return newShape;
	},
	
	/** _createEntity - Called by an afterCreate event emit from the IgeEntities
	class. Scans the passed entity and checks for box2d definition data. If found
	the method will create a new box2d entity in the box2d simulation and link it
	to the engine's entity. {
		category:"method",
		return:{
			type:"bool",
			desc:"Retuns true on success or false if the entity does not contain box2d definition data.",
		},
		arguments:[{
			name:"entity",
			type:"object",
			desc:"The entity to scan for box2d definition data.",
		}]
	} **/
	_createEntity: function (entity) {
		if (this._world) {
			if (entity.box2d) {
				if (entity.$local) {
					if (entity.box2d.trace) { this.log('Physics enabled for entity: ' + entity.entity_id, 'info'); }
					// The entity has physics info so setup a physics object for it
					// and store that object inside the entity's $local.$box2d object
					entity.$local.$box2d = entity.$local.$box2d || {};
					
					// Setup box2d object variables
					var tempFixtureDef = null, fixture = null, tempFix = null, tempBod = null, shape = null;
					
					if (entity.box2d.trace) { this.log('Setting up entity body definition...', 'info'); }
					for (var i in entity.box2d.bodyDef) {
						var bodyDef = entity.box2d.bodyDef[i];
						if (entity.box2d.trace) { this.log('Processing entity body definition...', 'info'); }
						
						// Convert entity position co-ords to box2d co-ords
						// TO-DO - Do we really want to set a new position variable here?
						// Why not use a SetPosition call after the body is created?
						// Then the variabe won't be transmitted over net
						if (typeof(bodyDef.pos) != 'undefined') {
							// Get the x and y from the position object
							if (entity.box2d.trace) { this.log('Setting body position from definition...', 'info'); }
							bodyDef.position = {};
							bodyDef.position.x = bodyDef.pos.x / this._ptm;
							bodyDef.position.y = bodyDef.pos.y / this._ptm;
						} else {
							// Get the x and y from the entity
							if (entity.box2d.trace) { this.log('Setting body position from entity data...', 'info'); }
							var map = entity.$local.$map;
							
							bodyDef.position = {};
							bodyDef.position.x = (entity._transform[0]) / this._ptm;
							bodyDef.position.y = (entity._transform[1]) / this._ptm;
						}
						
						switch (i) {
							case 'static':
								// Create the body
								if (entity.box2d.trace) { this.log('Creating static body object...', 'info'); }
								bodyDef.type = this.box2d.b2Body.b2_staticBody;
								tempBod = this.createBody(bodyDef);
							break;
							
							case 'dynamic':
								// Create the body
								if (entity.box2d.trace) { this.log('Creating dynamic body object...', 'info'); }
								bodyDef.type = this.box2d.b2Body.b2_dynamicBody;
								tempBod = this.createBody(bodyDef);
							break;
						}
					}
					
					if (entity.box2d.trace) { this.log('Setting up entity fixture definition...', 'info'); }
					if (typeof(entity.box2d.fixtureDef) != 'undefined') {
						for (var fixtureIndex = 0; fixtureIndex < entity.box2d.fixtureDef.length; fixtureIndex++) {
							// Get the fixture definition
							tempFixtureDef = entity.box2d.fixtureDef[fixtureIndex];
							if (entity.box2d.trace) { this.log('Processing fixture definition...', 'info'); }
							
							// Create the fixture
							fixture = this.createFixture(tempFixtureDef);
							
							// Check for a shape definition for the fixture
							if (typeof(tempFixtureDef.shapeDef) != 'undefined') {
								var shapeDef;
								
								for (var i in tempFixtureDef.shapeDef) {
									switch (i) {
										case 'rect':
											// Set the shape as a polygon
											if (entity.box2d.trace) { this.log('Creating rect shape...', 'info'); }
											shape = this.createShape(new this.box2d.b2PolygonShape);
											
											// Set the polygon as a box
											var finalX = 0, finalY = 0, finalWidth, finalHeight;
											
											if (typeof(tempFixtureDef.shapeDef.rect.x) != 'undefined') {
												finalX = tempFixtureDef.shapeDef.rect.x;
											}
											
											if (typeof(tempFixtureDef.shapeDef.rect.y) != 'undefined') {
												finalY = tempFixtureDef.shapeDef.rect.y;
											}
											
											if (typeof(tempFixtureDef.shapeDef.rect.width) != 'undefined' && typeof(tempFixtureDef.shapeDef.rect.height) != 'undefined') {
												// Get the width and height from the rect object
												finalWidth = tempFixtureDef.shapeDef.rect.width;
												finalHeight = tempFixtureDef.shapeDef.rect.height;
											} else {
												// Get the width and height from the entity
												finalWidth = entity._size[0];
												finalHeight = entity._size[1];
											}
											shape.SetAsOrientedBox(
												(finalWidth / this._ptm) * entity._transform[9],
												(finalHeight / this._ptm) * entity._transform[10],
												new this.box2d.b2Vec2(finalX, finalY),
												0
											);
											
											fixture.shape = shape;
										break;
										case 'poly':
											if (entity.box2d.trace) { this.log('Creating poly shape...', 'info'); }
											shape = new this.box2d.b2PolygonShape;
										break;
										case 'circle':
											if (entity.box2d.trace) { this.log('Creating circle shape...', 'info'); }
											var radius = tempFixtureDef.shapeDef.circle.radius / this._ptm;
											fixture.shape = this.createShape(new this.box2d.b2CircleShape(radius));
										break;
										case 'edge':
											if (entity.box2d.trace) { this.log('Creating edge shape...', 'info'); }
											fixture.shape = this.createShape(this.box2d.b2EdgeShape);
										break;
									}
								}
								
								if (entity.box2d.trace) { this.log('Applying fixture to body...', 'info'); }
								tempBod.CreateFixture(fixture);						
							}
						}
					}				
					
					// Assign the entity's ID to the object's userData variable
					if (entity.box2d.trace) { this.log('Setting body entity ID to ' + entity.entity_id, 'info'); }
					tempBod.SetUserData(entity.entity_id);
					if (entity.box2d.trace) { this.log('Body entity ID set to ' + tempBod.m_userData, 'info'); }
					
					// Store the body of this physics object in the entity's local storage object
					entity.$local.$box2d._body = tempBod;
					
					if (entity.box2d.trace) { this.log('Entity physics created!', 'info'); }
					
					return true;
				}
			}
		} else {
			this.log('Cannot create entity physics because physics world has not yet been created. Create a new world before creating entities with a call to createWorld().', 'error');
			return false;
		}
	},
	
	/** shapeSetBox - Sets a shape as a box using the shape.SetAsBox() method. {
		category:"method",
		arguments:[{
			name:"shape",
			type:"object",
			desc:"The shape to set as a box.",
		}, {
			name:"w",
			type:"float",
			desc:"The width of the box.",
		}, {
			name:"h",
			type:"float",
			desc:"The height of the box.",
		}]
	} **/
	shapeSetBox: function (shape, w, h) {
		var fw = (w / this._ptm).toFixed(2);
		var fh = (h / this._ptm).toFixed(2);
		
		shape.SetAsBox(fw, fh);
	},
	
	/** getBodyAtMouse - *MAY DEPRECIATE* Pick the body underneath the
	mouse position and return it. {
		category:"method",
		return:{
			type:"object",
			desc:"The box2d body that was under the mouse.",
		},
		arguments:[{
			name:"mouseX",
			type:"integer",
			desc:"The mouse x co-ordinate.",
		}, {
			name:"mouseY",
			type:"integer",
			desc:"The mouse y co-ordinate.",
		}]
	} **/
	getBodyAtMouse: function (mouseX, mouseY) {
		// Convert co-ords to box2d space
		mouseX = mouseX / this._ptm;
		mouseY = mouseY / this._ptm;
		
		mousePVec = new this.box2d.b2Vec2(mouseX, mouseY);
		var aabb = new this.box2d.b2AABB();
		aabb.lowerBound.Set(mouseX - 0.001, mouseY - 0.001);
		aabb.upperBound.Set(mouseX + 0.001, mouseY + 0.001);
		
		// Query the world for overlapping shapes.
		selectedBody = null;
		this.world.QueryAABB(this.bind(this.getBodyCB), aabb);
		return selectedBody;
	},
	
	/** getBodyCB - Part of the getBodyAtMouse method. {
		category:"method",
	} **/
	getBodyCB: function (fixture) {
		//if(fixture.GetBody().GetType() != this.box2d.b2Body.b2_staticBody) {
			if(fixture.GetShape().TestPoint(fixture.GetBody().GetTransform(), mousePVec)) {
				selectedBody = fixture.GetBody();
				return false;
			}
		//}
		return true;
	},
	
	/** setContactListener - Creates a contact listener with the specified
	callbacks. {
		category:"method",
		arguments:[{
			name:"cb1",
			type:"function",
			desc:"The method to call when the contact listener detects contact has started.",
		}, {
			name:"cb2",
			type:"function",
			desc:"The method to call when the contact listener detects contact has ended.",
		}]
	} **/
	setContactListener: function (cb1, cb2) {
		var contactListener = new this.box2d.b2ContactListener;
		contactListener.BeginContact = cb1;
		contactListener.EndContact = cb2;
		this.world.SetContactListener(contactListener);
	},
	
	/** setDebugCanvas - Sets the canvas element to use for drawing
	box2d debug info. {
		category:"method",
		arguments:[{
			name:"canvasId",
			type:"string",
			desc:"The canvas element id to use as the debug drawing surface.",
		}]
	} **/
	setDebugCanvas: function (canvasId) {
		// Define the debug drawing instance
		var debugDraw = new this.box2d.b2DebugDraw;
		this._debugDrawCtx = $('#' + canvasId)[0].getContext("2d");
		debugDraw.SetSprite(this._debugDrawCtx);
		debugDraw.SetDrawScale(this._ptm);
		debugDraw.SetFillAlpha(0.3);
		debugDraw.SetLineThickness(1.0);
		debugDraw.SetFlags(this.box2d.b2DebugDraw.e_aabbBit |
							this.box2d.b2DebugDraw.e_centerOfMassBit |
							this.box2d.b2DebugDraw.e_controllerBit |
							this.box2d.b2DebugDraw.e_jointBit |
							this.box2d.b2DebugDraw.e_pairBit |
							this.box2d.b2DebugDraw.e_shapeBit
		);
		
		// Set the debug draw for the world
		this._world.SetDebugDraw(debugDraw);
	},
	
	/** setUpdateListener - Sets the method that will be called when
	updates occur to the box2d simulation. {
		category:"method",
		arguments:[{
			name:"cb",
			type:"function",
			desc:"The callback method.",
		}]
	} **/
	setUpdateListener: function (cb) {
		this._updateCallback = cb;
	},
	
	/** setDebugLayer - Sets the debug canvas to use based upon the viewport
	and layer index passed. {
		category:"method",
		arguments:[{
			name:"viewport",
			type:"object",
			desc:"The viewport object.",
		}, {
			name:"layerIndex",
			type:"integer",
			desc:"The index of the viewport draw layer to use as the debug canvas.",
		}]
	} **/
	setDebugLayer: function (viewport, layerIndex) {
		// Debug with IGE output
		this._box2dDebug = true;
		this._igeDebugVp = viewport;
		this._igeDebugLi = layerIndex;
		this._igeDebugCtx = $('#' + viewport.viewport_id + '_' + layerIndex)[0].getContext("2d");
		
		this.setDebugCanvas(viewport.viewport_id + '_' + layerIndex);
	},
	
	/** step - Step the simulation forward. {
		category:"method",
	} **/
	step: function () {
		if (this._active) {
			// Call the world step; frame-rate, velocity iterations, position iterations 
			this._world.Step(1 / 60, 10, 10);
			this._world.DrawDebugData();
			
			//this._renderCount++;
			
			/*
			if (this._box2dDebug) {
				// Redraw the debug data
				var viewport = this._igeDebugVp;
				var camera = viewport.$local.$camera;
				var ctx = this._igeDebugCtx;
				ctx.clearRect(0, 0, viewport.panLayer.width, viewport.panLayer.height);
				
				ctx.save();
				ctx.translate(viewport.$viewportAdjustX + viewport.$local.$map.map_tilesize2, viewport.$viewportAdjustY + viewport.$local.$map.map_tilesize2);
				//ctx.scale(0.2, 0.2);
				this._world.DrawDebugData();
				ctx.restore();
			}
			*/
			
			// Loop the physics objects and move the entities they are assigned to
			var tempBod = this._world.GetBodyList();
			while (tempBod) {
				if (tempBod.m_userData != null) {

					// This body has an entity assigned to it
					var entity = this.engine.entities.read(tempBod.m_userData);
					if (tempBod.IsAwake() && entity.box2d.bodyDef.dynamic) {
						// Update the entity data
						this.engine.entities.translate(entity, tempBod.m_xf.position.x * this._ptm, tempBod.m_xf.position.y * this._ptm, 0);
						this.engine.entities.rotate(entity, tempBod.GetAngle());
					}
				}
				
				tempBod = tempBod.GetNext();
			}
			
			// Clear forces because we have ended our physics simulation frame
			this._world.ClearForces();
			
			if (typeof(this._updateCallback) == 'function') {
				this._updateCallback();
			}
			
			requestAnimFrame(this.bind(this.step));
		}
	},
	
	/** start - Start the physics simulation. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true if the module is ready, false if not.",
		},
	} **/
	start: function (callback) {
		if (!this._active) {
			if (this.state()) {
				this.log('Starting physics simulation...');
				this.emit('beforeStart');
				this._active = true;
				requestAnimFrame(this.bind(this.step));
				this.emit('afterStart');
				this.log('Physics simulation started');
				return true;
			} else {
				this.log('Cannot start the physics simulation because the physics system is not ready!', 'warning');
				return false;
			}
		} else {
			this.log('Cannot start the physics simulation because it has already been started!', 'warning');
			return false;
		}
	},
	
	/** stop - Stop the physics simulation. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true if the simulation is running and is then stopped successfully, false if not.",
		},
	} **/
	stop: function () {
		if (this._active) {
			this.log('Stopping physics simulation...');
			this.emit('beforeStop');
			this._active = false;
			this.emit('afterStop');
			this.log('Physics simulation stopped');
			return true;
		} else {
			this.log('Cannot stop the physics simulation because it has not been started!', 'warning');
			return false;
		}
	},
});