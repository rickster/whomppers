/** IgeScreens - The screen management class. {
	category:"class",
} **/

/** beforeCreate - Fired before a screen is created. {
	category: "event",
	argument: {
		type:"object",
		name:"screen",
		desc:"The screen object this event was fired for.",
	},
} **/
/** afterCreate - Fired after a screen is created. {
	category: "event",
	argument: {
		type:"object",
		name:"screen",
		desc:"The screen object this event was fired for.",
	},
} **/
/** afterRemove - Fired after a screen is removed. {
	category: "event",
	argument: {
		type:"object",
		name:"screen",
		desc:"The screen object this event was fired for.",
	},
} **/
/** resize - Fired after screen(s) are resized. {
	category: "event",
} **/
IgeScreens = new IgeClass({
	
	Extends: [IgeCollection, IgeItem, IgeEvents],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: null,
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: null,
	
	/** currentScreen - The current screen that the engine is displaying (internal use). {
		category:"property",
		type:"object",
	} **/
	currentScreen: null,
	
	/** renderList - An array with an integer index that contains a list of
	screens to actively render (internal use). {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	renderList: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeScreens';
		this.collectionId = 'screen';
		
		this.engine = engine;
		
		this.byIndex = [];
		this.byId = [];
		this.renderList = [];
		
		if (!this.engine.isServer && !this.engine.isSlave) {
			// Set an event hook to resize screens and then any viewports with the autoresize property set to true
			$(window).bind('resize', this.bind(function () { this._doOrientationChange(); }));
			$(window).bind('orientationchange', this.bind(function() { this._doOrientationChange(); }));
			/*
			$(document).ready(function () {
				$(window).trigger('orientationchange');
			});
			*/
		}
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('screensCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand('screensUpdate', this.bind(this.receiveUpdate));
		this.engine.network.registerCommand('screensRemove', this.bind(this._remove));
		
		// Network screen commands
		this.engine.network.registerCommand('screensSetCurrent', this.bind(this.setCurrent));
		this.engine.network.registerCommand('screensStartSend', this.bind(this.netSendStarted));
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'screen_id',
			'screen_background_color',
			'screen_html',
			'screen_persist',
		]);
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends when creating a new item. Here you can define
	any object properties that are default across all items of this class. If this method returns false the create action
	will be cancelled. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureIdExists(pItem);
		this.ensureLocalExists(pItem);
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends when creating a new item. Checks the
	integrity of an item before it is allowed to be created. Here you can define custom checks to ensure an item being
	created conforms to the standard your class requires. If this method returns false the create action will be cancelled. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		if (this.byId[pItem[this.collectionId + '_id']]) {
			this.log('Attempted to create a ' + this.collectionId + ' that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		return true;
	},	
	
	/** _create - Create a new screen. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"object",
			desc:"Returns the newly created item on success or false on failure.",
		},
		argument: {
			type:"object",
			name:"pItem",
			desc:"The screen object to be created.",
			link:"screenData",
		},
	} **/
	_create: function (pItem, callback) {
		this.byIndex.push(pItem);
		this.byId[pItem.screen_id] = pItem;
		
		// Check if we're working client-side and if so, create screen DOM elements
		if (!this.engine.isServer && !this.engine.isSlave) {
			var screenContainer = $('<div id="' + pItem.screen_id + '">');
			screenContainer.css('position', 'absolute');
			screenContainer.css('width', '100%');
			screenContainer.css('height', '100%');
			screenContainer.css('display', 'none');
			
			// Check if we should set a background color
			if (pItem.screen_background_color) {
				screenContainer.css('backgroundColor', pItem.screen_background_color);
			}
			
			// Check if we have been asked to append the screen element to a specific element
			if (pItem.screen_parent_id) {
				var parentElement = $('#' + pItem.screen_parent_id);
				if (parentElement[0]) {
					parentElement.append(screenContainer);
				} else {
					this.log('Cannot append the screen element to the specified parent because the parent element does not exist.', 'error', pItem);
				}
			} else {
				// No parent element_id specified so append to the body
				$('body').append(screenContainer);
			}
			
			// Now if the screen has an HTML file as its contents, load that into the screen HTML
			if (pItem.screen_html) {
				this.log('Loading screen HTML data: ' + pItem.screen_html);
				$.ajax({
					url: pItem.screen_html,
					success: this.bind(function (data) {
						//console.log('Screen data loaded ' + pItem.screen_html + ' +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
						this.log('Screen HTML data loaded ' + pItem.screen_html);
						
						// Append the html to the screen innerHTML
						$('#' + pItem.screen_id).append($(data));
						
						// Trigger an orientation change to ensure screen size etc is correct
						$(window).trigger('orientationchange');
						
						// Check for a callback function embedded in the item
						if (typeof(pItem.$local.create_callback) == 'function') {
							pItem.$local.create_callback.apply(this, [pItem]);
							delete pItem.$local.create_callback;
						}
						
						// Trigger the afterCreate event
						this.emit('afterCreate', pItem);
					}),
					dataType: 'html',
					error: this.bind(function () { this.log('Error loading screen html!', 'error', arguments); }),
				});
			} else {
				// Trigger an orientation change to ensure screen size etc is correct
				$(window).trigger('orientationchange');
				if (pItem.screen_always_render) { this.renderList.push(pItem); }
				this.emit('afterCreate', pItem);
			}
		} else {
			this.emit('afterCreate', pItem);
		}
		
		return pItem;
		
	},
	
	/** _update - Updates the class collection item with the matching id specified in the updData
	parameter with all properties of the pData parameter. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (pItem, pData) {
		// Update the current object with the new object's properties
		for (var i in pData) {
			pItem[i] = pData[i];
		}
		
		this.emit('afterUpdate', pItem);
		
		if (typeof(pItem.$local.update_callback) == 'function') {
			pItem.$local.update_callback(pItem);
			pItem.$local.update_callback = null;
		}
		
		return pItem;
	},
	
	/** _remove - Private method that removes the item identified by the passed
	id from the engine. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"curScreen",
			desc:"The item to be removed.",
			link:"screenData",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (pItem && pItem != null) {
			// Remove the item's DOM elements
			$('#' + pItem.screen_id).remove();
			
			// Check if the pItem has a callback method and if so, save a reference to it, then fire after removal of the pItem
			var cbMethod = null;
			if (typeof pItem.$local.$callback == 'function') {
				cbMethod = pItem.$local.$callback;
			}
			
			// Remove it from all the arrays
			var arr1 = this.byIndex;
			
			// Remove the item from all the lookup arrays
			delete this.byId[pItem[this.collectionId + '_id']];
			var arr1Index = arr1.indexOf(pItem);
			arr1.splice(arr1Index, 1);
			
			if (typeof cbMethod == 'function') {
				cbMethod.apply(this);
			}
			
			return true;
		} else {
			return false;
		}
	},
	
	/** setCurrent - Set the current visible screen and hide all others. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"string",
			name:"screenId",
			desc:"The id of the screen to make current.",
		}, {
			type:"object",
			name:"client",
			desc:"The socket.io client to send the command to.",
			flags:"optional, server",
		}],
	} **/
	setCurrent: function (screenId, client) {
		if (this.engine.isServer) {
			/* CEXCLUDE */
			this.log('Setting current screen to id: ' + screenId);
			this.engine.network.send('screensSetCurrent', screenId, client);
			/* CEXCLUDE */
		} else if (!this.engine.isSlave) {
			// If there is a current screen, hide it before switching!
			if (this.currentScreen != null) {
				if (document.getElementById(this.currentScreen.screen_id) != null) {
					document.getElementById(this.currentScreen.screen_id).style.display = 'none';
					if (!this.currentScreen.screen_always_render && this.renderList.indexOf(this.currentScreen) > -1) { this.renderList.splice(this.renderList.indexOf(this.currentScreen), 1); }
				}
			}
			
			/* Go through all the maps on this screen and then all the viewports looking
			at those maps and make sure that all the viewports have their dirty rectangles
			deleted and one added that is the size of the viewport - this means that the
			viewports will be updated whenever switching screens but also stops massive
			lag when loads of entities have changed position or been created since the 
			screen was inactive. */
			
			// Check if a screen is actually currently selected
			if (this.byId[screenId] != null) {
				
				// Loop through all viewports assigned to this screen
				var viewportsByScreenId = this.engine.viewports.byScreenId[screenId];
				
				// Check if we have any viewports for this screen!
				if (viewportsByScreenId != null) {
					
					var viewportCount = viewportsByScreenId.length;
					
					// Select each viewport
					while (viewportCount--) {
						
						/* Make the whole viewport and all layers dirty so they will all redraw on the
						next rendering cycle */
						this.log('Making viewport dirty with id: ' + viewportsByScreenId[viewportCount].viewport_id);
						this.engine.viewports.makeViewportDirty(viewportsByScreenId[viewportCount]);
						
					}
					
				}
				
			}			
			
			// Assign the new screen as current and show it!
			this.currentScreen = this.byId[screenId];
			if (this.currentScreen != null) {
				document.getElementById(this.currentScreen.screen_id).style.display = 'block';
				this.renderList.push(this.currentScreen);
				this.log('Current screen set to ' + this.currentScreen.screen_id);
				return true;
			} else {
				this.log('An attempt was made to switch to a screen that does not exist named: ' + screenId, 'error');
				return false;
			}
		} else {
			// Engine is running as slave so set current screen and xmsg
			this.currentScreen = this.byId[screenId];
			return true;
		}
		
		return false;
	},
	
	/** _doAutoSize - Autosizes all screens to fill their parent elements. Called
	when the browser window resizes. {
		category:"method",
		engine_ver:"0.1.2",
	} **/
	_doAutoSize: function () {
		var screenCount = this.byIndex.length;
		var screenDef = null;
		var screenContainer = null;
		
		while (screenCount--) {
			
			screenDef = this.byIndex[screenCount];
			screenContainer = document.getElementById(screenDef.screen_id);
			
			if (this._currentOrientation == 'landscape') {
				var newWidth = $('#' + screenDef.screen_id).parent().innerWidth();
				var newHeight = $('#' + screenDef.screen_id).parent().innerHeight();
			} else {
				var newWidth = $('#' + screenDef.screen_id).parent().innerWidth();
				var newHeight = $('#' + screenDef.screen_id).parent().innerHeight();
			}
						
			if (screenContainer != null) {
				screenContainer.style.width = newWidth + 'px';
				screenContainer.style.height = newHeight + 'px';
				resized = true;
			}
			
		}
		
		this.emit('resize');
		
	},
	
	/** _doOrientationChange - Stores the current orientation and then calls the
	_doAutoSize() method so that the screens fit the new window size. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_doOrientationChange: function () {
		if (!this._currentInnerWidth ||
			!this._currentInnerHeight ||
			this._currentInnerWidth != window.innerWidth ||
			this._currentInnerHeight != window.innerHeight
		) {
			// Store the current inner dimensions
			this._currentInnerWidth = window.innerWidth;
			this._currentInnerWidth = window.innerWidth;
			
			if (typeof(window.orientation) == 'undefined') {
				// Check for orientation from width / height analysis
				if (window.innerWidth >= window.innerHeight) {
					this._currentOrientation = 'landscape';
					this._currentOrientationVal = window.orientation;
				} else {
					this._currentOrientation = 'portrait';
					this._currentOrientationVal = window.orientation;
				}
			} else {
				switch (window.orientation) {
					case 0:
					case 180:
						// We're in portrait mode
						this._currentOrientation = 'portrait';
						this._currentOrientationVal = window.orientation;
					break;
					
					case 90:
					case -90:
						// We're in portrait mode
						this._currentOrientation = 'landscape';
						this._currentOrientationVal = window.orientation;
					break;
				}
			}
			
			//this.log('Screen orientation has changed to: ' + this._currentOrientation);
			//this.log('Dims ' + window.innerWidth + ', ' + window.innerHeight);
			
			// Now do a resize to ensure all our stuff is the correct size
			this._doAutoSize();
		}
		
		// Clear the url bar if we're running on a phone / mobile device
		setTimeout(function () { window.scrollTo(0, 1); }, 300);
	},
	
});