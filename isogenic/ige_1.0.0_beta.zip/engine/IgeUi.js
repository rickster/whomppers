/** IgeUi - The UI entity management class. This class is designed to
be optionally extended by the IgeEntities class and provides UI entity
support if required. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeUi = new IgeClass({
	init: function () {},
	
	/** uiInit - Sets up some local variables and event listeners for the UI system. {
		category:"method",
	} **/
	uiInit: function () {
		this.uiByIndex = [];
		this.uiById = [];
		this.uiByType = [];
		this.uiLayerUse = [];
		
		this.ige.viewports.on('mousemove', this.bind(this._uiVpMouseMove));
		this.ige.viewports.on('mouseup', this.bind(this._uiVpMouseUp));
		this.ige.viewports.on('mousedown', this.bind(this._uiVpMouseDown));
	},
	
	/** _uiDefaults - Called by the IgeItem class which this class extends when creating a new item. Here you can define
	any object properties that are default across all items of this class. If this method returns false the create action
	will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_uiDefaults: function (pItem) {
		if (typeof(pItem.entity_type) == 'undefined') {
			pItem.entity_type = ENTITY_TYPE_UI;
		}
		if (typeof(pItem.entity_layer) == 'undefined') {
			pItem.entity_layer = LAYER_UI;
		}
		if (typeof(pItem.asset_id) == 'undefined') {
			pItem.asset_id = pItem.ui.states[pItem.ui.state].asset_id;
		}
		return true;
	},
	
	/** _uiIntegrity - Called by the IgeItem class which this class extends when creating a new item. Checks the
	integrity of an item before it is allowed to be created. Here you can define custom checks to ensure an item being
	created conforms to the standard your class requires. If this method returns false the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_uiIntegrity: function (pItem) {
		if (!pItem.entity_id) {
			this.log('Cannot create UI entity because it must contain an entity_id property!', 'warning', pItem);
			return false;
		}
		if (typeof(pItem.ui) != 'object') {
			this.log('Cannot create UI element because the ui property does not contain a valid object!', 'warning', pItem);
			return false;
		}
		if (typeof(pItem.ui.type) != 'number') {
			this.log('Cannot create UI element because the ui_type property does not contain a valid value!', 'warning', pItem);
			return false;
		}
		return true;
	},
	
	/** uiCreate - The private method that is called when a new entity is created. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns null at all times.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The UI entity object to be created.",
			link:"uiData",
		}],
	} **/
	uiCreate: function (pItem) {
		if (this._uiIntegrity(pItem)) {
			// Apply defaults
			this._uiDefaults(pItem);
			
			// Add the UI entity to the collection arrays
			this.uiByIndex.push(pItem);
			this.uiById[pItem.entity_id] = pItem;
			this.uiByType[pItem.ui.type] = this.uiByType[pItem.ui.type] || [];
			this.uiByType[pItem.ui.type].push(pItem);
			
			this.uiLayerUse[pItem.entity_layer] = true;
		}
	},
	
	/** _uiVpMouseMove - The private method that is called when a viewport emits
	a mousemove event. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false at all times.",
		},
		arguments: [{
			type:"object",
			name:"e",
			desc:"The event object.",
		}],
	} **/
	_uiVpMouseMove: function (event) {
		event.preventDefault ? event.preventDefault() : event.returnValue = false;
		
		// Check for any intersection with UI entities
		var hitMissArr = this.uiAtScreenXY(event.viewport, event.pageX, event.pageY);
		var hits = hitMissArr[0];
		var misses = hitMissArr[1];
		var count = hits.length;
		
		// Loop the hits
		while (count--) {
			var entity = hits[count];
			if (this.uiState(entity) != UI_STATE_DOWN) {
				this.uiState(entity, UI_STATE_OVER, true);
			}
		}
		
		var count = misses.length;
		
		// Loop the misses
		while (count--) {
			var entity = misses[count];
			this.uiState(entity, UI_STATE_UP, false);
		}
		
		return false;
	},
	
	/** _uiVpMouseDown - The private method that is called when a viewport emits
	a mousedown event. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false at all times.",
		},
		arguments: [{
			type:"object",
			name:"e",
			desc:"The event object.",
		}],
	} **/
	_uiVpMouseDown: function (event) {
		event.preventDefault ? event.preventDefault() : event.returnValue = false;
		
		// Check for any intersection with UI entities
		var hitMissArr = this.uiAtScreenXY(event.viewport, event.pageX, event.pageY);
		var hits = hitMissArr[0];
		var count = hits.length;
		
		// Loop the hits
		while (count--) {
			var entity = hits[count];
			this.uiState(entity, UI_STATE_DOWN, true);
		}
		
		return false;
	},
	
	/** _uiVpMouseUp - The private method that is called when a viewport emits
	a mouseup event. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false at all times.",
		},
		arguments: [{
			type:"object",
			name:"e",
			desc:"The event object.",
		}],
	} **/
	_uiVpMouseUp: function (event) {
		event.preventDefault ? event.preventDefault() : event.returnValue = false;
		
		// Check for any intersection with UI entities
		var hitMissArr = this.uiAtScreenXY(event.viewport, event.pageX, event.pageY);
		var hits = hitMissArr[0];
		var count = hits.length;
		
		// Loop the hits
		while (count--) {
			var entity = hits[count];
			this.uiState(entity, UI_STATE_UP, true);
		}
		
		return false;
	},
	
	/** uiState - Sets and retrieves a UI entity state. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns the UI entity's current state or -1 on error.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The UI entity object to operate on.",
		}, {
			type:"multi",
			name:"newState",
			desc:"The new state to apply to the UI entity object.",
		}, {
			type:"bool",
			name:"emit",
			desc:"When true, instructs the method to emit an event for the state change.",
		}],
	} **/
	uiState: function (entity, newState, emit) {
		if (entity.ui) {
			if (typeof(newState) != 'undefined' && entity.ui.state != newState && entity.ui.states[newState]) {
				entity.ui.state = newState;
				this._uiApplyState(entity, entity.ui.states[newState], newState, emit);
			}
			
			return entity.ui.state;
		}
		
		return -1;
	},
	
	/** _uiApplyState - The private method that is used to read state data
	and apply it to a UI entity. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns null at all times.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The UI entity object to operate on.",
		}, {
			type:"object",
			name:"stateData",
			desc:"The stateData object contains all the properties of the entity that are to be applied.",
		}, {
			type:"string",
			name:"stateName",
			desc:"The name of the state being applied.",
		}, {
			type:"bool",
			name:"emit",
			desc:"When true, instructs the method to emit an event for the state change.",
		}],
	} **/
	_uiApplyState: function (entity, stateData, stateName, emit) {
		// Set the asset
		if (typeof(stateData.asset_id) != 'undefined') {
			this.ige.entities.setAsset(entity, stateData.asset_id);
		}
		
		// Set the asset sheet frame
		if (typeof(stateData.asset_sheet_frame) != 'undefined') {
			this.ige.entities.setSheetFrame(entity, stateData.asset_sheet_frame);
		}
		
		// Set visibility
		if (typeof(stateData.entity_hide) != 'undefined') {
			if (stateData.entity_hide) {
				this.ige.entities.hide(entity);
			} else {
				this.ige.entities.show(entity);
			}
		}
		
		// Set enabled
		if (typeof(stateData.entity_disabled) != 'undefined') {
			if (stateData.entity_disabled) {
				this.ige.entities.disable(entity);
			} else {
				this.ige.entities.enable(entity);
			}
		}
		
		// Set transform			
		if (typeof(stateData.entity_transform) != 'undefined') {
			this.ige.entities.applyTranform(entity, stateData.entity_transform);
		}
		
		// Set highlight
		if (typeof(stateData.entity_highlight) != 'undefined') {
			if (stateData.entity_highlight) {
				this.ige.entities.highlight(entity);
			} else {
				this.ige.entities.unHighlight(entity);
			}
		}
		
		// Mount points
		if (stateData.entity_mounts) {
			entity.entity_mounts = entity.entity_mounts || {};
			for (var i in stateData.entity_mounts) {
				entity.entity_mounts[i] = stateData.entity_mounts[i];
			}
		}
		
		// Entity text
		if (stateData.entity_text) {
			entity.entity_text = entity.entity_text || {};
			for (var i in stateData.entity_text) {
				entity.entity_text[i] = stateData.entity_text[i];
			}
		}
		
		// Emit event
		if (emit && stateData.emit_event) {
			this.emit('ui_' + stateName, [entity]);
		}
	},
	
	/** uiAtScreenXY - Scans each UI entity and checks if the co-ordinates on the passed
	viewport are inside the bounds of the entity determining if each entity is at the 
	passed screen XY. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"array",
			desc:"Returns an array with two items, each of which is also an array. [0] = all entities whose bounds intersect the co-ordinates. [1] = all entities whose bounds do not intersect the co-ordinates.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	uiAtScreenXY: function (viewport, x, y) {
		// Get the world co-ordinates of the mouse event
		var point = this.ige.viewports.screenToWorld(viewport, x, y);
		
		var hitArray = [];
		var missArray = [];
		
		x = point[0];
		y = point[1];
		
		// Loop entities and detect if our mouse is inside the entity bounding box
		// Get all the entities
		var ents = this.uiByIndex;
		var count = ents.length;
		
		while (count--) {
			var entity = ents[count];
			var renderMode = entity.$local.$asset.asset_render_mode;
			
			// Select the correct point co-ordinate type for the layer
			// this entity exists on (either a 2d or iso layer at time
			// of writing in version 1.0.0b)
			x = point[renderMode][0];
			y = point[renderMode][1];
			
			if (entity.entity_hide != true && entity.entity_disabled != true) {
				var entityBounds = this.ige.entities.bounds(entity);
				var depth = 0;
				
				// Check mouse co-ordinates and see if they are inside our entity bounding box
				if (entityBounds[0] <= x &&
					entityBounds[1] <= y &&
					entityBounds[0] + entityBounds[2] > x &&
					entityBounds[1] + entityBounds[3] > y) {
					
					hitArray.push(entity);
				} else {
					missArray.push(entity);
				}
			} else {
				missArray.push(entity);
			}
		}
		
		return [hitArray, missArray];
	},
});