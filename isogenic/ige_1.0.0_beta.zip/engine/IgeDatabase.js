/** IgeDatabase - Manages database connections. {
	category:"class",
	providers:[
		"IgeDatabaseProvider_Mongo"
	],
} **/
IgeDatabase = new IgeClass({
	
	Extends: IgeEvents,
	
	engine: null,
	wrapper: null,
	
	byIndex: [],
	byId: [],
	currentWrapper: '',
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeDatabase';
		
		this.engine = engine;
		
		this.byIndex = [];
		this.byId = [];
		this.currentWrapper = '';
	},
	
	/** setProvider - Sets the provider that the database system will use. {
		category:"method",
		return:{
			type:"bool",
			desc:"Returns true on success and false on failure.",
		},
		argument: {
			type:"string",
			name:"provider",
			desc:"The name of the provider class to absorb.",
		},
	} **/
	setProvider: function (provider) {
		this.log('Selecting new database provider "' + provider + '"...');
		if (this._currentProvider) {
			// A provider is already in place
			this.log('An existing provider is already in place, removing: ' + this._currentProvider);
			this._currentProvider = null;
		}
		
		if (this._providers[provider] && this._providers[provider].classMethod) {
			this.log('Provider found, absorbing provider...');
			this.absorbClass(this._providers[provider].classMethod.prototype);
			if (this._currentProvider) {
				this.log('Provider absorbed successfully!');
				return true;
			} else {
				this.log('Error absorbing provider class properties!', 'error');
				return false;
			}
		} else {
			this.log('Cannot select provider "' + provider + '" because it does not exist.', 'error');
			return false;
		}
	},
});