/** IgeDataLoader - Provides data loader helper methods to the extending class.
This class is designed to be extended and does not do anything by itself. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeDataLoader = new IgeClass({
	init: function () {},
	
	/* CEXCLUDE */
	/** loadAllDbData - Loads all the data from the database into memory. Optionally clears any
	non-persistent data from the database first. {
		engine_ver:"0.2.0",
		category:"method",
		arguments: [{
			type:"bool",
			name:"clearFirst",
			desc:"If set to true will clear all non-persistent data from the database before loading any data.",
		}, {
			type:"function",
			name:"callback",
			desc:"The method to call when all data has been successfully loaded from the database into the engine.",
			flags:"optional",
		}],
		flags:"server",
	} **/
	loadAllDbData: function (clearFirst, callback) {
		if (clearFirst) {
			// Clear all non-persist data first
			this.database.remove('asset', {asset_persist:false}, this.bind(function (err) {
			this.database.remove('map', {map_persist:false}, this.bind(function (err) {
			this.database.remove('viewport', {viewport_persist:false}, this.bind(function (err) {
			this.database.remove('screen', {screen_persist:false}, this.bind(function (err) {
			this.database.remove('camera', {camera_persist:false}, this.bind(function (err) {
			this.database.remove('entity', {entity_persist:false}, this.bind(function (err) {
				this._loadAllDbData(callback);
			}));
			}));
			}));
			}));
			}));
			}));
		} else {
			this._loadAllDbData(callback);
		}
	},
	
	/** _loadAllDbData - Called by loadAllDbData after non-persistent data is removed from the
	database or if no removal is required. This is used because calls to the DB are async. {
		engine_ver:"0.2.0",
		category:"method",
		arguments: [{
			type:"function",
			name:"callback",
			desc:"The method to call when all data has been successfully loaded from the database into the engine.",
			flags:"optional",
		}],
		flags:"server",
	} **/
	_loadAllDbData: function (callback) {
		// Load all the world data from the database!
		this.templates.dbLoadAll({}, this.bind(function () {
		this.screens.dbLoadAll({}, this.bind(function () {
		this.animations.dbLoadAll({}, this.bind(function () {
		this.assets.dbLoadAll({}, this.bind(function () {
		this.maps.dbLoadAll({}, this.bind(function () {
		this.cameras.dbLoadAll({}, this.bind(function () {
		this.viewports.dbLoadAll({}, this.bind(function () {
			callback();
		}));
		}));
		}));
		}));
		}));
		}));
		}));
	},
	
	/** loadData - Load data from a list of collections based upon the specified dataObj using the defined filters.
	The data will be loaded from each collection in order and only once each collection has finished loading its data
	will the next collection start loading its data. {
		engine_ver:"0.2.0",
		category:"method",
		arguments: [{
			type:"object",
			name:"dataObj",
			desc:"An object defining which collections to load data from and what filters to apply to the data that is loaded.",
		}],
		flags:"server",
	} **/
	loadData: function (dataObj) {
		if (dataObj != null && this.__loadDataObj == null) {
			this.__loadDataCollection = this.__loadDataCollection || [];
			this.__loadDataFilter = this.__loadDataFilter || [];
			this.__loadDataMax = 0;
			
			for (var i in dataObj) {
				this.log('[loadData] Queuing data retrieval from collection ' + i);
				this.__loadDataCollection.push(i);
				this.__loadDataFilter.push(dataObj[i] || {});
				this.__loadDataMax++;
			}
			
			this.__loadDataObj = dataObj;
			this.__loadDataIndex = 0;
			
			this._loadNextData();
			
			return true;
		} else {
			return false;
		}
	},
	
	/** _loadNextData - Called by loadData. Loads the next collection data in the loadData list. {
		engine_ver:"0.2.0",
		category:"method",
		flags:"server",
	} **/
	_loadNextData: function () {
		if (this.__loadDataIndex < this.__loadDataMax) {
			var collection = this.__loadDataCollection[this.__loadDataIndex];
			var filter = this.__loadDataFilter[this.__loadDataIndex];
			
			this.log('Loading data for collection: ' + collection);
			this[collection].dbLoadAll(filter, this.bind(function () { this.__loadDataIndex++; this._loadNextData(); }));
		} else {
			// All data has finished loading, emit an event
			this.log('[loadData] Completed');
			this.emit('_loadDataFinished');
		}
	},
	/* CEXCLUDE */
});