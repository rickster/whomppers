/** IgeCameras - The camera manager. {
	category:"class",
	examples:[{
		name:"Create a Camera",
		desc:"Creates a camera for a viewport looking at the viewport's map at 0, 0.",
		code:"<pre>
			this.ige.cameras.create({
				camera_id:'mainCam',
				camera_transform:{
					translate:[0, 0, 0],
				},
			});
		</pre>",
	}, {
		name:"Create a Camera With a Mirror View of the Map",
		desc:"Creates a camera for a viewport looking at the viewport's map at 0, 0 but with the camere scale inverted on the x axis.",
		code:"<pre>
			this.ige.cameras.create({
				camera_id:'mainCam',
				camera_transform:{
					translate:[0, 0, 0],
					scale:[-1, 1, 1],
				},
			});
		</pre>",
	}],
} **/

/** beforeCreate - Fired before a camera is created. {
	category: "event",
	arguments: [{
		type:"object",
		name:"camera",
		desc:"The camera object this event was fired for.",
		link:"cameraData",
	}],
	control:"This event can cancel subsequent code if the receiving method returns true.",
} **/
/** afterCreate - Fired after a camera is created. {
	category: "event",
	arguments: [{
		type:"object",
		name:"camera",
		desc:"The camera object this event was fired for.",
		link:"cameraData",
	}],
} **/
IgeCameras = new IgeClass({
	
	Extends: [IgeCollection, IgeItem, IgeEvents, IgeTransform, IgeTween],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: null,
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: null,
	
	/** tracking - An array with a string index holds data about which entities
	cameras are currently tracking. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	tracking: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		arguments: [{
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		}],
	} **/
	init: function (engine) {
		this._className = 'IgeCameras';
		this.collectionId = 'camera';
		
		this.ige = engine;
		this.engine = engine; // Legacy engine reference
		
		this.byIndex = [];
		this.byId = [];
		
		this.tracking = [];
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
		
		// Register the tweening processor method as a pre-world-tick method
		this.ige.preWorldTick(this.bind(this.tweenProcess), 'client'); // only process on client
		
		this._firstRun = true;
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('camerasCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand('camerasUpdate', this.bind(this.receiveUpdate));
		this.engine.network.registerCommand('camerasRemove', this.bind(this.receiveRemove));
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'camera_id',
			'camera_x',
			'camera_y',
			'camera_z',
		]);
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends when creating a new item. Here you can define
	any object properties that are default across all items of this class. If this method returns false the create action
	will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureLocalExists(pItem);
		/* CEXCLUDE */
		if (this.engine.isServer) { this.ensurePersistExists(pItem); }
		/* CEXCLUDE */
		this.ensureIdExists(pItem);
		
		// Make sure the camera scale is usable and it has a default size
		pItem.$local.$originalSize = [1024, 768];
		
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends when creating a new item. Checks the
	integrity of an item before it is allowed to be created. Here you can define custom checks to ensure an item being
	created conforms to the standard your class requires. If this method returns false the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		// Check that this item does not already exist
		if (this.byId[pItem[this.collectionId + '_id']]) {
			this.log('Attempted to create ' + this.collectionId + ' that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		
		// No integrity checks failed so return true to continue processing this item
		return true;
	},
	
	/** _create - Create a new camera to be use with a viewport. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the newly created item on success or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera object to be created.",
			link:"cameraData",
		}],
	} **/
	_create: function (pItem) {
		if (this._firstRun) {
			// Hook the viewport resize event to auto-scale cameras with an auto-scale setting
			this.engine.viewports.on('afterResize', this.bind(this._doAutoScale));
			this._firstRun = false;
		}
		
		this.byIndex.push(pItem);
		this.byId[pItem.camera_id] = pItem;
		
		// Apply the transformation data to the entity
		this.applyTransform(pItem);
		this.bounds(pItem, true);
		
		// Check for a callback function embedded in the entity
		if (typeof(pItem.$local.create_callback) == 'function') {
			pItem.$local.create_callback.apply(this, [pItem]);
			pItem.$local.create_callback = null;
		}
		
		this.emit('afterCreate', pItem);
		
		return pItem;
	},
	
	/** _update - Updates the class collection item with the matching id specified in the updData
	parameter with all properties of the pData parameter. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (pItem, pData) {
		// Grab the current item object
		var pItem = this.read(pItem);

		if (pItem != null) {
			// Emit the beforeUpdate event and halt if any listener returns the cancel flag
			if (!this.emit('beforeUpdate', pItem)) {
				// Update the current object with the new object's properties
				for (var i in pData) {
					pItem[i] = pData[i];
				}
			}
		} else {
			this.log('Cannot update item because it could not be located by calling this.read().', 'error', pItem);
			return false;
		}
	},
	
	/** _remove - Private method that removes the item identified by the passed
	id from the engine. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"curScreen",
			desc:"The item to be removed.",
			link:"screenData",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (pItem && pItem != null) {
			// Remove the item's DOM elements
			$('#' + pItem.screen_id).remove();
			
			// Check if the pItem has a callback method and if so, save a reference to it, then fire after removal of the pItem
			var cbMethod = null;
			if (typeof pItem.$local.$callback == 'function') {
				cbMethod = pItem.$local.$callback;
			}
			
			// Remove it from all the arrays
			var arr1 = this.byIndex;
			
			// Remove the item from all the lookup arrays
			delete this.byId[pItem[this.collectionId + '_id']];
			var arr1Index = arr1.indexOf(pItem);
			arr1.splice(arr1Index, 1);
			
			if (typeof cbMethod == 'function') {
				cbMethod.apply(this);
			}
			
			return true;
		} else {
			return false;
		}
	},
	
	/** trackTarget - Tells the camera to start tracking the movement of a target entity. The camera
	will follow the target entity until cancelTrackTarget is used to cancel tracking. {
		category:"method",
		engine_ver:"0.1.1",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to use when tracking the entitiy.",
			link:"cameraData",
		}, {
			type:"multi",
			name:"entityId",
			desc:"The id or the entity object of the entitiy to track.",
			link:"entityData",
		}],
	} **/
	trackTarget: function (camera, entityId, trackingOffset) {
		if (!trackingOffset) { trackingOffset = [0, 0]; }
		camera = this.read(camera);
		
		if (camera) {
			camera.tracking_offset = trackingOffset;
			var entity = this.engine.entities.read(entityId);
			
			if (entity) {
				// Start tracking the movement of this entity
				this.tracking[entity.entity_id] = this.tracking[entity.entity_id] || [];
				this.tracking[entity.entity_id].push(camera);
				this.engine.entities.on('afterMove', this.bind(this._targetMoved));
				
				this.log('Camera ' + camera.camera_id + ' is now tracking entity ' + entity.entity_id);
				
				// Get the cam to look at the entity
				this._targetMoved(entity);
			} else {
				this.log('Cannot track target entity because passed entity could not be found!', 'warning', entity);
			}
		} else {
			this.log('Cannot track target entity because passed camera could not be found!', 'warning', camera);
		}
	},
	
	/** cancelTrackTarget - Will cancel tracking of an entity previously set to track
	by a call to trackTarget. {
		category:"method",
		engine_ver:"0.1.1",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to use when cancelling the active tracking.",
			link:"cameraData",
		}, {
			type:"string",
			name:"entityId",
			desc:"The id of the entitiy that is currently being tracked.",
		}],
	} **/
	cancelTrackTarget: function (camera, entityId) {
		var entity = this.engine.entities.byId[entityId];
		
		if (camera && entity) {
			if (this.tracking[entityId]) {
				// Find the camera in the entity tracking array
				var camIndex = this.tracking[entityId].indexOf(camera);
				
				// Remove the camara from the entity tracking array
				if (camIndex > -1) {
					// Remove cam
					this.tracking[entityId].splice(camIndex, 1);
					
					// Check if this entity tracking array is now empty
					if (!this.tracking[entityId].length) {
						delete this.tracking[entityId];
					}
					
					// Check if the entire tracking array is now empty
					if (!this.tracking.length) {
						// No more tracking so kill the event listener so we're not being polled needlessly
						this.engine.entities.events.off('afterMove', this.bind(this._targetMoved));
					}
				}
			}
		}
	},
	
	/** _targetMoved - Called when an entity currently being tracked emits an afterMove event. {
		category:"method",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity that just moved.",
			link:"entityData",
		}],
	} **/
	_targetMoved: function (entity) {
		// Check for a tracking array for this entity
		if (this.tracking[entity.entity_id]) {
			// Loop through the list and update the tracking cams to look at this entity
			var camCount = this.tracking[entity.entity_id].length;
			
			while (camCount--) {
				var camera = this.tracking[entity.entity_id][camCount];
				
				// Get the cam to look at the entity
				this.translate(camera, entity._transform[0] + camera.tracking_offset[0], entity._transform[1] + camera.tracking_offset[1]);
			}
		}
	},
	
	/** lookAt - *DEPRECIATED* Sets the camera position to center on the specified co-ordinates. {
		category:"method",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to position.",
			link:"cameraData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate to center the camera on.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate to center the camera on.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate to center the camera on.",
		}],
	} **/
	lookAt: function (camera, x, y, z) {
		this.log('lookAt() has been depreciated and will no longer operate, please use translate() instead (1.0.0b).', 'warning', null, true);
		return;
	},
	
	/** lookBy - *DEPRECIATED* Sets the camera position to center on the specified co-ordinates by
	adding the passed co-ordinates to the current camera position. {
		category:"method",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to position.",
			link:"cameraData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate to add to the current x position.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate to add to the current y position.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate to add to the current z position.",
		}],
	} **/
	lookBy: function (camera, x, y, z) {
		this.log('lookBy() has been depreciated and will no longer operate, please use translate() instead (1.0.0b).', 'warning', null, true);
		return;
	},
	
	/** panTo - *DEPRECIATED* Pans the camera from its current position to the specified position
	in the speed passed in milliseconds. {
		category:"method",
		engine_ver:"0.3.0",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to pan.",
			link:"cameraData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate to center the camera on.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate to center the camera on.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate to center the camera on.",
		}, {
			type:"integer",
			name:"speedMs",
			desc:"The time in milliseconds to finish the pan in.",
		}],
	} **/
	panTo: function (camera, x, y, z, timeMs) {
		this.log('panTo() has been depreciated and will no longer operate, please use tweenStart() instead (1.0.0b).', 'warning', null, true);
		return;
	},
	
	/** setScale - *DEPRECIATED* Scales the camera's view. {
		category:"method",
		engine_ver:"0.3.0",
		arguments: [{
			type:"object",
			name:"camera",
			desc:"The camera to set the zoom scale for.",
			link:"cameraData",
		}, {
			type:"float",
			name:"newScaleX",
			desc:"The new scale value.",
		}],
	} **/
	setScale: function (camera, newScaleX, newScaleY) {
		this.log('setScale() has been depreciated and will no longer operate, please use scale() instead (1.0.0b).', 'warning', null, true);
		return;
	},
	
	/** _doAutoScale - Loops all the cameras and checks if they need auto-scaling
	because the viewport they are looking at has resized. {
		category:"method",
		engine_ver:"0.3.0",
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that has just been resized.",
			link:"viewportData",
		}],
	} **/
	_doAutoScale: function (viewport) {
		var arr = this.byIndex;
		var count = arr.length;
		
		while (count--) {
			var camera = arr[count];
			if (camera.$local.$viewport == viewport) {
				// This camera is looking at the viewport that just got resized
				if (camera.camera_autoscale && (camera.camera_width || camera.camera_height)) {
					// This camera is set to autoscale
					var finalWidth = 0;
					var finalHeight = 0;
					
					var vpWidthHeightRatio = viewport.$local.$width / viewport.$local.$height;
					
					if (camera.camera_width) {
						finalWidth = camera.camera_width;
					}
					
					if (camera.camera_height) {
						finalHeight = camera.camera_height;
					}
					
					if (!camera.camera_width) {
						// Auto-calculate the width
						finalWidth = camera.camera_height * vpWidthHeightRatio;
					}
					
					if (!camera.camera_height) {
						// Auto-calculate the height
						finalHeight = camera.camera_width / vpWidthHeightRatio;
					}
					
					var camToVpWidthRatio = viewport.$local.$width / finalWidth;
					var camToVpHeightRatio = viewport.$local.$height / finalHeight;
					
					camera.$local.$autoScaleWidth = finalWidth;
					camera.$local.$autoScaleHeight = finalHeight;
					camera.$local.$autoScaleRatioX = camToVpWidthRatio;
					camera.$local.$autoScaleRatioY = camToVpHeightRatio;
					
					this.scale(camera, camToVpWidthRatio, camToVpHeightRatio, 1);
				}
			}
		}
	},
	
	/** _afterTranslate - Called by the IgeTransform class after a camera
	has been translated. Updates some viewport specific cache values. {
		category:"method",
		engine_ver:"0.3.0",
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The camera that has just been translated.",
			link:"cameraData",
		}],
	} **/
	_afterTranslate: function (pItem) {
		if (pItem.$local) {
			if (!pItem.$local.$viewport.viewport_hide) {
				this.engine.viewports.updateViewportPreCalc(pItem.$local.$viewport);
				//this.engine.viewports.clearDirtySections(pItem.$local.$viewport);
				//this.engine.viewports.markViewportSectionDirty(pItem.$local.$viewport, xDiff, yDiff);
				//this.engine.viewports._setCleanSectionMove(pItem.$local.$viewport, xDiff, yDiff);
				this.engine.viewports.requestEntityData(pItem.$local.$viewport);
				this.engine.viewports.makeViewportDirty(pItem.$local.$viewport);
			}
		} else {
			this.log('Camera $local not available!', 'warning', camera);
		}
	},
	
	/** _afterScale - Called by the IgeTransform class after a camera
	has been scaled. Updates some viewport specific cache values. {
		category:"method",
		engine_ver:"0.3.0",
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The camera that has just been scaled.",
			link:"cameraData",
		}],
	} **/
	_afterScale: function (pItem) {
		this.engine.viewports.updateViewportPreCalc(pItem.$local.$viewport);
		this.engine.viewports.requestEntityData(pItem.$local.$viewport);
		this.engine.viewports.makeViewportDirty(pItem.$local.$viewport);
	},
});