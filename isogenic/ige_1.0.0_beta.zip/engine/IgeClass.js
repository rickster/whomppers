/*
	Isogenic Game Engine - Class generator
	--------------------------------------
	
	This code is part of the Isogenic Game Engine, however it is released
	under a separate license from other parts of the engine and can be used,
	reproduced, copied and distributed for all types of projects.
	
	Rob Evans
	Irrelon Software Limited
	http://www.isogenicengine.com
	------------------------------------------------------------------------
	
	Usage:
	
	// Define a new class
	var YourClass = new IgeClass({
		
		_tx: null, // Simple property
		
		init: function (arg1, arg2) {
			
			// Your constructor code here
			
		},
		
		setTx: function (tx) {
			
			// A simple method
			this._tx = tx;
			console.log(tx);
			
		},
		
		getTx: function () {
			
			return this._tx;
			
		}
		
	});
	
	// Create a new instance of your class
	var classInstance = new YourClass(arg1, arg2);
*/

/** IgeClass - Allows the creation of classes that follow the same definition
as MooTools classes without the MooTools dependency. {
	category:"class",
	externalLibs:[{
		name:"colors",
		desc:"Add Coloured Console Output",
		url:"https://github.com/Marak/colors.js",
	}],
	examples:[{
		name:"Create a New Class",
		desc:"Defines a new class and then creates a class instance, passing the engine as an argument.",
		code:"<pre>
			MyNewClass = new IgeClass({
				init: function (engine) {
					// Store a reference to the engine
					this.ige = engine;
					
					// Log something to show we've done an init() call
					this.log('Class init() method called.');
				},
			});
			
			// Create a new class instance
			var myNewClassInstance = new MyNewClass(this.ige);
		</pre>",
	}, {
		name:"Create a New Class With a Custom Method",
		desc:"Defines a new class with a custom method in it and then creates a class instance, passing the engine as an argument. Then calls the custom method.",
		code:"<pre>
			MyNewClass = new IgeClass({
				init: function (engine) {
					// Store a reference to the engine
					this.ige = engine;
					
					// Log something to show we've done an init() call
					this.log('Class init() method called.');
				},
				
				doSomeMath: function (a, b, c) {
					var total = a + b + c;
					this.log('Did a bit of math: ' + total);
				},
			});
			
			// Create a new class instance
			var myNewClassInstance = new MyNewClass(this.ige);
			myNewClassInstance.doSomeMath(1, 5, 3); // Outputs "Did a bit of math: 9"
		</pre>",
	}, {
		name:"Create a New Class That Extends Another Class",
		desc:"Defines a new class that extends the IgeEvents class to add event capability to the new class.",
		code:"<pre>
			MyNewClass = new IgeClass({
				Extends: [IgeEvents],
				
				init: function (engine) {
					// Store a reference to the engine
					this.ige = engine;
					
					// Log something to show we've done an init() call
					this.log('Class init() method called.');
				},
				
				doSomeMath: function (a, b, c) {
					var total = a + b + c;
					this.log('Did a bit of math: ' + total);
					
					// Emit an event with the total and the original values as arguments
					this.emit('didSomeMath', [total, a, b, c]);
				},
			});
			
			// Create a new class instance
			var myNewClassInstance = new MyNewClass(this.ige);
			
			// Hook the event 'didSomeMath' from the new class
			myNewClassInstance.on('didSomeMath', function (arg1, arg2, arg3, arg4) {
				console.log('We just received an event with the arguments:', arg1, arg2, arg3, arg4);
			});
			
			// Call our custom class method
			myNewClassInstance.doSomeMath(1, 5, 3); // Outputs "Did a bit of math: 9"
		</pre>",
	}],
} **/
IgeClass = function (params) {
	var newClass = this.create(params);
	
	if (params['Depends'])
	{
		this.loadDepends(params['Depends']);
	} else {
		// Check if the class extends any other class
		if (params['Extends']) {
			// If the extends parameter is an array or string
			if (typeof(params['Extends']) == 'function') {
				// The extend is a single string item
				this.process(newClass, params['Extends'].prototype);
				
				// Call the init method of the class we're extending
				// and apply the context of the new class
				if (typeof(params['Extends'].prototype.init) == 'function') {
					params['Extends'].prototype.init.apply(newClass.prototype);
				}
			}
			if (params['Extends'] instanceof Array) {
				// The extends is an array of classes so loop it and extend
				var extendArray = params['Extends'];
				for (var i = 0; i < extendArray.length; i++) {
					if (extendArray[i] && extendArray[i].prototype) {
						// Extend from this prototype
						this.process(newClass, extendArray[i].prototype);
						
						// Call the init method of the class we're extending
						// and apply the context of the new class
						if (typeof(extendArray[i].prototype.init) == 'function') {
							extendArray[i].prototype.init.apply(newClass.prototype);
						}
					} else {
						this.log('Cannot extend class because class prototype does not exist.', 'error');
					}
				}
			}
		}
		
		this.process(newClass, params);
	}
	
	// Return our new class
	return newClass;
};

/** create - Creates a new class from the passed object. {
	category:"method",
	arguments:[{
		name:"params",
		type:"object",
		desc:"The class definition object.",
	}],
} **/
IgeClass.prototype.create = function (params) {
	return function () {
		this.bind = IgeClass.prototype.bind;
		this.log = IgeClass.prototype.log;
		this.options = {};
		this.enableOption = IgeClass.prototype.enableOption;
		this.disableOption = IgeClass.prototype.disableOption;
		this.toggleOption = IgeClass.prototype.toggleOption;
		this.setOption = IgeClass.prototype.setOption;
		
		params['init'].apply(this, arguments);
		this.safeCall = IgeClass.prototype.safeCall;
		this.absorbClass = IgeClass.prototype.absorbClass;
	} || function () {};
};

/** enableOption - Sets an option in the this.options object to true. {
	category:"method",
	arguments:[{
		name:"option",
		type:"string",
		desc:"The option name.",
	}, {
		name:"obj",
		type:"object",
		desc:"An object to use instead of the this.options object.",
		flags:"optional",
	}],
} **/
IgeClass.prototype.enableOption = function (option, obj) {
	if (typeof(obj) == 'object') {
		obj[option] = true;
	} else {
		this.options[option] = true;
	}
};

/** disableOption - Sets an option in the this.options object to false. {
	category:"method",
	arguments:[{
		name:"option",
		type:"string",
		desc:"The option name.",
	}, {
		name:"obj",
		type:"object",
		desc:"An object to use instead of the this.options object.",
		flags:"optional",
	}],
} **/
IgeClass.prototype.disableOption = function (option, obj) {
	if (typeof(obj) == 'object') {
		obj[option] = false;
	} else {
		this.options[option] = false;
	}
};

/** toggleOption - Sets an option in the this.options object to 
the opposite boolean value to its current value. {
	category:"method",
	arguments:[{
		name:"option",
		type:"string",
		desc:"The option name.",
	}, {
		name:"obj",
		type:"object",
		desc:"An object to use instead of the this.options object.",
		flags:"optional",
	}],
} **/
IgeClass.prototype.toggleOption = function (option, obj) {
	if (typeof(obj) == 'object') {
		obj[option] = !obj[option];
	} else {
		this.options[option] = !this.options[option];
	}
};

/** setOption - Sets an option in the this.options object to 
a new value. {
	category:"method",
	arguments:[{
		name:"option",
		type:"string",
		desc:"The option name.",
	}, {
		name:"value",
		type:"multi",
		desc:"The value to set the option to.",
		flags:"optional",
	}, {
		name:"obj",
		type:"object",
		desc:"An object to use instead of the this.options object.",
		flags:"optional",
	}],
} **/
IgeClass.prototype.setOption = function (option, value, obj) {
	if (typeof(obj) == 'object') {
		obj[option] = value;
	} else {
		this.options[option] = value;
	}
};

/** loadDepends - *NON-FUNCTIONAL* Load any scripts that this class depends on. {
	category:"method",
	arguments:[{
		name:"depends",
		type:"array",
		desc:"The array of script paths to load.",
	}],
} **/
IgeClass.prototype.loadDepends = function (depends) {
	var script = new IgeElement('script', {src: source, type: 'text/javascript'});	
};

/** loadDepends - Process passed parameters and add them to newClass.prototype. {
	category:"method",
	arguments:[{
		name:"newClass",
		type:"object",
		desc:"The new class object to process.",
	}, {
		name:"params",
		type:"object",
		desc:"The parameters to apply to the new class.",
	}],
} **/
IgeClass.prototype.process = function (newClass, params) {
	for (var param in params) {
		switch (typeof params[param]) {
			case 'function' && param != 'initialize' && param != 'Extends':
				newClass.prototype[param] = params[param];
			break;
			
			default:
				newClass.prototype[param] = params[param];
			break;
		}
	}
	
	return newClass;
};

/** absorbClass - Process passed parameters and add them to this.prototype except
where the param already exists in this. {
	category:"method",
	arguments:[{
		name:"params",
		type:"object",
		desc:"The parameters to apply to the prototype object.",
	}],
} **/
IgeClass.prototype.absorbClass = function (params) {
	//console.log('Absorbing...', this._className, params['networkProvider']);
	for (var param in params)
	{
		if (typeof(this[param]) == 'undefined') {
			switch (typeof(params[param]))
			{
				
				case 'function' && param != 'initialize' && param != 'Extends':
					this[param] = params[param];
				break;
				
				default:
					this[param] = params[param];
				break;
				
			}
		}
		
	}
	
};

/** bind - Create a new method that will call the passed method in the current
context. {
	category:"method",
	arguments:[{
		name:"Method",
		type:"function",
		desc:"The method to create within the current context.",
	}, {
		name:"ignoreNullMethod",
		type:"bool",
		desc:"Set to true to ignore when the passed method is not a funciton. When false (default) a warning message will be output to the console if the method is null.",
	}],
} **/
IgeClass.prototype.bind = function(Method, ignoreNullMethod) {
	
	if (typeof Method == 'function') {
		var _this = this;
		return(
			function(){
				return( Method.apply( _this, arguments ) );
			}
		);
	} else {
		if (!ignoreNullMethod) {
			this.log('An attempt to use bind against a method that does not exist was made!', 'warning');
		}
		return (function () { });
	}
	
};

/** safeCall - Attempts to call the method specified by the methodName
argument in the passed obj object but if the method does not exist no
error will be thrown. {
	category:"method",
	arguments:[{
		name:"obj",
		type:"object",
		desc:"The object that the method will be called from.",
	}, {
		name:"methodName",
		type:"string",
		desc:"The name of the method to call.",
	}, {
		name:"args",
		type:"array",
		desc:"An array of arguments to pass to the method.",
	}],
} **/
IgeClass.prototype.safeCall = function (obj, methodName, args) {
	if (obj && typeof obj[methodName] == 'function') {
		return obj[methodName].apply(obj, args || []);
	} else {
		// No method
		//this.log('Cannot call method "' + methodName + '" of passed object.', 'info');
		return false;
	}
};

/** log - Logs the param argument to the console based upon the level parameter. {
	category:"method",
	arguments:[{
		name:"param",
		type:"string",
		desc:"The string to log to the console.",
	}, {
		name:"level",
		type:"string",
		desc:"The log level to output the console message as.",
		flags:"optional",
		valueOf:{
			'log': {
				type:"string",
				desc:"Outputs a standard log line.",
			},
			'info': {
				type:"string",
				desc:"Outputs a standard log line.",
			},
			'warning': {
				type:"string",
				desc:"Outputs a warning line and a stack trace by default.",
			},
			'depreciated': {
				type:"string",
				desc:"Outputs a standard log line and a stack trace by default.",
			},
			'error': {
				type:"string",
				desc:"Outputs an error line and a stack trace by default. Also ends the Node.js process (server-side) by default.",
			},
		},
	}, {
		name:"obj",
		type:"array",
		desc:"An object to output just before the console message.",
		flags:"optional",
	}, {
		name:"ignoreStack",
		type:"bool",
		desc:"When set to true will not output a stack trade for warning and error level messages.",
		flags:"optional",
	}],
} **/
IgeClass.prototype.log = function (param, level, obj, ignoreStack) {
	var dtObj = new Date();
	var dt = '[' + dtObj.toDateString() + ' ' + dtObj.toTimeString().substr(0,8) + '] ';
	
	var output = '';
	var debugOn = false;
	var debugLevel = [];
	var breakOnError = false;
	var isServer = false;
	var isSandboxed = false;
	
	if (!level) { level = 'info'; }
	//console.log('moo', typeof this.ige);
	if ((this.engine && this.engine.config) || (this.config && this.config.debug) || (typeof(window) === 'undefined' && typeof(this.ige) == 'object') || this.isNode) {
		/* CEXCLUDE */
		if (this.engine != null) { 
			// Use settings from engine config
			debugOn = this.engine.config.debug;
			debugLevel = this.engine.config.debugLevel;
			breakOnError = this.engine.config.debugBreakOnError;
			isSandboxed = this.engine.config.sandbox;
		} else if (this.config != null) {
			// Use settings from config
			debugOn = this.config.debug;
			debugLevel = this.config.debugLevel;
			breakOnError = this.config.debugBreakOnError;
			isSandboxed = this.config.sandbox;
		} else if (typeof this.ige == 'object') {
			// Use settings from ige config
			debugOn = this.ige.config.debug;
			debugLevel = this.ige.config.debugLevel;
			breakOnError = this.ige.config.debugBreakOnError;
			isSandboxed = this.ige.config.sandbox;
		} else {
			// Set some defaults
			debugOn = true;
			debugLevel = ['info', 'warning', 'error', 'log'];
			breakOnError = true;
			isSandboxed = true;
		}
		var color = require(igeConfig.mapUrl('/node_modules/colors'));
		isServer = true;
		/* CEXCLUDE */
	} else {
		// Client-side debugging
		debugOn = window.igeDebug;
		debugLevel = window.igeDebugLevel;
		breakOnError = window.igeDebugBreakOnError;
	}
	if (!isSandboxed) {
		
		var className = this._className || "Unnamed Class";
			
		if (debugOn && valueIn(level, debugLevel))
		{
			
			if (console != null) {
				switch (level)
				{
					
					case 'log':
						if (obj) { console.log(obj); }
						
						if (isServer) {
							output = color.magenta(dt) + color.white("IGE ") + color.cyan("*" + level + "*") + color.yellow(" [" + className + "]") + " :";
						} else {
							output = dt + "IGE *" + level + "* [" + className + "] :";
						}
						
						console.log(output);
						console.log(param);
					break;
					
					case 'info':
						if (obj) { console.log(obj); }
						if (isServer) {
							output = color.magenta(dt) + color.white("IGE ") + color.cyan("*" + level + "*") + color.yellow(" [" + className + "]") + " : " + param;
						} else {
							output = dt + "IGE *" + level + "* [" + className + "] : " + param;
						}
						
						console.info(output);
					break;
					
					case 'warning':
						if (!ignoreStack) {
							if (isServer) {
								var stack = new Error().stack;
								console.log(color.magenta('Stack:'), color.red(stack));
							} else {
								if (typeof printStackTrace == 'function') {
									console.log('Stack:', printStackTrace().join('\n ---- '));
								}
							}
						}
						if (obj) { console.log(obj); }
						
						if (isServer) {
							output = color.magenta(dt) + color.white("IGE ") + color.magenta("*" + level + "*") + color.yellow(" [" + className + "]") + " : " + color.magenta(param);
						} else {
							output = dt + "IGE *" + level + "* [" + className + "] : " + param;
						}
						
						console.warn(output);
					break;
					
					case 'depreciated':
						if (!ignoreStack) {
							if (isServer) {
								var stack = new Error().stack;
								console.log(color.magenta('Stack:'), color.red(stack));
							} else {
								if (typeof printStackTrace == 'function') {
									console.log('Stack:', printStackTrace().join('\n ---- '));
								}
							}
						}
						if (obj) { console.log(obj); }
						
						if (isServer) {
							output = color.magenta(dt) + color.white("IGE ") + color.magenta("*" + level + "*") + color.yellow(" [" + className + "]") + " : " + color.magenta(param);
						} else {
							output = dt + "IGE *" + level + "* [" + className + "] : " + param;
						}
						
						console.warn(output);
					break;
					
					case 'error':
						if (!ignoreStack) {
							if (isServer) {
								var stack = new Error().stack;
								console.log(color.magenta('Stack:'), color.red(stack));
							} else {
								if (typeof printStackTrace == 'function') {
									console.log('Stack:', printStackTrace().join('\n ---- '));
								}
							}
						}
						if (obj) { console.log(obj); }
						
						if (isServer) {
							output = color.magenta(dt) + color.white("IGE ") + color.red("*" + level + "*") + color.yellow(" [" + className + "]") + " : " + color.red(param);
						} else {
							output = dt + "IGE *" + level + "* [" + className + "] : " + param;
						}
						
						if (breakOnError) {
							throw(output);
						} else {
							console.log(output);
						}
					break;
				}
			}
		}
	}
};

/** valueIn - Checks if a value is contained in an array. {
	category:"method",
	arguments:[{
		name:"value",
		type:"multi",
		desc:"The value to check the array for.",
	}, {
		name:"arr",
		type:"array",
		desc:"The array to check the value for.",
	}],
} **/
var valueIn = function (value, arr) {
	for (var index =0; index < arr.length; index++) {
		if (arr[index] == value) { return true; }
	}
	
	return false;
};