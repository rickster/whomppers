IgeHeightmap = new IgeClass({

	Extends: [IgeCollection, IgeNetworkItem, IgeItem, IgeEvents],
	engine: null,

	/* init - Constructor, takes the engine object as the parameter. */
	init: function (engine) {
		this._className = 'IgeHeightmap';
		
		this.waterlevel = 3; //engine.config.waterlevel;
		this.waterlevels = 3; //engine.config.waterlevels;
		this.engine = engine;
		this.collectionId = 'heightmap';
		this.entities = this.engine.entities;
	},
	
	engineHooks: function () {
		this.engine.on('afterCanvasBasedCreate', this.bind(this.viewportNewHitmap));
		this.engine.on('afterCanvasBasedResize', this.bind(this.viewportNewHitmap));
	},
	
	viewportNewHitmap: function (viewport, panLayer, layerLevel) {
		var hitmapLayer = $('<canvas></canvas>');
		hitmapLayer.attr('id', viewport.viewport_id + '_hitmap');
		hitmapLayer.attr('width', viewport.panLayer.width);
		hitmapLayer.attr('height', viewport.panLayer.height);
		
		hitmapLayer.css('position', 'relative');
		hitmapLayer.css('width', viewport.panLayer.width + 'px');
		hitmapLayer.css('height', viewport.panLayer.height + 'px');
		hitmapLayer.css('display', 'none');
		hitmapLayer.css('opacity', 0.4);
		hitmapLayer.css('top', -(0 + (layerLevel * viewport.panLayer.height)) + 'px');
		hitmapLayer.css('zIndex', 6);
		
		panLayer.append(hitmapLayer);
		
		viewport.$local.$hitMap = hitmapLayer;
		viewport.$local.$hitMapCtx = this.engine.viewports._canvasContext(hitmapLayer[0]);
	},
	
	viewportHitmapResize: function (viewport, panLayer, width, height, layerLevel) {
		var hmElem = $('#' + viewport.viewport_id + '_hitmap');
		
		hitmapLayer.css('width', viewport.panLayer.width + 'px');
		hitmapLayer.css('height', viewport.panLayer.height + 'px');
		hitmapLayer.css('top', -(0 + (layerLevel * viewport.panLayer.height)) + 'px');
	},
	
	_create: function (entity, callback) {
		/* CEXCLUDE */
		if (this.engine.isServer) {
			if (entity.south -4 < entity.north) { // is the tile not obscuring itself?
				// add the corner elevation to the entity_z
				var orig_entity_z = entity.entity_z;
				entity.entity_z += Math.max(entity.north, entity.east - 2, entity.west - 2, entity.south - 4);
				
				var qsize = this.engine.maxheightdelta + 1;
				var lines = (entity.east * qsize) + entity.west;
				var templates = lines * qsize * qsize;
				var line = (entity.north * qsize) + entity.south;
				entity.asset_sheet_frame =  templates + line + 1;
				
				this.entities.create(entity, this.bind(function(justCreatedEntity) {
					var maxHeight = Math.max(entity.north, entity.east, entity.west, entity.south);
					//console.log(entity.entity_x+'/'+entity.entity_y+'/'+entity.entity_z);
					for(var i = this.waterlevel; i >= (this.waterlevel-this.waterlevels); i--) {
						if(i > orig_entity_z){
							var water = {};
							// can we shortcut to a simple square, to keep the html map form downloading similar tiles with different names
							if (i > entity.entity_z) {
								water.asset_sheet_frame = 1;
								water.template_id = 'water_0';
							} else {
								water.asset_sheet_frame = entity.asset_sheet_frame;
								water.template_id = 'water_' + (i - orig_entity_z);
							}
					
							water.entity_x = entity.entity_x;
							water.entity_y = entity.entity_y;
							water.entity_z = i;
							water.drawdepthoffset = maxHeight;
							water.north = water.east = water.south = water.west = 0;
							water.map_id = entity.map_id;
							water.entity_locale = entity.entity_locale;
							water.opacity = .3;//this.engine.config.planeopactiy;
							//console.log('@'+i+'gets'+water.template_id+'.'+water.asset_sheet_frame);
							this.entities.create(water, callback);
						}
					}
				}));
			}
		}
		/* CEXCLUDE */
	},
});

// Global function
function dec2hex(i)
{
  var result = "0000";
  if      (i >= 0    && i <= 15)    { result = "00000" + i.toString(16); }
  else if (i >= 16   && i <= 255)   { result = "0000"  + i.toString(16); }
  else if (i >= 256  && i <= 4095)  { result = "000"   + i.toString(16); }
  else if (i >= 4096 && i <= 65535) { result = "00"    + i.toString(16); }
  else if (i >= 65536  && i <= 1048575)  { result = "0"+ i.toString(16); }
  else if (i >= 1048576 && i <= 16777215) { result =     i.toString(16); }
  return result
}