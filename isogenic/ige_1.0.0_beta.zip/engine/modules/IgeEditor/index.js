IgeEditor = new IgeClass({
	Extends: [IgeEvents, IgeState],
	
	init: function (engine) {
		this._className = 'IgeEditor';
		
		// Store engine instance
		this.ige = engine;
		
		// Register ourselves in the engine instance
		this.ige.editor = this;
		
		if (!this.ige.isServer) {
			// Load the treeview plugin
			$('<script id="jQuery_treeView" type="text/javascript" src="./engine/modules/IgeEditor/js/jquery.jstree.js" />').appendTo("head");
			$('<link rel="stylesheet" href="./engine/modules/IgeEditor/css/main.css" type="text/css" media="screen" />').appendTo("head");
			
			// Load the editor HTML interface into the DOM
			$.ajax({
				url: './engine/modules/IgeEditor/html/panel.htm',
				success: this.bind(function (data) {
					this.log('Editor interface HTML loaded!');
					
					// Append the html to the body
					$('body').append($(data));
					
					// Create the treeview
					this._createTreeview();
					
					// Set state to ready
					this.state(1);
				}),
				dataType: 'html',
				error: this.bind(function () { this.log('Error loading editor interface HTML!', 'error', arguments); }),
			});
			
			// Hook all the engine crud operations
			this._hookEvents();
		}
	},
	
	_hookEvents: function () {
		this.ige.animations.on('afterCreate', this.bind(this._onCreate));
		this.ige.assets.on('afterCreate', this.bind(this._onCreate));
		this.ige.backgrounds.on('afterCreate', this.bind(this._onCreate));
		this.ige.cameras.on('afterCreate', this.bind(this._onCreate));
		this.ige.entities.on('afterCreate', this.bind(this._onCreate));
		this.ige.maps.on('afterCreate', this.bind(this._onCreate));
		this.ige.screens.on('afterCreate', this.bind(this._onCreate));
		this.ige.templates.on('afterCreate', this.bind(this._onCreate));
		this.ige.viewports.on('afterCreate', this.bind(this._onCreate));
	},
	
	_createTreeview: function () {
		$.jstree._themes = "./engine/modules/IgeEditor/js/themes/";
		$("#IgeEditor .tree").jstree({
			'core': {
				'animation': 0,
			},
			"themes" : {
				"theme" : "classic",
				"dots" : true,
				"icons" : false
			},
			"json_data" : {
				"data" : [
					{
						"data" : "IGE",
						state:'open',
						'metadata':'ige',
						"children": [
							{'data': 'Animations', attr:{id:'animations'}, 'metadata':'ige.animations'},
							{'data': 'Assets', attr:{id:'assets'}, 'metadata':'ige.assets'},
							{'data': 'Backgrounds', attr:{id:'backgrounds'}, 'metadata':'ige.backgrounds'},
							{'data': 'Cameras', attr:{id:'cameras'}, 'metadata':'ige.cameras'},
							{'data': 'Entities', attr:{id:'entitys'}, 'metadata':'ige.entities'},
							{'data': 'Maps', attr:{id:'maps'}, 'metadata':'ige.maps'},
							{'data': 'Screens', attr:{id:'screens'}, 'metadata':'ige.screens'},
							{'data': 'Templates', attr:{id:'templates'}, 'metadata':'ige.templates'},
							{'data': 'Viewports', attr:{id:'viewports'}, 'metadata':'ige.viewports'},
						]
					},
				],
				"progressive_render" : true
			},
			"plugins" : [ "themes", "json_data" ]
		});
	},
	
	_onCreate: function (pItem) {
		var itemType = this.ige.itemType._reverse[pItem._itemType];
		this.log('Engine created ' + itemType + ': ' + pItem[itemType + '_id']);
		
		$('#IgeEditor .tree').jstree("create_node", $('#' + itemType + 's'), 'inside', {data:pItem[itemType + '_id'], attr: {id: pItem[itemType + '_id']}});
		$('#IgeEditor .tree').jstree("open_node", $('#' + itemType + 's'));
	},
});