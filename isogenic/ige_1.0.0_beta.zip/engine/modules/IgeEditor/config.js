var config = {
	moduleName: 'IgeEditor',
	serverSide: true,
	clientSide: true,
}