/** IgeItem - Provides item management methods and events to extending classes. 
This class is designed to be extended and does not do anything by itself. {
	category:"class",
} **/
IgeItem = new IgeClass({
	init: function () {},
	
	/** create - Creates a new item. {
		category:"method",
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item to be created.",
		}, {
			type:"method",
			name:"pCb",
			desc:"A callback method to be called when the item has been successfully created.",
			flags:"optional",
		}],
	} **/
	create: function (pItem, pCb) {
		// Apply an item type if it exists
		if (typeof(this.engine.itemType[this.collectionId]) != 'undefined') {
			pItem._itemType = this.engine.itemType[this.collectionId];
		}
		
		// Apply templates (ensuring that if the item is a template itself, the
		// template is NOT applied... since that would be bad... very bad! Think
		// infinite loop bad.)
		if (pItem.template_id && typeof(pItem.template_contents) == 'undefined') {
			this.engine.templates.applyTemplate(pItem);
		}
		
		// Ensure defaults
		if (this.safeCall(this, '_itemDefaults', [pItem]) == true) {
			// Ensure our own defaults
			this.ensureLocalExists(pItem);
			/* CEXCLUDE */
			if (this.engine.isServer) { this.ensurePersistExists(pItem); }
			/* CEXCLUDE */
			
			// If there is a callback, store it
			if (typeof(pCb) == 'function') {
				// The callback is a function so store it in the item object for later use
				pItem.$local.create_callback = pCb;
			}
			
			// Check integrity
			if (this.safeCall(this, '_itemIntegrity', [pItem]) == true || typeof(this._itemIntegrity) != 'function') {
				// Ensure that the item has an id!
				if (pItem[this.collectionId + '_id']) {
					
					// Emit the beforeCreate event and act upon a cancel request
					if (!this.emit('beforeCreate', pItem)) {
						// No receiver methods requested a cancel operation so
						// check if this class has propagation
						if (typeof(this._propagate) == 'function') {
							// Pass it to propagation
							this._propagate(pItem, PROPAGATE_CREATE);
						} else {
							// No propagation enabled in this class so just create the item!
							this._create(pItem);
						}
					} else {
						// Call the callback with no argument meaning there was a cancellation or error
						if (typeof (pCb) == 'function') { pCb(); }
					}
				} else {
					this.log('Cannot create item because it has no id! (IgeItem)', 'warning', pItem);
				}
			} else {
				//this.log('Bugging out of create because the item failed an integrity check!', 'warning', pItem);
			}
		}
	},
	
	/** read - Returns the object whose id is passed, or if an object is passed, will
	return the object with the id that matches the object's property collectionId + '_id'. {
		category:"method",
		engine_ver:"0.2.2",
		return: {
			type:"object",
			desc:"Returns the corresponding object to the passed parameter or false on error.",
		},
		arguments: [{
			type:"multi",
			name:"itemIdOrObj",
			desc:"Either an object or a string that identifies the object (by it's id) to return.",
		}],
	} **/
	read: function (itemIdOrObj) {
		// Check if the argument passed is null and return immediately if so
		if (itemIdOrObj == null) { return false; }
		// Check if the argument is an object or a string
		if (typeof(itemIdOrObj) == 'object') {
			// We have an object, see if we can get an id from it
			var obj = this.byId[itemIdOrObj[this.collectionId + '_id']];
			if (typeof(obj) == 'undefined') {
				return false;
			} else {
				return obj;
			}
		} else {
			// We have a string, see if the string matches an id for this collection
			var obj = this.byId[itemIdOrObj];
			if (typeof(obj) == 'undefined') {
				return false;
			} else {
				return obj;
			}
		}
	},
	
	/** update - Updates the class collection item with the matching id. The item is updated
	with all properties of the pItem parameter. DO NOT use this method to alter the position of
	an entity, use the IgeEntities translate() method instead. {
		category:"method",
		engine_ver:"0.2.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"multi",
			name:"pItem",
			desc:"The object containing update data.",
		}, {
			type:"object",
			name:"pData",
			desc:"The object containing update data.",
		}],
	} **/
	update: function (tpItem, pData, pCb) {
		// Check if the item and data are the same,
		// if so do not assign anything to them because
		// it will overwrite the pData by reference!
		/*
		if (pItem != pData) {
			var pItem = this.read(tpItem);
			if (pItem != pItemFinal) {
				pItem = pItemFinal;
			}
		}*/
		
		var pItem = this.read(tpItem);
		
		// Emit the beforeUpdate event and act upon a cancel request
		if (!this.emit('beforeUpdate', pItem)) {
			// No receiver methods requested a cancel operation
			if (typeof(pCb) == 'function') {
				// The callback is a function so store it in the item object for later use
				pItem.$local.update_callback = pCb;
			}
			
			if (typeof(this._update) == 'function') {
				this._update(pItem, pData);
			} else {
				this.log('Warning, attempting to update an item but no _update() method exists to process the update!', 'warning');
			}
			
			// Check if this class has propagation
			if (typeof(this._propagate) == 'function') {
				// Pass it to propagation
				this._propagate(pItem, PROPAGATE_UPDATE);
			} else {
				// No propagate method so just call the callback
				this.emit('afterUpdate', pItem);
				
				if (typeof(pItem.$local.update_callback) == 'function') {
					pItem.$local.update_callback(pItem);
					delete pItem.$local.update_callback;
				}
			}
		} else {
			// Call the callback with no argument meaning there was a cancellation or error
			if (typeof(pCb) == 'function') { pCb(); }
		}
	},
	
	/** remove - Removes an item from the engine based upon its _locale and _persist
	property values. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or null for any other reason.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be removed.",
			link:"entityData",
		}, {
			type:"method",
			name:"pCb",
			desc:"The method to call when the item has been successfully removed from the engine.",
			flags:"optional",
		}],
	} **/
	remove: function (pItem, pCb) {
		// Check if we were passed an array of items
		if (pItem.length && typeof(pItem[0]) == 'object') {
			var itemCount = pItem.length;
			while (itemCount--) {
				// If we are on the last item, attach the callback
				// if there is one
				if (itemCount == 0) {
					// Check if a callback was specified and if so, attach it to the item
					if (typeof(pCb) == 'function') {
						pItem[itemCount].$local.remove_callback = pCb;
					}
				}
				this.remove(pItem[itemCount]);
			}
		} else {
			var pItem2 = this.read(pItem);
			
			if (pItem2) {
				// Check if this class has propagation
				if (typeof(this._propagate) == 'function') {
					// Pass it to propagation
					this._propagate(pItem2, PROPAGATE_DELETE);
				} else {
					this._remove(pItem2);
				}
				
				// Check if a callback was specified and if so, attach it to the item
				if (typeof(pCb) == 'function') {
					pItem2.$local.remove_callback = pCb;
				}
			} else {
				//this.log('Cannot remove item because it could not be found', 'warning', pItem);
			}
		}
	},
	
	/** removeAll - Removes all items by passing each one to the remove() method. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"method",
			name:"pCb",
			desc:"The method to call when the item has been successfully removed from the engine.",
			flags:"optional",
		}],
	} **/
	removeAll: function (pCb) {
		for (var i in this.byIndex) {
			this.remove(this.byIndex[i]);
		}
		
		if (typeof(pCb) == 'function') {
			pCb();
		}
	},
	
	/* CEXCLUDE */
	/** ensurePersistExists - Takes an object and makes sure that the _persist property has a value,
	even if that value is just false. This makes sure that the database has a value to scan against
	when checking persist values. {
		category:"method",
		flags:"server",
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to check.",
		}],
	} **/
	ensurePersistExists: function (obj) {
		if (!obj[this.collectionId + '_persist']) { obj[this.collectionId + '_persist'] = PERSIST_DISABLED; }
	},
	/* CEXCLUDE */
	
	/** ensureIdExists - Takes an object and makes sure that the _id property has a value. If no value
	currently exists, a new ID is generated from the IgeFactory.js class method newId(). {
		category:"method",
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to check.",
		}],
	} **/	
	ensureIdExists: function (obj) {
		if (!obj[this.collectionId + '_id']) { obj[this.collectionId + '_id'] = this.engine.idFactory.newId(); }
	},
	
	/** ensureLocalExists - Takes an object and makes sure that the $local property
	is an object. If no value currently exists, a new object is assigned. {
		category:"method",
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to check.",
		}],
	} **/	
	ensureLocalExists: function (obj) {
		if (obj && typeof(obj.$local) != 'object') {
			obj.$local = {};
		}
	},
});