/** IgeNetwork_Packet - Defines methods for creating, encoding and
decoding network packet data. {
	category:"class",
} **/
IgeNetwork_Packet = new IgeClass({
	init: function () {},
	
	/** useBison - Sets a flag to determin if we are to encode and
	decode packets via bison. {
		category:"method",
		arguments:[{
			name:"flag",
			type:"bool",
			desc:"Set to true to use BISON encoding.",
		}],
	} **/
	useBison: function (flag) {
		this.log('Use BISON to encode / decode network packets: ' + flag);
		this._bisonEnabled = flag;
	},
	
	/** encodePacket - Creates, encodes and returns a new network packet's data. {
		category:"method",
		return:{
			type:"object",
			desc:"The new encoded network packet object.",
		},
		arguments:[{
			name:"cmdId",
			type:"integer",
			desc:"The command id of the command the packet will contain.",
		}, {
			name:"data",
			type:"object",
			desc:"Data to encode as part of the packet.",
		}],
	} **/
	encodePacket: function (cmdId, data) {
		// Check if we need to manifest compress
		if (this._manifestEnabled && typeof(data) == 'object') {
			// Replace each instance of a property name with it's new index
			var objectJson = JSON.stringify(data);
			var propIndex = this._manifest._reverse;
			for (var i in propIndex) {
				var regex1 = new RegExp('"' + propIndex[i] + '"', 'g');
				objectJson = objectJson.replace(regex1, 'º' + i + '');
			}
			
			// Replace true and false with 1 and 0 to get compression of those values
			var regex = new RegExp(':true', 'g');
			objectJson = objectJson.replace(regex, ':1');
			
			var regex = new RegExp(':false', 'g');
			objectJson = objectJson.replace(regex, ':0');
			
			data = 'º' + objectJson;
		}
		
		// Check if we need to BISON encode
		if (this._bisonEnabled) {
			return this.bison.encode(this._packet(cmdId, data));
		} else {
			return this._packet(cmdId, data);
		}
	},
	
	/** decodePacket - Returns decoded network packet data. {
		category:"method",
		return:{
			type:"object",
			desc:"The decoded network packet object.",
		},
		arguments:[{
			name:"packetData",
			type:"object",
			desc:"The network packet data to decode.",
		}],
	} **/
	decodePacket: function (packetData) {
		var tempPacket = null;
		
		// Check if we need to BISON decode
		if (this._bisonEnabled) {
			tempPacket = this.bison.decode(packetData);
		} else {
			tempPacket = packetData;
		}
		
		var data = tempPacket[2];
		
		// Check if we need to manifest decompress
		if (this._manifestEnabled && typeof(data) == 'string') {
			// Check if this string was originally encoded with manifest data
			if (data.substr(0, 1) == 'º') {
				// Remove the starting byte
				data = data.substr(1, data.length - 1);
				
				// Replace each instance of an index with it's property name
				var objectJson = data;
				var propIndex = this._manifest._reverse;
				for (var i in propIndex) {
					var regex1 = new RegExp('º' + i + ':', 'g');
					objectJson = objectJson.replace(regex1, '"' + propIndex[i] + '":');
					
					var regex2 = new RegExp('º' + i + ',', 'g');
					objectJson = objectJson.replace(regex2, '"' + propIndex[i] + '",');
					
					var regex3 = new RegExp('º' + i + '}', 'g');
					objectJson = objectJson.replace(regex3, '"' + propIndex[i] + '"}');
					
					var regex4 = new RegExp('º' + i + ']', 'g');
					objectJson = objectJson.replace(regex4, '"' + propIndex[i] + '"]');
				}
				
				/*
				if (this._statsEnabled) {
					var jData = JSON.parse(data);
					this._nonCompressed = this._nonCompressed || [];
					for (var i in jData) {
						if (i.substr(0, 1) != 'º' && i.length > 2 && (parseInt(i) != i)) {
							this._nonCompressed[i] = this._nonCompressed[i] || 0;
							this._nonCompressed[i]++;
						}
						if (typeof(jData[i]) == 'string' && jData[i].substr(0, 1) != 'º' && jData[i].length > 2 && (parseInt(jData[i]) != jData[i])) {
							this._nonCompressed[jData[i]] = this._nonCompressed[jData[i]] || 0;
							this._nonCompressed[jData[i]]++;
						}
					}
				}
				*/
				// Convert the JSON back into a real object
				try { data = JSON.parse(objectJson); } catch (err) { console.log(objectJson); }
				
				// We do not reverse the compression of the "true" and "false" values since
				// they should be OK mapping to == true and == false anyway with 1 and 0	
			}
		}
		
		return {cmdId:tempPacket[0].charCodeAt(0), msgTime: tempPacket[1], data: data};
	},
	
	/** _packet - Private method for returning a packet array. {
		category:"method",
		return:{
			type:"array",
			desc:"The packet array.",
		},
		arguments:[{
			name:"cmdId",
			type:"integer",
			desc:"The command id for the command to store in the packet.",
		}, {
			name:"data",
			type:"object",
			desc:"An object containing data to store in the packet.",
		}],
	} **/
	_packet: function (cmdId, data) {
		return [String.fromCharCode(cmdId), new Date().getTime(), data]
	},
	
	/** _nextSequenceId - Returns a new unique id for a packet. {
		category:"method",
		return:{
			type:"integer",
			desc:"The next unique sequence number.",
		},
	} **/
	_nextSequenceId: function () {
		return this._sequenceId++;
	},
});