/** IgeTween - Provides tweening methods to any item generated in a class
that extends IgeTransform and this class. {
	category:"class",
	urls:[{
		name:"Easing equations converted from ActionScript to JavaScript from original source at",
		url:"http://robertpenner.com/easing/",
	}],
} **/

/** propertyTarget - An object of tween properties and the target values to tween to. {
	category:"definition",
	contents:{
		translateX:{
			type:"float",
			desc:"The x position co-ordinate to tween to.",
		},
		translateY:{
			type:"float",
			desc:"The y position co-ordinate to tween to.",
		},
		translateZ:{
			type:"float",
			desc:"The z position co-ordinate to tween to.",
		},
		scaleX:{
			type:"float",
			desc:"The x scale co-ordinate to tween to.",
		},
		scaleY:{
			type:"float",
			desc:"The y scale co-ordinate to tween to.",
		},
		scaleZ:{
			type:"float",
			desc:"The z scale co-ordinate to tween to.",
		},
		rotateX:{
			type:"float",
			desc:"The x rotation value to tween to. Please note that only the x value is used when the engine is in 2d or isometric view. The y and z values are ignored.",
		},
		rotateY:{
			type:"float",
			desc:"The y rotation value to tween to.",
		},
		rotateZ:{
			type:"float",
			desc:"The z rotation value to tween to.",
		},
		originX:{
			type:"float",
			desc:"The x origin co-ordinate to tween to.",
		},
		originY:{
			type:"float",
			desc:"The y origin co-ordinate to tween to.",
		},
		originZ:{
			type:"float",
			desc:"The z origin co-ordinate to tween to.",
		},
		opacityX:{
			type:"float",
			desc:"The x opacity value to tween to.Please note that only the x value is used when the engine is in 2d or isometric view. The y and z values are ignored.",
		},
		opacityY:{
			type:"float",
			desc:"The y opacity value to tween to.",
		},
		opacityZ:{
			type:"float",
			desc:"The z opacity value to tween to.",
		},
	}
} **/

/** tweenOptions - The options that can be passed to the tweenStart method. {
	category:"definition",
	contents:{
		startTime:{
			type:"integer",
			desc:"The time in milliseconds to start the tween from.",
			default:"Result of new Date().getTime();",
		},
		easing:{
			type:"string",
			desc:"The name of the easing method to apply to the tween. This is a string name, not a reference to the function! If you want to add your own function, add it to the  tweenEasing object and then use its name here.",
			default:"Defaults to easing.none which is a linear function.",
			valueOf: {
				'none': {
					type:"string",
					desc:"Basic linear function, effectively no easing.",
				},
				'inQuad': {
					type:"string",
					desc:"",
				},
				'inOutQuad': {
					type:"string",
					desc:"",
				},
				'inOutCubic': {
					type:"string",
					desc:"",
				},
				'outInCubic': {
					type:"string",
					desc:"",
				},
				'inQuart': {
					type:"string",
					desc:"",
				},
				'outQuart': {
					type:"string",
					desc:"",
				},
				'inOutQuart': {
					type:"string",
					desc:"",
				},
				'outInQuart': {
					type:"string",
					desc:"",
				},
				'inQuint': {
					type:"string",
					desc:"",
				},
				'outQuint': {
					type:"string",
					desc:"",
				},
				'inOutQuint': {
					type:"string",
					desc:"",
				},
				'outInQuint': {
					type:"string",
					desc:"",
				},
				'inSine': {
					type:"string",
					desc:"",
				},
				'outSine': {
					type:"string",
					desc:"",
				},
				'outInSine': {
					type:"string",
					desc:"",
				},
				'inExpo': {
					type:"string",
					desc:"",
				},
				'outExpo': {
					type:"string",
					desc:"",
				},
				'inOutExpo': {
					type:"string",
					desc:"",
				},
				'outInExpo': {
					type:"string",
					desc:"",
				},
				'inCirc': {
					type:"string",
					desc:"",
				},
				'outCirc': {
					type:"string",
					desc:"",
				},
				'inOutCirc': {
					type:"string",
					desc:"",
				},
				'outInCirc': {
					type:"string",
					desc:"",
				},
				'inElastic': {
					type:"string",
					desc:"",
				},
				'outElastic': {
					type:"string",
					desc:"",
				},
				'inOutElastic': {
					type:"string",
					desc:"",
				},
				'outInElastic': {
					type:"string",
					desc:"",
				},
				'inBack': {
					type:"string",
					desc:"",
				},
				'outBack': {
					type:"string",
					desc:"",
				},
				'inOutBack': {
					type:"string",
					desc:"",
				},
				'outInBack': {
					type:"string",
					desc:"",
				},
				'inBounce': {
					type:"string",
					desc:"",
				},
				'outBounce': {
					type:"string",
					desc:"",
				},
				'inOutBounce': {
					type:"string",
					desc:"",
				},
				'outInBounce': {
					type:"string",
					desc:"",
				},
			},
		},
	},
} **/
IgeTween = new IgeClass({
	/** init - The constructor for this class. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	init: function () {
		this._tweeners = [];
	},
	
	/** tweenStart - Start tweening a transform property based upon the current
	and target values. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to apply tweening to.",
		}, {
			name:"propertyTarget",
			type:"object",
			desc:"The propery names and their target values to tween with / to.",
			link:"propertyTarget",
		}, {
			name:"duration",
			type:"integer",
			desc:"The duration that the tween should run for in milliseconds.",
		}, {
			name:"options",
			type:"object",
			desc:"The tween options.",
			link:"tweenOptions",
		}],
		examples:[{
			name:"Tween an Entity",
			desc:"Tween the entity with the ID 'testEntity' from its current world co-ordinates to x = 100, y = 250 and tween the opacity of the entity to half-visible (0.5), all in 2 seconds (2000 milliseconds).",
			code:"<pre>
				// Move the entity and set opacity to half
				this.ige.entities.tweenStart('testEntity', {
					translateX: 100,
					translateY: 250,
					opacityX: 0.5
				}, 2000);
			</pre>",
		}, {
			name:"Tween an Entity With Easing",
			desc:"Tween the entity with the ID 'testEntity' from its current world co-ordinates to x = 100, y = 250 with an easing function, all in 5 seconds (5000 milliseconds).",
			code:"<pre>
				// Move the entity and set opacity to half
				this.ige.entities.tweenStart('testEntity', {
					translateX: 100,
					translateY: 250
				}, 5000, { easing:'outQuad' });
			</pre>",
		}],
	} **/
	tweenStart: function (tempItem, propertyTarget, duration, options) {
		pItem = this.read(tempItem);
		if (pItem) {
			// Check / fill some option defaults
			var options = options || [];
			if (typeof(options.easing) == 'undefined') { options.easing = 'none'; }
			if (typeof(options.startTime) == 'undefined') { options.startTime = new Date().getTime(); }
			if (typeof(duration) == 'undefined') { duration = 0; }
			
			// Calculate the end time
			endTime = options.startTime + duration;
			
			// Record the starting value and the differene between the start and end values
			// for each tweening property
			pItem._tweens = pItem._tweens || [];
			
			for (var i in propertyTarget) {
				var finalTween = {};
				var transformIndex = this.transformProp[i];
				
				finalTween.target = propertyTarget[i];
				finalTween.duration = duration;
				finalTween.easing = options.easing;
				finalTween.startTime = options.startTime;
				finalTween.endTime = endTime;
				finalTween.startVal = pItem._transform[transformIndex];
				finalTween.valDelta = finalTween.target - finalTween.startVal;
				
				// Check that we don't have a tween for this transform index already.
				// If not, increment the tween count
				if (!pItem._tweens[transformIndex]) {
					// Increase the tween count
					if (typeof(pItem._tweenCount) == 'undefined') { pItem._tweenCount = 0; }
					pItem._tweenCount++;
				}
				
				// Store the callback function for this transform index
				if (typeof(options.afterTween) == 'function') {
					pItem.$local.afterTween_callback = pItem.$local.afterTween_callback || [];
					pItem.$local.afterTween_callback[transformIndex] = options.afterTween;
				}
				
				if (typeof(options.beforeTween) == 'function') {
					pItem.$local.beforeTween_callback = pItem.$local.beforeTween_callback || [];
					pItem.$local.beforeTween_callback[transformIndex] = options.beforeTween;
				}
				
				// Store the tween data
				pItem._tweens[transformIndex] = finalTween;
			}
			
			// Enable tweening on this item
			this.tweenEnable(pItem);
		}
	},
	
	/** tweenStop - Stop tweening a transform property for an item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to stop tweening for.",
		}, {
			name:"transformIndex",
			type:"integer",
			desc:"The transform property index to affect.",
		}],
	} **/
	tweenStop: function (pItem, transformIndex) {
		this._tweeners = this._tweeners || [];
		
		// Store the new tween details in the item
		pItem._tweens = pItem._tweens || [];
		delete pItem._tweens[transformIndex];
		if (pItem.$local.afterTween_callback) {
			delete pItem.$local.afterTween_callback[transformIndex];
		}
		
		// Reduce the tween count
		pItem._tweenCount--;
		
		if (!pItem._tweenCount) {
			// Disable tweening on this item
			this.tweenDisable(pItem);
		}
	},
	
	/** tweenStopAll - Stop all tweening for an item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to stop tweening for.",
		}],
	} **/
	tweenStopAll: function (pItem) {
		this._tweeners = this._tweeners || [];
		
		// Disable tweening
		this.tweenDisable(pItem);
		
		// Remove all tween details
		delete pItem._tweens;
		delete pItem.$local.afterTween_callback;
		pItem._tweens = [];
	},
	
	/** tweenEnable - Enable tweening for an item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to enable tweening for.",
		}],
	} **/
	tweenEnable: function (pItem) {
		this._tweeners = this._tweeners || [];
		
		// Check if the item is currently tweening
		if (!pItem._tweening) {
			// Store the item in the tweeners lookup array
			this._tweeners.push(pItem);
			
			// Set the item to tweening
			pItem._tweening = true;
		}
	},
	
	/** tweenDisable - Disable tweening for an item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to disable tweening for.",
		}],
	} **/
	tweenDisable: function (pItem) {
		this._tweeners = this._tweeners || [];
		
		// Check if the item is currently tweening
		if (pItem._tweening) {
			// Remove the item from the tweeners lookup array
			var itemIndex = this._tweeners.indexOf(pItem);
			
			if (itemIndex > -1) {
				this._tweeners.splice(itemIndex, 1);
			}
			
			// Set the item to not tweening
			pItem._tweening = false;
		}
	},
	
	/** tweenProcess - Process tweening for all actively tweening items. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"timeDelta",
			type:"integer",
			desc:"The time in milliseconds between the current time and the last world tick.",
		}, {
			name:"currentTime",
			type:"integer",
			desc:"The current world tick time in milliseconds.",
		}],
	} **/
	tweenProcess: function (timeDelta, currentTime) {
		this._tweeners = this._tweeners || [];
		
		// Loop the tweeners and process updates to their properties
		var count = this._tweeners.length;
		
		while (count--) {
			// Grab the item stored in the tweeners array at this position
			var pItem = this._tweeners[count];
			
			// Loop the item's tweens
			for (var propIndex in pItem._tweens) {
				var tween = pItem._tweens[propIndex];
				
				// Check if we should be starting this tween yet
				if (tween._started || currentTime >= tween.startTime) {
					if (!tween._started) {
						// Check if we have a beforeTween callback to fire
						if (pItem.$local.beforeTween_callback) {
							if (typeof(pItem.$local.beforeTween_callback[propIndex]) == 'function') {
								// Fire the beforeTween callback
								pItem.$local.beforeTween_callback[propIndex](pItem, propIndex);
								
								// Delete the callback so we don't store it any longer
								delete pItem.$local.beforeTween_callback[propIndex];
							}
						}
						
						tween._started = true;
					}
					
					var deltaTime = currentTime - tween.startTime; // Delta from start time to current time
					var destTime = tween.endTime - tween.startTime; // Time in milliseconds to destination
					
					// Check if the tween has reached it's destination based upon
					// the current time
					if (deltaTime >= destTime) {
						// The tween time indicates the tween has ended so set to
						// the ending value and stop the tween
						
						// TO-DO - This can be optimised by detecting changes to each type of
						// transform such as translate, rotate, scale etc and then storing the
						// changes and calling a transform operation with the x, y, z values
						// all at once instead of one at a time like it is at the moment.
						this.transformByIndex(pItem, propIndex, tween.target);
						
						// If there is a callback, call it
						if (pItem.$local.afterTween_callback) {
							if (typeof(pItem.$local.afterTween_callback[propIndex]) == 'function') {
								// Fire the beforeTween callback
								pItem.$local.afterTween_callback[propIndex](pItem, propIndex);
								
								// Delete the callback so we don't store it any longer
								delete pItem.$local.afterTween_callback[propIndex];
							}
						}
						
						// Now stop tweening this transform index
						this.tweenStop(pItem, propIndex);
					} else {
						// The tween is still active, process the tween by passing it's details
						// to the selected easing method
						var newVal = this.tweenEasing[tween.easing](deltaTime, tween.startVal, tween.valDelta, destTime);
						this.transformByIndex(pItem, propIndex, newVal);
					}
				}
			}
		}
	},
	
	/** tweenEasing - Contains all the tween easing functions. {
		category:"property",
		type:"object",
	} **/
	tweenEasing: {
		// Easing equations converted from AS to JS from original source at
		// http://robertpenner.com/easing/
		none: function(t, b, c, d) {
			return c*t/d + b;
		},    
		inQuad: function(t, b, c, d) {
			return c*(t/=d)*t + b;
		},    
		outQuad: function(t, b, c, d) {
			return -c *(t/=d)*(t-2) + b;
		},    
		inOutQuad: function(t, b, c, d) {
			if((t/=d/2) < 1) return c/2*t*t + b;
			return -c/2 *((--t)*(t-2) - 1) + b;
		},    
		inCubic: function(t, b, c, d) {
			return c*(t/=d)*t*t + b;
		},    
		outCubic: function(t, b, c, d) {
			return c*((t=t/d-1)*t*t + 1) + b;
		},    
		inOutCubic: function(t, b, c, d) {
			if((t/=d/2) < 1) return c/2*t*t*t + b;
			return c/2*((t-=2)*t*t + 2) + b;
		},    
		outInCubic: function(t, b, c, d) {
			if(t < d/2) return this.outCubic(t*2, b, c/2, d);
			return this.inCubic((t*2)-d, b+c/2, c/2, d);
		},    
		inQuart: function(t, b, c, d) {
			return c*(t/=d)*t*t*t + b;
		},    
		outQuart: function(t, b, c, d) {
			return -c *((t=t/d-1)*t*t*t - 1) + b;
		},    
		inOutQuart: function(t, b, c, d) {
			if((t/=d/2) < 1) return c/2*t*t*t*t + b;
			return -c/2 *((t-=2)*t*t*t - 2) + b;
		},    
		outInQuart: function(t, b, c, d) {
			if(t < d/2) return this.outQuart(t*2, b, c/2, d);
			return this.inQuart((t*2)-d, b+c/2, c/2, d);
		},    
		inQuint: function(t, b, c, d) {
			return c*(t/=d)*t*t*t*t + b;
		},    
		outQuint: function(t, b, c, d) {
			return c*((t=t/d-1)*t*t*t*t + 1) + b;
		},    
		inOutQuint: function(t, b, c, d) {
			if((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
			return c/2*((t-=2)*t*t*t*t + 2) + b;
		},    
		outInQuint: function(t, b, c, d) {
			if(t < d/2) return this.outQuint(t*2, b, c/2, d);
			return this.inQuint((t*2)-d, b+c/2, c/2, d);
		},    
		inSine: function(t, b, c, d) {
			return -c * Math.cos(t/d *(Math.PI/2)) + c + b;
		},    
		outSine: function(t, b, c, d) {
			return c * Math.sin(t/d *(Math.PI/2)) + b;
		},    
		outSine: function(t, b, c, d) {
			return -c/2 *(Math.cos(Math.PI*t/d) - 1) + b;
		},    
		outInSine: function(t, b, c, d) {
			if(t < d/2) return this.outSine(t*2, b, c/2, d);
			return this.inSine((t*2)-d, b+c/2, c/2, d);
		},    
		inExpo: function(t, b, c, d) {
			return(t==0) ? b : c * Math.pow(2, 10 *(t/d - 1)) + b - c * 0.001;
		},    
		outExpo: function(t, b, c, d) {
			return(t==d) ? b+c : c * 1.001 *(-Math.pow(2, -10 * t/d) + 1) + b;
		},    
		inOutExpo: function(t, b, c, d) {
			if(t==0) return b;
			if(t==d) return b+c;
			if((t/=d/2) < 1) return c/2 * Math.pow(2, 10 *(t - 1)) + b - c * 0.0005;
			return c/2 * 1.0005 *(-Math.pow(2, -10 * --t) + 2) + b;
		},    
		outInExpo: function(t, b, c, d) {
			if(t < d/2) return this.outExpo(t*2, b, c/2, d);
			return this.inExpo((t*2)-d, b+c/2, c/2, d);
		},    
		inCirc: function(t, b, c, d) {
			return -c *(Math.sqrt(1 -(t/=d)*t) - 1) + b;
		},    
		outCirc: function(t, b, c, d) {
			return c * Math.sqrt(1 -(t=t/d-1)*t) + b;
		},    
		inOutCirc: function(t, b, c, d) {
			if((t/=d/2) < 1) return -c/2 *(Math.sqrt(1 - t*t) - 1) + b;
			return c/2 *(Math.sqrt(1 -(t-=2)*t) + 1) + b;
		},    
		outInCirc: function(t, b, c, d) {
			if(t < d/2) return this.outCirc(t*2, b, c/2, d);
			return this.inCirc((t*2)-d, b+c/2, c/2, d);
		},    
		inElastic: function(t, b, c, d, a, p) {
			var s;
			if(t==0) return b;  if((t/=d)==1) return b+c;  if(!p) p=d*.3;
			if(!a || a < Math.abs(c)) { a=c; s=p/4; } else s = p/(2*Math.PI) * Math.asin(c/a);
			return -(a*Math.pow(2,10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )) + b;
		},    
		outElastic: function(t, b, c, d, a, p) {
			var s;
			if(t==0) return b;  if((t/=d)==1) return b+c;  if(!p) p=d*.3;
			if(!a || a < Math.abs(c)) { a=c; s=p/4; } else s = p/(2*Math.PI) * Math.asin(c/a);
			return(a*Math.pow(2,-10*t) * Math.sin((t*d-s)*(2*Math.PI)/p ) + c + b);
		},    
		inOutElastic: function(t, b, c, d, a, p) {
			var s;
			if(t==0) return b;  if((t/=d/2)==2) return b+c;  if(!p) p=d*(.3*1.5);
			if(!a || a < Math.abs(c)) { a=c; s=p/4; }       else s = p/(2*Math.PI) * Math.asin(c/a);
			if(t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )) + b;
			return a*Math.pow(2,-10*(t-=1)) * Math.sin((t*d-s)*(2*Math.PI)/p )*.5 + c + b;
		},    
		outInElastic: function(t, b, c, d, a, p) {
			if(t < d/2) return this.outElastic(t*2, b, c/2, d, a, p);
			return this.inElastic((t*2)-d, b+c/2, c/2, d, a, p);
		},    
		inBack: function(t, b, c, d, s) {
			if(s == undefined) s = 1.70158;
			return c*(t/=d)*t*((s+1)*t - s) + b;
		},    
		outBack: function(t, b, c, d, s) {
			if(s == undefined) s = 1.70158;
			return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
		},    
		inOutBack: function(t, b, c, d, s) {
			if(s == undefined) s = 1.70158;
			if((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
			return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
		},    
		outInBack: function(t, b, c, d, s) {
			if(t < d/2) return this.outBack(t*2, b, c/2, d, s);
			return this.inBack((t*2)-d, b+c/2, c/2, d, s);
		},    
		inBounce: function(t, b, c, d) {
			return c - this.outBounce(d-t, 0, c, d) + b;
		},    
		outBounce: function(t, b, c, d) {
			if((t/=d) <(1/2.75)) {
				return c*(7.5625*t*t) + b;
			} else if(t <(2/2.75)) {
				return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
			} else if(t <(2.5/2.75)) {
				return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
			} else {
				return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
			}
		},    
		inOutBounce: function(t, b, c, d) {
			if(t < d/2) return this.inBounce(t*2, 0, c, d) * .5 + b;
			else return this.outBounce(t*2-d, 0, c, d) * .5 + c*.5 + b;
		},    
		outInBounce: function(t, b, c, d) {
			if(t < d/2) return this.outBounce(t*2, b, c/2, d);
			return this.inBounce((t*2)-d, b+c/2, c/2, d);
		}
	},
});