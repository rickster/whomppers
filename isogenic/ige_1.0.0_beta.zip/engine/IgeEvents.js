/** IgeEvents - The events management class. This class is meant to be
extended by other classes and provides event emitter capabilities to the
extending class. {
	category:"class",
	examples:[{
		name:"Emitting and Listening For Events",
		desc:"Registers an event listener for a given event name.",
		code:"<pre>
			// Create a new class that extends IgeEvents
			MyNewClass = new IgeClass({
				Extends: [IgeEvents],
				
				init: function (engine) {},
				
				fireTheEmitter: function (arg) {					
					// Emit an event with the passed variable 'arg' as an argument
					this.emit('myNewEvent', [arg]);
				},
			});
			
			// Create a new class instance
			var myNewClassInstance = new MyNewClass(this.ige);
			
			// Hook the event 'myNewEvent' from the new class
			myNewClassInstance.on('myNewEvent', function (arg) {
				console.log('We just received an event with the argument:', arg);
			});
			
			// Call our custom class method
			myNewClassInstance.fireTheEmitter('moo!'); // Outputs "We just received an event with the argument: moo!"
		</pre>",
	}, {
		name:"Listening For Multiple Events",
		desc:"The IgeEvents class can accept multiple event emitters and event names as a way to receive an event callback only when every event in the list has fired at least once.",
		code:"<pre>
			// Create a new class that extends IgeEvents
			MyNewClass = new IgeClass({
				Extends: [IgeEvents],
				
				init: function (engine) {},
				
				fireTheFirstEmitter: function () {					
					// Emit an event
					this.emit('myNewEvent1', [arg]);
				},
				
				fireTheSecondEmitter: function () {					
					// Emit an event
					this.emit('myNewEvent2', [arg]);
				},				
			});
			
			// Create a new class instance
			var myNewClassInstance = new MyNewClass(this.ige);
			
			// Hook the events 'myNewEvent1' and 'myNewEvent2' from the new class
			// so that we will only receive an event callback once both events
			// have fired at least once
			this.ige.on(
				// Event entry array
				[
					// Event data array
					[
						// The event emitter object to listen in
						myNewClassInstance,
						
						// Array of event names to listen for
						[
							'myNewEvent1',
							'myNewEvent2'
						]
					]
				], function (arg) {
				console.log('We just received a callback from a multi-event!');
			});
			
			// Call our custom class method
			myNewClassInstance.fireTheFirstEmitter();
			myNewClassInstance.fireTheSecondEmitter(); // Outputs "We just received a callback from a multi-event!"
		</pre>",
	}],
} **/
IgeEvents = new IgeClass({
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
	} **/
	init: function () {},
	
	/** on - Add an event listener method for an event. {
		category:"method",
		arguments: [{
			type:"multi",
			name:"eventName",
			desc:"The name of the event to listen for (string), or an array of events to listen for (multi-events in 0.2.0 or higher only).",
		}, {
			type:"method",
			name:"call",
			desc:"The method to call when the event listener is triggered.",
		}, {
			type:"object",
			name:"context",
			desc:"The context in which the call to the listening method will be made (sets the 'this' variable in the method to the object passed as this parameter).",
			flags:"optional",
		}, {
			type:"bool",
			name:"oneShot",
			desc:"If set, will instruct the listener to only listen to the event being fired once and will not fire again.",
			flags:"optional",
		}, {
			type:"bool",
			name:"sendEventName",
			desc:"If set, will instruct the emitter to send the event name as the argument instead of any emitted arguments. Only 0.2.0 or higher.",
			flags:"optional",
		}],
	} **/
	on: function (eventName, call, context, oneShot, sendEventName) {
		// Check that we have an event listener array
		this._eventListeners = this._eventListeners || [];
		
		if (typeof call == 'function') {
			if (typeof eventName == 'string') {
				// Check if this event already has an array of listeners
				this._eventListeners[eventName] = this._eventListeners[eventName] || [];
				
				// Compose the new listener
				var newListener = {
					call: call,
					context: context,
					oneShot: oneShot,
					sendEventName: sendEventName,
				}
				
				// Check if we already have this listener in the list
				var addListener = true;
				
				// TO-DO - Could this do with using indexOf? Would that work? Would be faster?
				for (var i in this._eventListeners[eventName]) {
					if (this._eventListeners[eventName][i] == newListener) {
						addListener = false;
						break;
					}
				}
				
				// Add this new listener
				if (addListener) {
					this._eventListeners[eventName].push(newListener); 
				}
				
				return newListener;
			} else {
				// The eventName is an array of names, creating a group of events
				// that must be fired to fire this event callback
				if (eventName.length) {
					// Loop the event array
					var multiEvent = [];
					multiEvent[0] = 0; // This will hold our event count total
					multiEvent[1] = 0; // This will hold our number of events fired
					multiEvent[2] = []; // This will hold the list of already-fired event names
					
					// Define the multi event callback
					multiEvent[3] = this.bind(function (firedEventName) {
						if (multiEvent[2].indexOf(firedEventName) == -1) {
							multiEvent[2].push(firedEventName);
							multiEvent[1]++;
							
							if (multiEvent[0] == multiEvent[1]) {
								call.apply(context || this);
							}
						}
					});
						
					for (var eventIndex in eventName) {
						var eventData = eventName[eventIndex];
						var eventObj = eventData[0];
						var eventNameArray = eventData[1];
						
						multiEvent[0] += eventNameArray.length;
						
						for (var singleEventIndex in eventNameArray) {
							// Get the event name
							var singleEventName = eventNameArray[singleEventIndex];
							
							// Register each event against the event object with a callback
							eventObj.on(singleEventName, multiEvent[3], null, true, true);
						}
					}
				}
			}
		} else {
			if (typeof(eventName) != 'string') {
				eventName = '*Multi-Event*'
			}
			this.log('Cannot register event listener for event "' + eventName + '" because the passed callback is not a function!', 'error');
		}
	},
	
	/** emit - Emit an event by name. {
		category:"method",
		arguments: [{
			type:"object",
			name:"eventName",
			desc:"The name of the event to listen for",
		}, {
			type:"multi",
			name:"args",
			desc:"The arguments to send to any listening methods. If you are sending multiple arguments, use an array containing each argument.",
		}],
	} **/
	emit: function (eventName, args) {
		// Check that we have an event listener array
		this._eventListeners = this._eventListeners || [];
		
		// Check if the event has any listeners
		if (this._eventListeners[eventName]) {
			
			// Fire the listeners for this event
			var eventCount = this._eventListeners[eventName].length;
			
			// If there are some events, ensure that the args is ready to be used
			if (eventCount) {
				var finalArgs = [];
				if (typeof(args) == 'object' && args != null && args[0] != null) {
					for (var i in args) {
						finalArgs[i] = args[i];
					}
				} else {
					finalArgs = [args];
				}
				
				// Loop and emit!
				var cancelFlag = false;
				
				while (eventCount--) {
					var tempEvt = this._eventListeners[eventName][eventCount];
					
					// If the sendEventName flag is set, overwrite the arguments with the event name
					if (tempEvt.sendEventName) { finalArgs = [eventName]; }
					
					// Call the callback
					var retVal = tempEvt.call.apply(tempEvt.context || this, finalArgs);
					
					// If the retVal == 1 then store the cancel flag and return to the emitting method
					// TO-DO - Make this a constant that can be named
					if (retVal == 1) {
						// The receiver method asked us to send a cancel request back to the emitter
						cancelFlag = true;
					}
					
					// Check if we should now cancel the event
					if (tempEvt.oneShot) {
						// The event has a oneShot flag so since we have fired the event,
						// lets cancel the listener now
						this.off(eventName, tempEvt);
					}
				}
				
				if (cancelFlag) {
					return 1;
				}
				
			}
			
		}
	},
	
	/** cancelOn - DEPRECIATED PLEASE USE IgeEvents::off() instead. Remove a listener. {
		category:"method",
		desc:"Remove a listener using the original arguments that were passed to the 'on' method to set the listener up",
		return:{
			type:"bool",
			desc:"Returns true if successful and false otherwise."
		},
		arguments: [{
			type:"object",
			name:"evtListener",
			desc:"The name of the event you originally registered to listen for",
		}, {
			type:"object",
			name:"call",
			desc:"The event listener object to cancel.",
		}],
	} **/
	cancelOn: function (eventName, evtListener) {
		this.log('IgeEvents::cancelOn() has been depreciated, please use IgeEvents::off() instead.', 'warning');
		return this.off(eventName, evtListener);
	},
	
	/** off - Remove a listener. {
		category:"method",
		desc:"Remove a listener using the original arguments that were passed to the 'on' method to set the listener up.",
		return:{
			type:"bool",
			desc:"Returns true if successful and false otherwise."
		},
		arguments: [{
			type:"object",
			name:"evtListener",
			desc:"The name of the event you originally registered to listen for.",
		}, {
			type:"object",
			name:"call",
			desc:"The event listener object to cancel.",
		}],
	} **/
	off: function (eventName, evtListener) {
		// Check that we have an event listener array
		this._eventListeners = this._eventListeners || [];
		
		if (this._eventListeners[eventName]) {
			// Find this listener in the list
			var evtListIndex = this._eventListeners[eventName].indexOf(evtListener);
			if (evtListIndex > -1) {
				// Remove the listener from the event listender list
				this._eventListeners[eventName].splice(evtListIndex, 1);
				return true;
			}
			this.log('Failed to cancel event listener for event named "' + eventName + '" !', 'info', evtListener);
		} else {
			this.log('Failed to cancel event listener!');
		}
		
		return false;
	},
	
	eventList: function () {
		return this._eventListeners;
	},
	
	// Add a wrapper to continue support for the old way of handling events but warn each time it's used!
	events: {
		on: function () { var stack = new Error().stack; throw('+++++++++ ERROR +++++++++ [class].events.on() is depreciated in 0.2.2. Please use [class].on() instead!\n' + stack); process.exit(); },
		emit: function () { var stack = new Error().stack; throw('+++++++++ ERROR +++++++++ [class].events.emit() is depreciated in 0.2.2. Please use [class].emit() instead!\n' + stack); },
		cancelOn: function () { var stack = new Error().stack; throw('+++++++++ ERROR +++++++++ [class].events.cancelOn() is depreciated in 0.2.2. Please use [class].off() instead!\n' + stack); },
	},
	
});