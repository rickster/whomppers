/** IgeGamepad - *EXPERIMENTAL* Provides gamepad interface methods and events. {
	category:"class",
} **/
IgeGamepad = new IgeClass({
	Extends: IgeEvents,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeGamepad';
		this.ige = engine;
		
		if (!this.ige.isServer) {
			this._pads = navigator.webkitGamepads || navigator.mozGamepads || navigator.gamepads;
			
			// Hook gamepad window events
			$(window).bind('MozGamepadConnected', this.bind(this._connected));
			$(window).bind('WebkitGamepadConnected', this.bind(this._connected));
			$(window).bind('gamepadConnected', this.bind(this._connected));
			
			$(window).bind('MozGamepadDisconnected', this.bind(this._disconnected));
			$(window).bind('WebkitGamepadDisconnected', this.bind(this._disconnected));
			$(window).bind('gamepadDisconnected', this.bind(this._disconnected));
		}
	},
	
	/** available - Checks for the availability of the GamePad API
	in the browser. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true if the GamePad API is available, false if not.",
		},
	} **/
	available: function () {
		if (typeof(this._pads) == 'undefined') {
			return false;	
		} else {
			return true;
		}
	},
	
	/** _connected - Called when a GamePad is connected. Emits the
	'connected' event with the gamepad object that was connected. {
		category:"method",
		argument: {
			type:"object",
			name:"e",
			desc:"The event object.",
		},
	} **/
	_connected: function (e) {
		this.log('Gamepad connected with vendor id of ' + e.gamepad.id);
		this.emit('connected', e.gamepad);
	},
	
	/** _disconnected - Called when a GamePad is disconnected. Emits the
	'connected' event with the gamepad object that was disconnected. {
		category:"method",
		argument: {
			type:"object",
			name:"e",
			desc:"The event object.",
		},
	} **/
	_disconnected: function (e) {
		this.log('Gamepad disconnected with vendor id of ' + e.gamepad.id);
		this.emit('disconnected', e.gamepad);
	},
});