/** IgeAssets - The assets manager. {
	category:"class",
	externalLibs:[{
		name:"node-imagemagick",
		desc:"ImageMagick Module for Node.js",
		url:"https://github.com/rsms/node-imagemagick",
	}],
	examples:[{
		name:"Create an Asset From a Single-Frame Image File",
		desc:"Where an asset contains a single frame (not a sprite-sheet) 2d image you can define it like this.",
		code:"<pre>
			this.ige.assets.create({
				asset_id: 'myNewAsset', // A unique ID value
				asset_image_url: './assets/ui/testUi.png',
				asset_anchor_points: [[0, 0]],
				asset_render_mode: ASSET_RENDER_MODE_2D,
			});
		</pre>",
	}, {
		name:"Create an Asset From a Multi-Frame Sprite-Sheet Image File",
		desc:"Where an asset contains multiple frames (a sprite-sheet) 2d image you can define it like this. In the example the sprite-sheet contains 4 frames in total, 2 on each row.",
		code:"<pre>
			this.ige.assets.create({
				asset_id: 'myNewAsset', // A unique ID value
				asset_image_url: './assets/ui/testUi.png',
				asset_sheet_enabled: true,
				asset_sheet_width: 2,
				asset_sheet_height: 2,
				asset_anchor_points: [[0, 0]],
				asset_render_mode: ASSET_RENDER_MODE_2D,
			});
		</pre>",
	}],
} **/

/** beforeCreate - Fired before an asset is created. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
	control:"This event can cancel subsequent code if the receiving method returns true.",
} **/
/** afterCreate - Fired after an asset is created. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
} **/
/** beforeUpdate - Fired before an asset is updated. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
	control:"This event can cancel subsequent code if the receiving method returns true.",
} **/
/** afterUpdate - Fired after an asset is updated. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
} **/
/** assetLoaded - Fired after an asset has been loaded into memory. This does not mean
that the assets image is ready to use. If you want to know when an asset image is ready
you can hook the assetReady event. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
} **/
/** assetReady - Fired after an asset has loaded its image data into memory. {
	category: "event",
	argument: {
		type:"object",
		name:"asset",
		desc:"The asset object this event was fired for.",
	},
} **/
/** allAssetsLoaded - Fired after all assets in the load queue have finished loading. {
	category: "event",
} **/
IgeAssets = new IgeClass({
	
	Extends: [IgeCollection, IgeItem, IgeEvents],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: null,
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: null,
	
	/** byMapId - An array with a string index that allows you to access every item
	created using the create method by its map_id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byMapId: [],
	
	/** assetImage - An array with a string index that allows you to access every asset's
	image element (img tag) by the asset_id. {
		category:"property",
		type:"array",
		index:"string",
	} **/	
	assetImage: [],
	
	/** imagesLoading - An integer value representing the number of images left to load into
	memory. If set to zero then all images have finished loading. If -1 then no images have
	been loaded and no assets have been created. {
		category:"property",
		type:"integer",
	} **/	
	imagesLoading: null,
	
	/* CEXCLUDE */
	/** imageMagic - A reference to the ImageMagick node module instance. {
		category:"property",
		type:"object",
		flags:"server",
	} **/
	imageMagic: null,
	/* CEXCLUDE */
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeAssets';
		
		this.engine = engine;
		
		this.byIndex = [];
		this.byId = [];
		this.byMapId = [];
		this.assetImage = [];
		
		this.collectionId = 'asset';
		this.imagesLoading = -1;
		this._createCount = 0;
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			this.imageMagic = require(igeConfig.mapUrl('/node_modules/imagemagick/imagemagick'));
			this.vm = require('vm');
			this.fs = require('fs');
		}
		/* CEXCLUDE */
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('assetsCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand(this.collectionId + 'sCreateCount', this.bind(this.receiveCreateCount));
		//this.engine.network.registerCommand('assetsProcess', this.bind(this.processAssetsClient));
		this.engine.network.registerCommand('assetsUpdate', this.bind(this.receiveUpdate));
		this.engine.network.registerCommand('assetsRemove', this.bind(this.receiveRemove));
		
		this.engine.network.registerCommand('assetsStartSend', this.bind(this.netSendStarted));
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'asset_anchor_points',
			'asset_id',
			'asset_image_url',
			'asset_locale',
			'asset_render_mode',
			'asset_scale',
			'asset_sheet_enabled',
			'asset_sheet_frame',
			'asset_sheet_width',
			'asset_sheet_height',
			'asset_sheet_unit_x',
			'asset_sheet_unit_y',
			'asset_persist',
		]);
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends when creating a new item. Here you can define
	any object properties that are default across all items of this class. If this method returns false the create action
	will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureLocalExists(pItem);
		/* CEXCLUDE */
		if (this.engine.isServer) { this.ensurePersistExists(pItem); }
		/* CEXCLUDE */
		this.ensureIdExists(pItem);
		
		// Ensure the asset has an asset_sheet_frame (default to 1)
		//pItem.asset_sheet_frame = pItem.asset_sheet_frame || 1;
		
		// Ensure the asset has a render mode
		if (typeof(pItem.asset_render_mode) == 'undefined') {
			// Default to 2d
			pItem.asset_render_mode = RENDER_MODE_2D;
		}
		
		// Set the new _targetData variable for entity interpolation
		if (!this.engine.isServer) { pItem._targetData = []; }
		
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends when creating a new item. Checks the
	integrity of an item before it is allowed to be created. Here you can define custom checks to ensure an item being
	created conforms to the standard your class requires. If this method returns false the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		// Check that this entity does not already exist
		if (this.byId[pItem.entity_id]) {
			this.log('Attempted to create an asset that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		
		// No integrity checks failed so return true to continue processing this item
		return true;
	},
	
	/** _create - Create a new asset to be use in entities. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the newly created item on success or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"asset",
			desc:"The asset object to be created.",
			link:"assetData",
		}],
	} **/
	_create: function (pItem) {
		// Set all loaded to false
		this.allLoaded = false;
		
		// Set some defaults
		pItem.asset_scale = pItem.asset_scale || 1;
		delete pItem.processing;
		
		this.byIndex.push(pItem);
		this.byId[pItem.asset_id] = pItem;
		this.byMapId[pItem.map_id] = this.byMapId[pItem.map_id] || [];
		this.byMapId[pItem.map_id].push(pItem);
		
		if (this.imagesLoading == -1) { this.imagesLoading = 0; }
		this.imagesLoading++;
		
		if (this.engine.isServer) {
			/* CEXCLUDE */
			this.processAssetsServer();
			/* CEXCLUDE */
		} else {
			// Client code
			this.log('Processing asset load for: ' + pItem.asset_id);
			if (this.options.delayProcess == true && this._createCount > 0) {
				// Delay the processing of assets until the assets we've received
				// matches the number of assets in the createCount that was set by
				// the server's assetsCreateCount network message
				if (this.imagesLoading == this._createCount) {
					this.log('Now processing delayed asset image creation...');
					// Reset the create count
					this._createCount = 0;
					// Process assets
					this.processAssetsClient();
				}
			} else {
				// We shouldn't delay processing so start processing immediately
				this.processAssetsClient();
			}
		}
		
		// Check for a callback function embedded in the item
		if (typeof(pItem.$local.create_callback) == 'function') {
			pItem.$local.create_callback.apply(this, [pItem]);
			delete pItem.$local.create_callback;
		}
		
		this.emit('afterCreate', pItem);
		
		return pItem;
	},
	
	/** _update - Updates the class collection item with the matching id specified in the updData
	parameter with all properties of the pData parameter. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (pItem, pData) {
		// Grab the current item object
		var pItem = this.read(pItem);

		if (pItem != null) {
			// Emit the beforeUpdate event and halt if any listener returns the cancel flag
			if (!this.emit('beforeUpdate', pItem)) {
				// Update the current object with the new object's properties
				for (var i in pData) {
					pItem[i] = pData[i];
				}
				
				this.emit('afterUpdate', pItem);
				
				if (typeof(pItem.$local.update_callback) == 'function') {
					pItem.$local.update_callback(pItem);
					pItem.$local.update_callback = null;
				}
				
				return pItem;
			} else {
				// Call the callback with no argument meaning there was a cancellation or error
				if (typeof(pItem.$local.update_callback) == 'function') {
					pItem.$local.update_callback();
					pItem.$local.update_callback = null;
				}
			}
		} else {
			this.log('Cannot update item because it could not be located by calling this.read().', 'error', pItem);
			return false;
		}
		
	},

	/** _remove - Private method that removes the item identified by the passed
	id from the engine. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The entity object to be removed.",
			link:"entityData",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (typeof(pItem) != 'undefined') {
			// Check if the pItem has a callback method and if so, save a reference to it, then fire after removal of the pItem
			var cbMethod = null;
			if (typeof pItem.$local.remove_callback == 'function') {
				cbMethod = pItem.$local.remove_callback;
			}
			
			// Remove it from all the arrays
				// TO-DO - Don't like this implementation - should store the index at create
				// and avoid these costly lookups! - But memory is important too... oh the woe.
			var arr1 = this.byMapId[pItem.map_id];
			var arr2 = this.byIndex;
			
			// Remove the item from all the lookup arrays
			delete this.byId[pItem[this.collectionId + '_id']];
			var arr1Index = arr1.indexOf(pItem);
			var arr2Index = arr2.indexOf(pItem);
			arr1.splice(arr1Index, 1);
			arr2.splice(arr2Index, 1);
			
			if (typeof(cbMethod) == 'function') {
				cbMethod.apply(this);
			}
			
			return true;
		} else {
			return false;
		}
	},
	
	/** assetReady - Check the ready state of an asset by it's id. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true if the asset whose id is passed as the parameter has loaded its image and is ready to use. Returns false otherwise",
		},
		argument: {
			type:"string",
			name:"assetId",
			desc:"The id of the asset to be evaluated.",
		},
	} **/
	assetReady: function (assetId) {
		var ready = false;
		var asset = this.byId[assetId];
		
		if (asset) {
			if (asset.asset_image_url) {
				if (this.byId[assetId].$local.$image) {
					ready = true;
				}
			}
			if (asset.asset_render_script) {
				if (this.byId[assetId].$local.$script) {
					ready = true;
				}
			}
		}
			
		return ready;
	},
	
	/** processAssetsClient - Trigger loading of the current list of un-loaded assets. {
		category:"method",
	} **/
	processAssetsClient: function () {
		// Check if we are the client engine
		if (!this.engine.isServer && !this.engine.isSlave) {
			var asset = null;
			
			for (var i = 0; i < this.byIndex.length; i++) {
				asset = this.byIndex[i];
				if (!this.assetReady(asset.asset_id) && !asset.processing) {
					asset.processing = true;
					
					// Check if the asset should load an image
					if (asset.asset_image_url) {
						this.log('Loading asset image data: ' + asset.asset_image_url);
						this.loadImage(asset.asset_id, asset.asset_image_url);
					}
					
					// Check if the asset should load a render script (1.0.0+)
					if (asset.asset_render_script) {
						this.log('Loading asset render script: ' + asset.asset_render_script);
						this.loadScript(asset.asset_id, asset.asset_render_script);
					}
				}
			}
		}
	},
	
	/** processAssetsServer - Trigger loading of the current list of un-loaded assets. {
		category:"method",
	} **/
	processAssetsServer: function () {
		if (this.engine.isServer) {
			/* CEXCLUDE */
			// Server doesn't load images via <img> tags, instead we grab image
			// data using the ImageMagick library
			var asset = null;
			
			for (var i = 0; i < this.byIndex.length; i++) {
				
				asset = this.byIndex[i];
				
				if (!this.assetReady(asset.asset_id) && !asset.processing) {
					this.log('Asset needs loading: ' + asset.asset_id);
					asset.processing = true;
					
					// Check if the asset has an image url
					if (asset.asset_image_url) {
						// Support asset urls outside of the main game folder such as those used in modules
						var finalUrl = asset.asset_image_url;
						
						// Load the asset and get it's details
						try {
							this.imageMagic.identify(finalUrl, this.bind(function(err, data){
								if (!err) {
									delete asset.processing;
									// Assign the data to the image for later use
									this.log('Asset loaded successfully: ' + asset.asset_id);
									this._setAssetSize(asset, {width:data.width, height:data.height});
									this.imagesLoading--;
									
									this.emit('assetLoaded', asset);
									if (this.imagesLoading == 0) { this.emit('allAssetsLoaded'); }
								} else {
									this.log('Cannot execute imagemagick "identify". Is the image file valid and is imagemagick installed?', 'error', [__dirname + '/' + finalUrl, asset, err]);
								}
							}));
						} catch (err) {
							this.log('Cannot execute imagemagick "identify". Is the image file valid and is imagemagick installed?', 'error', err);
						}
					}
					
					// Check if the asset has a render script url
					if (asset.asset_render_script) {
						// Load the render script code and execute it inside a new context
						var rs_sandboxContext = {};
						this.fs.readFile(asset.asset_render_script, this.bind(function(err, data) {
							try {
								this.vm.runInNewContext(data, rs_sandboxContext);
								
								// Check if the script defined an image object which is
								// required for asset scripts
								if (typeof(rs_sandboxContext.image) == 'object') {
									// Store the image object
									asset.$local.$script = rs_sandboxContext.image;
									
									// Set the size of the asset based upon the script data
									this._setAssetSize(asset, {width:asset.$local.$script.width, height:asset.$local.$script.height});
									
									delete asset.processing;
									this.log('Asset loaded successfully: ' + asset.asset_id);
									this.imagesLoading--;
									this.emit('assetLoaded', asset);
									if (this.imagesLoading == 0) { this.emit('allAssetsLoaded'); }
								} else {
									// The script did not define an image object!
									this.log('Error reading asset render script data. The script does not contain an image variable!', 'error', [asset.asset_render_script, rs_sandboxContext]);
								}
							} catch(err2) {
								// The script contained a JS error
								this.log('Error executing asset render script: ', 'error', [err2, asset.asset_render_script]);
							}
						}));
					}
					
				}
				
			}
			/* CEXCLUDE */
		}
	},
	
	/** generateMipMap - Generates a new MIP based upon the specified asset and mipScale. {
		category:"method",
		engine_ver:"0.3.0",
		return: {
			type:"object",
			desc:"Returns the MIP as a canvas element or false on error.",
		},
		arguments: [{
			type:"object",
			name:"asset",
			desc:"The asset to use when generating the MIP.",
		}, {
			type:"integer",
			name:"mipScale",
			desc:"The scale to draw the MIP at. Defaults to 0.5.",
			flags:"optional",
		}],
	} **/
	generateMipMap: function (asset, mipScale) {
		if (!mipScale) { mipScale = 0.5; }
		var img = null;
		if (asset.$local.$image) {
			img = asset.$local.$image;
		} else {
			this.log('No image was passed and no image exists in the asset for generateMipMap.', 'warning', asset);
		}

		if (img) {
			var canvas = document.createElement('canvas');
			canvas.width = img.width * mipScale;
			canvas.height = img.height * mipScale;
			
			var ctx = canvas.getContext('2d');
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			
			return canvas;
		}
		
		return false;
	},
	
	/** loadImage - Loads an image into an img tag and sets an onload event to capture
	when the image has finished loading. {
		category:"method",
		arguments: [{
			type:"string",
			name:"assetId",
			desc:"The asset_id of the asset to load the image for.",
		}, {
			type:"string",
			name:"imageUrl",
			desc:"The image url used to load the image data.",
		}],
	} **/
	loadImage: function (assetId, imageUrl) {
		var newImage = new IgeElement('img', {id:assetId});
		newImage.onload = this.bind(this._assetImageLoaded);
		newImage.src = imageUrl;
		this.assetImage[assetId] = newImage;
	},
	
	/** loadScript - Loads a render script into a script tag and sets an
	onload event to capture	when the script has finished loading. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"string",
			name:"assetId",
			desc:"The asset_id of the asset to load the image for.",
		}, {
			type:"string",
			name:"scriptUrl",
			desc:"The script url used to load the script data.",
		}],
	} **/
	loadScript: function (assetId, scriptUrl) {
		$.ajax({
			url: scriptUrl,
			success: this.bind(function(data) {
				var asset = this.byId[assetId];
				
				// Parse the JS with evil eval and store the result in the asset
				eval(data);
				
				// Store the eval data
				asset.$local.$script = image;
				
				delete asset.processing;
				this._setAssetScriptSize(asset);
				
				this.imagesLoading--;
				this.log('Asset render script loaded: ' + scriptUrl);
				
				// Emit the asset loaded event with the asset id - useful for deferring parts of the code until an asset exists
				this.emit('assetLoaded', asset);
				if (this.imagesLoading == 0) { this.emit('allAssetsLoaded'); }
			}),
			dataType: 'script',
		});
	},
	
	/** _assetImageLoaded - Called when an image has finished loading. Stores the new image in the
	asset and emits an assetLoaded event. {
		category:"method",
		arguments: [{
			type:"object",
			name:"e",
			desc:"The event object.",
		}],
	} **/
	_assetImageLoaded: function (e) {
		var img = e.target;
		var asset = this.byId[img.id];
		delete asset.processing;
		this._setAssetSize(asset, img);
		
		this.imagesLoading--;
		this.log('Asset image loaded: ' + img.src + ' (' + img.width + ', ' + img.height + ')');
		
		// Emit the asset loaded event with the asset id - useful for deferring parts of the code until an asset exists
		this.emit('assetLoaded', asset);
		if (this.imagesLoading == 0) { this.emit('allAssetsLoaded'); }
	},
	
	/** _assetScriptLoaded - Called when an image has finished loading. Stores the new image in the
	asset and emits an assetLoaded event. {
		category:"method",
		arguments: [{
			type:"object",
			name:"e",
			desc:"The event object.",
		}],
	} **/
	_assetScriptLoaded: function (e) {
		var img = e.target;
		var asset = this.byId[img.id];
		delete asset.processing;
		this._setAssetSize(asset, img);
		
		this.imagesLoading--;
		this.log('Asset image loaded: ' + img.src + ' (' + img.width + ', ' + img.height + ')');
		
		// Emit the asset loaded event with the asset id - useful for deferring parts of the code until an asset exists
		this.emit('assetLoaded', asset);
		if (this.imagesLoading == 0) { this.emit('allAssetsLoaded'); }
	},
	
	/** _setAssetSize - Called when an asset's image has fully loaded and calculates and stores
	a number of useful values that are used to render the asset image and determine dimensions. {
		category:"method",
		arguments: [{
			type:"object",
			name:"asset",
			desc:"The asset object to use when setting object properties to.",
		}, {
			type:"object",
			name:"img",
			desc:"The image element whose dimensions are to be evaluated.",
		}],
	} **/
	_setAssetSize: function (asset, img) {
		// Check if we are loading a sheet and if so, pre-calculate
		// all the co-ordinates so that the renderer can use them
		// without having to calculate them itself every frame...
		var tempImageWidth = img.width;
		var tempImageHeight = img.height;
		asset.$local.$sheetFrames = [];
		
		if (asset.asset_sheet_enabled && asset.asset_sheet_width && asset.asset_sheet_height) {
			asset.asset_sheet_unit_x = tempImageWidth / asset.asset_sheet_width;
			asset.asset_sheet_unit_y = tempImageHeight / asset.asset_sheet_height;
			
			// Check the asset for data that we might need to calculate
			if (asset.asset_sheet_width > 1 || asset.asset_sheet_height > 1) {
				// Loop through each frame and calculate the frame bounds for the renderer
				for (var frameIndex = 1; frameIndex <= (asset.asset_sheet_width * asset.asset_sheet_height); frameIndex++) {
					var yPos = (Math.ceil(frameIndex / asset.asset_sheet_width) - 1);
					var xPos = ((frameIndex - (asset.asset_sheet_width * yPos)) - 1);
					
					// Store the xy in the sheet frames variable
					asset.$local.$sheetFrames[frameIndex] = [(xPos * asset.asset_sheet_unit_x), (yPos * asset.asset_sheet_unit_y)];
				}
				
				if (asset.asset_anchor_points[0]) {
					// Check that all the asset anchor points are filled in. If not, calculate them from the first one
					for (var i = 2; i <= (asset.asset_sheet_width * asset.asset_sheet_height); i++) {
						if (!asset.asset_anchor_points[i - 1]) {
							// Make the anchor point the same as the first one
							asset.asset_anchor_points[i - 1] = asset.asset_anchor_points[0];
						}
					}
				} else {
					this.log('Asset loaded with sheet enabled but no anchor point found. At least one must be defined.', 'error');
				}
			}
			
			asset.$local.$size = asset.$local.$size || [];
			
			// Calculate and store the asset size data
			asset.$local.$size[0] = asset.asset_sheet_unit_x;
			asset.$local.$size[1] = asset.asset_sheet_unit_y;
		} else {
			asset.$local.$size = asset.$local.$size || [];
			
			// Single image so use source as whole image size
			asset.$local.$size[0] = tempImageWidth;
			asset.$local.$size[1] = tempImageHeight;
			
			asset.$local.$sheetFrames[1] = [0, 0];
		}
		
		asset.$local.$imageWidth = tempImageWidth;
		asset.$local.$imageHeight = tempImageHeight;
		asset.$local.$image = img;
		
		// Check if the asset has a callback method and if so, fire it
		if (typeof asset.$local.$callback == 'function') {
			asset.$local.$callback.apply(this, [asset]);
			asset.$local.$callback = null;
		}
		
		this.emit('assetReady', asset);
	},
	
	/** _setAssetScriptSize - Called when an asset's image has fully loaded and calculates and stores
	a number of useful values that are used to render the asset image and determine dimensions. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"object",
			name:"asset",
			desc:"The asset object to use when setting object properties to.",
		}, {
			type:"object",
			name:"img",
			desc:"The image element whose dimensions are to be evaluated.",
		}],
	} **/
	_setAssetScriptSize: function (asset) {
		// Check if we are loading a sheet and if so, pre-calculate
		// all the co-ordinates so that the renderer can use them
		// without having to calculate them itself every frame...
		var tempImageWidth = asset.$local.$script.width;
		var tempImageHeight = asset.$local.$script.height;
		asset.$local.$sheetFrames = [];
		
		if (asset.asset_sheet_enabled && asset.asset_sheet_width && asset.asset_sheet_height) {
			asset.asset_sheet_unit_x = tempImageWidth / asset.asset_sheet_width;
			asset.asset_sheet_unit_y = tempImageHeight / asset.asset_sheet_height;
			
			// Check the asset for data that we might need to calculate
			if (asset.asset_sheet_width > 1 || asset.asset_sheet_height > 1) {
				// Loop through each frame and calculate the frame bounds for the renderer
				for (var frameIndex = 1; frameIndex <= (asset.asset_sheet_width * asset.asset_sheet_height); frameIndex++) {
					var yPos = (Math.ceil(frameIndex / asset.asset_sheet_width) - 1);
					var xPos = ((frameIndex - (asset.asset_sheet_width * yPos)) - 1);
					
					// Store the xy in the sheet frames variable
					asset.$local.$sheetFrames[frameIndex] = [(xPos * asset.asset_sheet_unit_x), (yPos * asset.asset_sheet_unit_y)];
				}
				
				if (asset.asset_anchor_points[0]) {
					// Check that all the asset anchor points are filled in. If not, calculate them from the first one
					for (var i = 2; i <= (asset.asset_sheet_width * asset.asset_sheet_height); i++) {
						if (!asset.asset_anchor_points[i - 1]) {
							// Make the anchor point the same as the first one
							asset.asset_anchor_points[i - 1] = asset.asset_anchor_points[0];
						}
					}
				} else {
					this.log('Asset loaded with sheet enabled but no anchor point found. At least one must be defined.', 'error');
				}
			}
			
			asset.$local.$size = asset.$local.$size || [];
			
			// Calculate and store the asset size data
			asset.$local.$size[0] = asset.asset_sheet_unit_x;
			asset.$local.$size[1] = asset.asset_sheet_unit_y;
		} else {
			asset.$local.$size = asset.$local.$size || [];
			
			// Single image so use source as whole image size
			asset.$local.$size[0] = tempImageWidth;
			asset.$local.$size[1] = tempImageHeight;
			
			asset.$local.$sheetFrames[1] = [0, 0];
		}
		
		asset.$local.$imageWidth = tempImageWidth;
		asset.$local.$imageHeight = tempImageHeight;
		
		// Check if the asset has a callback method and if so, fire it
		if (typeof asset.$local.$callback == 'function') {
			asset.$local.$callback.apply(this, [asset]);
			asset.$local.$callback = null;
		}
		
		this.emit('assetReady', asset);
	},
	
	/** size - Returns the width and height in pixels of the asset. If the
	asset uses a sheet, the width and height of one cell from the sheet is
	returned. If no sheet is used, the width and height of the source image
	is returned. {
		category:"method",
		return:{
			type:"array",
			index:"integer",
			desc:"An array with 2 values [0] = width, [1] = height. Returns false on error.",
		},
	} **/
	size: function (asset) {
		if (asset.$local && asset.$local.$size) {
			return asset.$local.$size;
		} else {
			return false;
		}
	},
	
});