/** IgeUtils - A class containing some helper utility methods that are inherited by the
extending class. This class is designed to be extended and does not do anything by itself. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeUtils = new IgeClass({
	init: function () {},
	
	/** stripLocal - Returns a copy (not a reference) of the passed object with any dollar-prepended properties removed. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a copy (not a reference) of the passed object with any dollar-prepended properties removed.",
		},	
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to copy and return stripped of properties that start with a dollar sign.",
		}],
	} **/
	stripLocal: function (obj) {
		var newObj = {};
		for (var i in obj) {
			if (i != '$local') {
				newObj[i] = obj[i];
			}
		}
		return newObj;
	},
	
	/** stripLocalDeep - Returns a copy (not a reference) of the passed object with any dollar-prepended properties removed.
	This method performs a deep scan so every property which is also an object will also be checked and have their dollar-
	prepended properties removed recursively. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a copy (not a reference) of the passed object with any dollar-prepended properties removed.",
		},	
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to copy and return stripped of properties that start with a dollar sign.",
		}],
	} **/
	stripLocalDeep: function (obj) {
		var newObj = {};
		for (var i in obj) {
			if (i != '$local') {
				if (typeof (obj[i]) == 'object') {
					newObj[i] = this.stripLocalDeep(obj[i]);
				} else {
					newObj[i] = obj[i];
				}
			}
		}
		return newObj;
	},
	
	/** objClone - Returns a copy (not a reference) of the passed object. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a copy (not a reference) of the passed object.",
		},	
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to copy and return.",
		}],
	} **/	
	objClone: function (obj) {
		var objType = typeof(obj);
		if (objType != 'undefined' && objType != 'null') {
			var retVal = {};
			
			try {
				retVal = JSON.parse(JSON.stringify(obj));
			} catch (err) {
				console.log(err, obj);
			}
			
			return retVal;
		} else {
			this.log('Cannot clone undefined object!', 'warning', obj);
		}
	},
	
	/** diffObject - Takes a two objects and an optional array and finds the differences between the two
	objects and returns the result of the comparison. {
		category:"method",
		return: {
			type:"array",
			desc:"Returns an array with the first entry (index zero) as a new object containing only the properties and their values from argument 1 that are different from the object specified in argument 2.",
		},
		arguments: [{
			type:"object",
			name:"newObject",
			desc:"The new object to compare to the current object (argument 2).",
		}, {
			type:"object",
			name:"curObject",
			desc:"The current object to compare to the new object (argument 1).",
		}, {
			type:"array",
			name:"props",
			desc:"If set, will limit the comparison of each object to only the property names in the array.",
			flags:"optional",
		}, {
			type:"bool",
			name:"checkDollars",
			desc:"If set to true, the function will	also test properties whose names start with a dollar symbol ($). The default is to ignore them (dollar-prepended names are considered private properties and not to be included in network traffic, DB storage or object comparisons etc).",
			flags:"optional",
		}],
	} **/
	diffObject: function (newObject, curObject, props, checkDollars) {
		
		if (newObject != null && curObject != null) {
			var updObject = {};
			var changedProps = [];
			
			// Whatever changes have been made, we NEED to have the ID in the update object!
			// TO-DO - Not every object we pass into this method is an entity is it? If so this should
			// go in the IgeEntities class not here! Else this line is wrong because is assumes an entity!
			updObject.entity_id = newObject.entity_id;
			
			if (props) {
				// We have an array of properties to copy
				for (var i in props) {
					var propName = props[i];
					
					if (!checkDollars && propName.substr && propName.substr(0, 1) == '$') {
						continue;
					}
					
					if (curObject[propName] != newObject[propName]) {
						updObject[propName] = newObject[propName];
						changedProps.push(propName);
					}
				}
			} else {
				// Check for differences and copy changed data
				for (var i in newObject) {
					
					if (!checkDollars && i.substr && i.substr(0, 1) == '$') {
						continue;
					}
					
					if (curObject[i] != null && curObject[i] != newObject[i]) {
						updObject[i] = newObject[i];
						changedProps.push(i);
					}
				}
			}
		} else {
			this.log('Error whilst trying to diffObject, an object == null.', 'error', {newObject:newObject, curObject:curObject});
		}
		
		return [updObject, changedProps];
		
	},
	
	/** _processMethodArray - Loops the passed array and calls each method contained in it
	with the passed arguments. The array is reverse-iterated so the last method pushed to the
	array will be the first to be called. {
		category:"method",
		arguments: [{
			type:"array",
			name:"arr",
			desc:"The method array. An array of methods that will be called with the passed arguments.",
			index:"integer",
		}, {
			type:"array",
			name:"args",
			desc:"The array of arguments that will be passed to each method in the method array.",
			index:"integer",
		}],
	} **/
	_processMethodArray: function (arr, args) {
		var count = arr.length;
		while (count--) {
			arr[count].apply(this, args);
		}
	},
	
	/** buildTermIndex - Returns an array of property names and values used in the passed
	object. Scans object recursively. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns an array of property names and values used in the passed object.",
		},	
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to scan for property names.",
		}],
	} **/
	buildTermIndex: function (obj, currentIndex, retMode) {
		// Build an array of unique property names as keys with the value as true
		var newIndex = currentIndex || [];
		for (var i in obj) {
			if (typeof(obj[i]) == 'object') {
				// Parse the object
				this.buildTermIndex(obj[i], newIndex, 1);
			} else if(typeof(obj[i]) == 'string') {
				if (parseInt(obj[i]) != obj[i]) {
					// Store the string value in the term array
					newIndex[obj[i]] = true;
				}
			}
			if (parseInt(i) != i) {
				newIndex[i] = true;
			}
			
		}
		
		if (!retMode) {
			// Now turn the index into an array where the keys are integers
			var finalIndex = [];
			for (var i in newIndex) {
				finalIndex.push(i);
			}
			return finalIndex;
		}
	},
	
	/** buildTermIndexCompressed - Returns an array of property names and values used in the passed object where the name or value
	appears more than once. Scans object recursively. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns an array of property names and values used in the passed object.",
		},	
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to scan for property names.",
		}],
	} **/
	buildTermIndexCompressed: function (obj, currentIndex, retMode) {
		// Build an array of unique property names as keys with the value as true
		var newIndex = currentIndex || [];
		for (var i in obj) {
			// Check if this key is a non-number
			if (parseInt(i) != i) {
				// This is a key, not a value
				if (!newIndex[i]) { newIndex[i] = 1; } else { newIndex[i] = 2; }
			}
			
			// Check if the value for this key is an object or string
			if (typeof(obj[i]) == 'object') {
				// Parse the object
				this.buildTermIndexCompressed(obj[i], newIndex, 1);
			} else if(typeof(obj[i]) == 'string') {
				// This is a value, not a key
				if (parseInt(obj[i]) != obj[i]) {
					// Store the string value in the term array
					if (!newIndex[obj[i]]) { newIndex[obj[i]] = 1; } else { newIndex[obj[i]] = 2; }
				}
			}

			
		}
		
		if (!retMode) {
			// Now turn the index into an array where the keys are integers
			var finalIndex = [];
			for (var i in newIndex) {
				if (newIndex[i] > 1) {
					finalIndex.push(i);
				}
			}
			return finalIndex;
		}
	},
});