/** IgeBase - Defines a number of helper methods that are used throughout
the engine code. {
	category:"class",
} **/

/** IgeElement - Allows the engine to create new HTML elements using passed
parameters to determine the element's properties. {
	category:"method",
	arguments:[{
		name:"elem",
		type:"string",
		desc:"The element name to create.",
	}, {
		name:"params",
		type:"object",
		desc:"An object containing properties and values that the element should contain.",
	}],
} **/
var IgeElement = function (elem, params) {
	var tempElem = document.createElement(elem);
	
	for (param in params) {
		eval('tempElem.' + param + ' = params.' + param);
	}
	
	return tempElem;
}

/** disableContextMenu - Turn off the right-click default behaviour in the
browser for the passed element. {
	category:"method",
	arguments:[{
		name:"obj",
		type:"object",
		desc:"The element name to disable right-click context menus for.",
	}],
} **/
var disableContextMenu = function (obj) {
	if (obj != null) {
		//this.log('Disabling context menus for ' + obj, 'info');
		obj.oncontextmenu = function () { return false; }
	} else {
		//this.log('Disabling context menus for ' + obj + ' did not work', 'error');
	}
}

/** cloneArray - Clones an array without maintaining references. Only
removes references for first level objects. {
	category:"method",
	arguments:[{
		name:"arr",
		type:"array",
		desc:"The array to clone.",
	}],
} **/
var cloneArray = function (arr) {
	var newArr = {};
	var arrCount = arr.length;
	while (arrCount--) {
		newArr[arrCount] = arr[arrCount];
	}
	
	return newArr;
}

/** cloneArray - Clones an object without maintaining references. Only
removes references for first level objects. {
	category:"method",
	arguments:[{
		name:"obj",
		type:"object",
		desc:"The object to clone.",
	}],
} **/
var cloneObject = function (obj) {
	var newObj = {};
	for (var i in obj) {
		newObj[i] = obj[i];
	}
	
	return newObj;
}

/** removePx - Removes a px string from the end of the passed string. {
	category:"method",
	arguments:[{
		name:"str",
		type:"string",
		desc:"The string to remove px from.",
	}],
} **/
var removePx = function (str) {
	return ~~(1 * str.substr(0, str.length - 2));
}

/** Array.prototype.indexOf - Adds the indexOf method to all
array objects if it does not already exist which would you
believe can still happen. {
	category:"method",
} **/
if(!Array.prototype.indexOf){
	Array.prototype.indexOf = function(obj){
		for(var i = 0, l = this.length; i < l; i++){
			if(this[i]==obj){
				return i;
			}
		}
		return -1;
	}
}

/** dec2hex - Converts decimal to hexadecimal. {
	category:"method",
	arguments:[{
		name:"i",
		type:"number",
		desc:"The number to convert.",
	}],
} **/
function dec2hex(i) {
	var result = "0000";
	if      (i >= 0    && i <= 15)    { result = "00000" + i.toString(16); }
	else if (i >= 16   && i <= 255)   { result = "0000"  + i.toString(16); }
	else if (i >= 256  && i <= 4095)  { result = "000"   + i.toString(16); }
	else if (i >= 4096 && i <= 65535) { result = "00"    + i.toString(16); }
	else if (i >= 65536  && i <= 1048575)  { result = "0"+ i.toString(16); }
	else if (i >= 1048576 && i <= 16777215) { result =     i.toString(16); }
	return result;
}

/** window.requestAnimFrame - A cross-browser requestAnimFrame method. {
	category:"method",
} **/
if (typeof(window) != 'undefined') {
	/*window.requestAnimFrame = (function(){
		return function(callback, element){
			setTimeout(callback, 200);
		};
	})();
	*/
	window.requestAnimFrame = (function(){
		return  window.requestAnimationFrame       || 
				window.webkitRequestAnimationFrame || 
				window.mozRequestAnimationFrame    || 
				window.oRequestAnimationFrame      || 
				window.msRequestAnimationFrame     || 
		function(callback, element){
			setTimeout(callback, 1000 / 60);
		};
	})();
	
} else {
	requestAnimFrame = function(callback, element){
		setTimeout(callback, 1000 / 60);
	};
}