/** IgeModules - DEPRECIATED - Provides modules management methods to the extending class.
This class is designed to be extended and does not do anything by itself. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeModules = new IgeClass({
	init: function () {},
	
	includeModule: function (modName) {
		/* CEXCLUDE */
		if (this.isServer) {
			// Load the config data for the named module
			var configDataSandbox = {};
			try {
				var fileData = this.fs.readFileSync('./engine/modules/' + modName + '/config.js');
			} catch (err) {
				this.log('Error, cannot load file ' + __dirname + '/./engine/modules/' + modName + '/config.js', 'error');
			}
			if (fileData != null) {
				this.vm.runInNewContext(fileData, configDataSandbox);
				if (configDataSandbox.config.moduleName) {
					if (configDataSandbox.config.serverSide && configDataSandbox.config.clientSide) {
						this.loadModule(configDataSandbox.config.moduleName, './engine/modules/' + modName + '/index', './engine/modules/' + modName + '/index');
					}
					if (configDataSandbox.config.serverSide && !configDataSandbox.config.clientSide) {
						this.loadModule(configDataSandbox.config.moduleName, './engine/modules/' + modName + '/index', null);
					}
					if (!configDataSandbox.config.serverSide && configDataSandbox.config.clientSide) {
						this.loadModule(configDataSandbox.config.moduleName, null, './engine/modules/' + modName + '/index');
					}
				} else {
					this.log('Module cannot be loaded because the config does not contain a moduleName property!', 'warning');
				}
			}
		}
		/* CEXCLUDE */
	},
	
	/** loadModule - Load a module into the engine. The path argument determines the
	server-side path of the module and the url is given to connecting clients to allow
	them to load the module. If path is omitted, the module will not be loaded server-
	side. If url is omitted, the module will not be loaded client-side. {
		category:"method",
		engine_ver:"0.1.3",
		arguments: [{
			type:"object",
			name:"modName",
			desc:"The name of the module class you are loading.",
		}, {
			type:"object",
			name:"path",
			desc:"The server-side path for Node.js to access and load the module's main script. Can be null if no server-side access is required for the module.",
		}, {
			type:"object",
			name:"url",
			desc:"The client-side path for clients to access and load the module's main script. Can be null if no client-side access is required for the module.",
			flags:"optional",
		}],
	} **/
	loadModule: function (modName, path, url) {
		this._moduleList = this._moduleList || [];
		this._moduleList.push([modName, path, url]);
		
		/* CEXCLUDE */
		if (this.isServer) {
			if (path != null) {
				this._moduleCount++;
				this.emit('loadingModule', [modName, path]);
				
				// Require module main file
				this.log('Loading module "' + modName + '" from path: ' + process.cwd() + '/' + path);
				require(process.cwd() + '/' + path);
				
				// Create module instance
				this.log('Init module "' + modName + '" from path: ' + path);
				var moduleInstanceName = 'module_' + this._moduleCount + new Date().getTime();
				eval(moduleInstanceName + ' = new ' + modName + '(this);');
				
				// Init module framework methods
				var methodName = '';
				for (var i in this._moduleFrameworkMethods) {
					methodName = this._moduleFrameworkMethods[i];
					if (!this.safeCall(eval(moduleInstanceName), methodName)) { this.log('Module "' + modName + '" does not implement framework method "' + methodName + '"', 'warning', null, true); }
				}
								
				this.emit('moduleLoaded', [modName, path]);
				this.setModuleLoaded(modName);
			}
			if (url != null) {
				this._moduleListClientData.push([modName, url]);
				this.log('Module added to client load queue with url: ' + url);
			}
		}
		/* CEXCLUDE */
		
		if (!this.isServer) {
			// We're client-side so just load the client-side module into the engine
			this._loadModule([[modName, url]]);
		}
	},
	
	/* CEXCLUDE */
	/** sendClientModuleList - Sends a network message to the specified client detailing
	all client-side modules that the server wants the client to load. {
		category:"method",
		engine_ver:"0.1.3",
		flags:"server",
		arguments: [{
			type:"object",
			name:"client",
			desc:"The socket.io client object to send the data to.",
		}],
	} **/
	sendClientModuleList: function (client) {
		if (this.isServer) {
			// Check if we've got any modules to send
			if (this._moduleListClientData.length) {
				this.network.send('loadModule', [this._moduleListClientData], client);
			}
		}
	},
	/* CEXCLUDE */
	
	/** _loadModule - Called when a network message is received by a client to load client-
	side module scripts. {
		category:"method",
		engine_ver:"0.1.3",
		arguments: [{
			type:"array",
			name:"data",
			desc:"A multi-dimensional array of module data.",
		}],
	} **/
	_loadModule: function (data) {
		// Load the module code
		this._moduleCount++;
		if (!this.isServer) {
			// Client-side
			for (var i = 0; i < data.length; i++) {
				// Ask the bootstrap class to require this module file and fire the callback
				// method we're supplying when the file is loaded.
				this.emit('loadingModule', [data[0], data[1]]);
				this.log('Asking bootstrap to load module file for ' + data[i][1]);
				this.log("Bootstrap Busy: " + igeBootstrap.busy, "Bootstrap Queue Length: " + igeBootstrap.queue.length);
				igeBootstrap.require(data[i][1], data[i][0], this.bind(function (fileData) {
					if (fileData[1]) {
						// We were passed the name of the class created by this module
						// so create a new instance of the class now. Many modules can
						// simply add themselves to the engine which is passed to the
						// module's init as an argument in the call below.
						this.setModuleLoaded(fileData[0]);
						this.log('Bootstrap Loaded Module: ' + fileData[0]);
						
						// Create the new module instance
						var moduleInstanceName = 'module_' + this._moduleCount + new Date().getTime();
						eval(moduleInstanceName + ' = new ' + fileData[1] + '(this);');
						var moduleInstance = eval(moduleInstanceName);
						
						// Init module framework methods
						var methodName = '';
						for (var i in this._moduleFrameworkMethods) {
							methodName = this._moduleFrameworkMethods[i];
							if (!this.safeCall(moduleInstance, methodName)) {
								this.log('Module "' + moduleInstance._className + '" does not implement framework method "' + methodName + '"', 'warning', null, true);
							} else {
								this.log('Executed module ' + moduleInstance._className + ' framework method: ' + methodName);
							}
						}
						
						this._moduleLoadedCount++;
						this.emit('moduleLoaded', [fileData[1], fileData[0]]);
						
						if (this._moduleLoadedCount == this._moduleCount) {
							this.emit('allModulesLoaded');
						}
					}
				}));
			}
			igeBootstrap.process();
		}
	},
	
	/** setModuleLoaded - Set the module's status to loaded. {
		category:"method",
		engine_ver:"0.2.0",
		arguments: [{
			type:"string",
			name:"moduleName",
			desc:"The name of the module to set as loaded.",
		}],
	} **/
	setModuleLoaded: function (moduleName) {
		this._loadedModules = this._loadedModules || [];
		this._loadedModules[moduleName] = true;
	},
	
	/** isModuleLoaded - Check if a module has loaded. {
		category:"method",
		engine_ver:"0.2.0",
		return: {
			type:"bool",
			desc:"Returns true if the module has been loaded or false otherwise.",
		},
		arguments: [{
			type:"string",
			name:"moduleName",
			desc:"The name of the module to check.",
		}],
	} **/
	isModuleLoaded: function (moduleName) {
		this._loadedModules = this._loadedModules || [];
		return this._loadedModules[moduleName] || false;
	},
});