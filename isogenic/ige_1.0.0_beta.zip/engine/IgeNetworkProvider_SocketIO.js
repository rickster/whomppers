/** IgeNetworkProvider_SocketIO - The socket.io network provider.
Allows a game to use the socket.io library for networking. {
	category:"class",
	externalLibs:[{
		name:"socket.io",
		desc:"Realtime Networking Library",
		url:"https://github.com/LearnBoost/socket.io",
	}],
} **/
IgeNetworkProvider_SocketIO = new IgeClass({
	/** networkProvider - The name of this network provider. {
		category:"property",
		type:"string",
	} **/
	networkProvider: 'socketio',
	
	/** state - Holds the current state of the provider. {
		category:"property",
		type:"integer",
	} **/
	state: 0,
	
	/** clientList - Holds an array of currently connected clients. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	clientList: [],
	
	/** setOptions - Sets the options for the network provider. {
		category:"method",
		arguments:[{
			name:"obj",
			type:"object",
			desc:"The options that you want to set for the provider.",
		}],
	} **/
	setOptions: function (obj) {
		this.io.socketio.options = obj;
		if (typeof(this.io.socketio.options.gameServer) == 'undefined') {
			// Set the host to null
			this.io.socketio.options.gameServer = '';
		}
	},
	
	/** providerInit - Initialises the provider by loading its
	required libraries etc. {
		category:"method",
	} **/
	providerInit: function () {
		if (typeof(this.io.socketio.options) == 'undefined') {
			this.io.socketio.options = {};
		}
		if (typeof(this.io.socketio.options.gameServer) == 'undefined') {
			this.io.socketio.options.gameServer = '';
		}
		
		this._state = 1;
		this.registerCommand('keepAlive', this.bind(this._keepAliveC), this.bind(this._keepAliveS));
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Load the socketio node module
			this.io.socketio.library = require(igeConfig.mapUrl('/node_modules/socket.io'));
			this.log('Network provider ready');
			this.emit('networkProviderReady');
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer) {
			// Ask the client to include our client-side library
			window.igeBootstrap.require(this.io.socketio.options.gameServer + '/socket.io/socket.io', 'socketioclient', this.bind(function () {
				this.log('Network provider ready');
				this.emit('networkProviderReady');
			}));
			
			if (!window.igeBootstrap.busy) {
				window.igeBootstrap.process.apply(window.igeBootstrap);
			}
		}
	},
	
	keepAlive: function (data, sessionId) {
		this.send('keepAlive');
		this.log('Sending keepAlive');
	},
	
	_keepAliveS: function (data, sessionId) {
		this.log('Received keepAlive');
		this.send('keepAlive', {}, sessionId);
	},
	
	_keepAliveC: function (data, sessionId) {
		this.log('Received keepAlive');
		this.send('keepAlive', {}, sessionId);
	},	
	
	/** _start - Called by IgeNetwork's start() method to ask
	the provider to start up. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"The callback method to call once the provider has started up successfully.",
		}],
	} **/
	_start: function (callback) {
		var self = this;
		this.io.socketio.onStart = callback;
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Set the socketio pipe settings and create instance
			this.log('Starting listener on port ' + this.engine.config.port);
			this.io.socketio.connection = this.io.socketio.library.listen(this.engine.config.port);
			this.io.socketio.connection.configure(this.bind(function () {
				if (this.debug) {
					this.io.socketio.connection.set('log level', 10);
				} else {
					this.io.socketio.connection.set('log level', 1);
				}
				//this.io.socketio.connection.set('heartbeat timeout', 8);
				//this.io.socketio.connection.set('heartbeat interval', 12);
				//this.io.socketio.connection.set('flash policy port', 843);
				this.io.socketio.connection.set('flash policy server', true);
				this.io.socketio.connection.disable('browser client minification');
				this.io.socketio.connection.set('transports', this.options.transports || [
					'websocket',
					//'flashsocket',
					'htmlfile',
					'xhr-polling',
					'jsonp-polling'
				]);
			}));
			
			// Listen for socketio client events
			this.io.socketio.connection.sockets.on('connection', function (client) {
				if (!self._serveClients) {
					self.log('Rejecting client connect, we are not serving clients yet!');
					client.disconnect();
				} else {
					self.emit('clientConnecting', client.id);
					
					client.on('message', function (data) {
						self._socketioServer_ClientMessage(data, client);
					});
					
					client.on('disconnect', function () {
						self.log('Client disconnected from session id ' + client.id);
						self.emit('clientDisconnect', client.id);
					});
					
					self.log('Client connected with session id ' + client.id + ' from IP ' + client.handshake.address.address + ':' + client.handshake.address.port);
					self.emit('clientConnect', client.id);
				}
			});
			
			// Set the socket as ready
			this.io.socketio.state = 2;
			
			// Setup the sync tick
			//setInterval(this.bind(this._sendSyncData), Math.floor(1000 / this._cl_updaterate));
			
			// Server is UP!!
			this.setState(5);
			this.emit('networkProviderUp');
			
			if (typeof(this.io.socketio.onStart) == 'function') {
				this.io.socketio.onStart.apply(this);
			}
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer) {
			// Create new socketio instance
			//this.io.socketio.options['connect timeout'] = 5000;
			this.io.socketio.connection = new io.connect(this.io.socketio.options.gameServer, this.io.socketio.options);
			
			// Listen for state changes
			this.io.socketio.connection.on('connect', function () {
				// Set the session ID as bug fixed by David Villareal
				self.engine.network.sessionId = this.socket.sessionid;
				
				this.on('message', function (data) {
					if (self.debug) {
						console.log(data);
					}
					self._socketioClient_Receive(data);
				});
				
				//setInterval(self.bind(this.keepAlive), 2000);
				
				// Set the socket as ready
				self.io.socketio.state = 2;
				
				self.emit('networkProviderUp');
				self.emit('serverConnect');
			});
			
			this.io.socketio.connection.on('disconnect', this.bind(function () {
				this.log('disconnect', 'info', arguments);
			}));
		}
	},
	
	/* CEXCLUDE */
	_socketioServer_ClientMessage: function(data, client) {
		// Decode the data packet
		var packet = this.decodePacket(data);
		var command = this._commandList._reverse[packet.cmdId];
		
		if (typeof(command) == 'undefined') {
			this.log('Error in network packet, command is undefined!', 'error', packet);
		} else {
			var packetData = packet.data || {};
			if (command == 'clientRequest') {
				//console.log('IGEN REQ DATA:', packet);
				var requestId = packetData.data.__igeRI;
				delete packetData.data.__igeRI;
				this.emit('clientRequest', {command:packetData.command, data:packetData.data, requestId:requestId, client:client.id});
			} else {
				this.emit(command, [packetData, client.id, packet, data]);
			}
		}
	},
	/* CEXCLUDE */
	
	// If socketio connects with us
	_socketioClient_Connect: function () {
		this.log('SocketIO API connected!');
		this.io.socketio.state = 2;
		
		// Emit an event that we are connected
		this.emit('serverConnect');
	},
	
	// If socketio has an error
	_socketioClient_Error: function () {
		this.log('SocketIO API error!', 'error', arguments);
		this.io.socketio.state = -1;
	},
	
	_socketioClient_Receive: function (data, client) {
		if (this._statsEnabled) {
			var bytes = JSON.stringify(data).length;
			this._dataRecv[new Date().getSeconds()] += bytes;
			this._dataRecvAll += bytes;
		}
		
		// Decode the data packet
		var packet = this.decodePacket(data);
		var command = this._commandList._reverse[packet.cmdId];
		if (this.debug) {
			console.log('Incomming server message:', command, packet);
		}
		
		if (typeof command == 'undefined') {
			this.log('Error in network packet, command is undefined!', 'error', packet);
		} else {
			var packetData = packet.data || {};
			if (command == 'serverResponse') {
				var requestId = packetData.__igeRI;
				var requestObj = this._requests[requestId];
				//delete finalData.data.__igeRI;
				if (typeof requestObj.callback == 'function') { requestObj.callback.apply(requestObj.callback, [packetData]); }
			} else {
				this.emit(command, [packetData, packet, data]);
			}
		}
	},
	
	/** _stop - Called by IgeNetwork's stop() method to ask
	the provider to shut down. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"The callback method to call once the provider has shut down successfully.",
		}],
	} **/
	_stop: function () {
		
	},
	
	/** send - The provder send method that will send data over
	the network. {
		category:"method",
		arguments:[{
			name:"command",
			type:"string",
			desc:"The command string of the command to send.",
		}, {
			name:"sendData",
			type:"object",
			desc:"The data object to send along with the command. Can be null.",
		}, {
			name:"socketId",
			type:"multi",
			desc:"The id of the socket to target the message at. If none is provided, the message will be sent to all connected clients (server only).",
		}, {
			name:"debug",
			type:"string",
			desc:"When set to the name of the command, will output debug messages as the send command is executed.",
		}],
	} **/
	send: function (command, sendData, clientId, debug, volatile) {
		// Check that we have a socket object to work with
		if (debug) { this.log('Send: Starting with arguments:', 'info', arguments); }
		if (this.io.socketio.state == 2) {
			if (sendData && sendData.$local != null) {
				var strippedData = this.engine.stripLocal(sendData);
			} else {
				var strippedData = sendData;
			}
			
			var cmdId = this._commandList[command];
			if (debug) { this.log('Send: Command ID is: ' + cmdId); }
			if (cmdId != null) {
				// Create and encode a new data packet
				var finalPacketData = this.encodePacket(this._commandList[command], strippedData);
				
				if (this._statsEnabled) {
					if (debug) { this.log('Send: Recording stats...'); }
					var bytes = JSON.stringify(finalPacketData).length;
					this._dataSend[new Date().getSeconds()] += bytes;
					this._dataSendAll += bytes;
				}
				
				if (command == debug) {
					this.log('Network original:', 'info', strippedData);
					/*if (strippedData != null && strippedData.template_contents != null) {
						console.log('Template object:', typeof(strippedData.template_contents));
						for (var i in strippedData.template_contents) {
							console.log(i, typeof(strippedData.template_contents[i]));
						}
					}*/
					this.log('Network sending:', 'info', this.decodePacket(finalPacketData));
				}
				// Depending upon if we are client or server, send the packet accordingly
				/* CEXCLUDE */
				if (this.engine.isServer) {
					// Server code
					if (clientId) {
						if (clientId instanceof Array) {
							// An array of client id's to send to
							if (debug) { this.log('Send: Sending to array of socketId\'s...'); }
							//console.log('Sending data to clients ID by array: ', clientId);
							for (var i in clientId) {
								if (volatile) {
									this.io.socketio.connection.sockets.socket(clientId[i]).volatile.json.send(finalPacketData);
								} else {
									this.io.socketio.connection.sockets.socket(clientId[i]).json.send(finalPacketData);
								}
							}
						} else if (typeof clientId == 'object') {
							// A single client object to send to
							if (debug) { this.log('Send: Sending to a single client object with session: ' + clientId.id); }
							//console.log('Sending data to client ID by object: ', clientId.id);
							if (volatile) {
								clientId.volatile.json.send(finalPacketData);
							} else {
								clientId.json.send(finalPacketData);
							}
						} else {
							// A single client id to send to
							if (debug) { this.log('Send: Sending to a single client with session: ' + clientId); }
							//console.log('Sending data to client ID: ', clientId);
							if (volatile) {
								this.io.socketio.connection.sockets.socket(clientId).volatile.json.send(finalPacketData);
							} else {
								this.io.socketio.connection.sockets.socket(clientId).json.send(finalPacketData);
							}
						}
					} else {
						if (debug) { this.log('Send: Sending broadcast...'); }
						//this.socket.sockets.json.send('test');
						if (volatile) {
							this.io.socketio.connection.sockets.volatile.json.send(finalPacketData);
						} else {
							this.io.socketio.connection.sockets.json.send(finalPacketData);
						}
					}
				}
				/* CEXCLUDE */
				if (!this.engine.isServer){
					// Client code
					//console.log('Sending data to server...');
					//console.log(this.socket.send);
					if (volatile) {
						this.io.socketio.connection.volatile.json.send(finalPacketData);
					} else {
						this.io.socketio.connection.json.send(finalPacketData);
					}
				}
				return true;
			} else {
				this.log('Attempted to send a network packet using a command that does not exist!', 'warning', command);
				return false;
			}
		} else {
			this.log('SocketIO state error, cannot send messages in this state!', 'warning', this.io.socketio.state);
		}
	},
	
});

// Register this provider with the network class
IgeNetwork.prototype.io = IgeNetwork.prototype.io || [];
IgeNetwork.prototype.io.socketio = {};
IgeNetwork.prototype.io.socketio.classMethod = IgeNetworkProvider_SocketIO;
