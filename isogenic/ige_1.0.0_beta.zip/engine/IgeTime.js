/** IgeTime - Time management class. {
	category:"class",
} **/
IgeTime = new IgeClass({
	Extends: IgeEvents,
	
	engine: null,
	network: null,
	
	/** serverTimeDiff - The time difference between the server and client
	clocks. When you receive a packet from the server, add this value to the
	packet's timestamp to convert from server to client time. {
		category:"property",
		engine_ver:"1.0.0",
	} **/
	serverTimeDiff: null,
	totalServerToClientClockLatency: null,
	clientSync: null,
	clientNetLag: null,
	clientNetLatency: null,
	clientNetDiff: null,
	netSyncCount: null,
	intervalNetSync: null,
	_latencyHistory: null,
	
	byIndex:[],
	
	init: function (engine) {
		this._className = 'IgeTime';
		
		this.engine = engine;
		this.byIndex = [];
		
		// Set a load of internal vars to zero
		this.serverTimeDiff = 0; // The time diff between server and client
		this.totalServerToClientClockLatency = 0;
		this.clientSync = 0;
		this.clientNetLag = 0;
		this.clientNetLatency = 0;
		this.clientNetDiff = 0;
		this.netSyncCount = 0;
		this.latestLatency = 0;
		this._latencyHistory = []; // Holds the last x number of latency times to produce an average
		
		this.options._debug = false;
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		this.network = this.engine.network;
		this.network.registerCommand('netSync', this.bind(this.netSyncReceived));
	},
	
	// Methods
	netSyncStart: function (delay, sampleCount, onlySchedule) {
		if (!onlySchedule) {
			if (typeof(sampleCount) == 'undefined') { sampleCount = 0; } // Default to 1 sample (base 0)
			this.network.send('netSync', new Date().getTime());
			if (this.netSyncCount < sampleCount) {
				this.netSyncCount++;
				setTimeout(this.bind(this.netSyncStart), 1000);
			} else {
				this.netSyncCount = 0;
			}
		}
		
		if (delay >= 500) {
			this.intervalNetSync = setInterval(this.bind(this.netSyncStart), delay);
			this.log('Network time sync is set to interval every ' + delay + ' milliseconds');
		}
	},
	
	netSyncReceived: function (data) {
		if (this.engine.isServer) {
			/* CEXCLUDE */
			// Send back the client's sent time and our current time
			var client = arguments[1];
			this.network.send('netSync', [data, new Date().getTime()], client, null, true);
			/* CEXCLUDE */
		} else {
			// Received the response from the server, work out the delta
			var latency = (new Date().getTime() - parseInt(data[0])) / 2; // Current time - client sent time divided by two (the entire round trip / 2)
			var timeDiff = (new Date().getTime() - parseInt(data[1])); // Current time - server sent time (the time difference from server to client clocks)
			
			if (this.options.debug) {
				this.log('Network clock sync returned Latency: ' + latency + ', TimeDiff: ' + timeDiff, 'info');
			}
			
			// Add the latest latency value to the history
			this._latencyHistory.push(latency);
			
			// Clearup the latency history
			if (this._latencyHistory.length > 10) {
				// Remove the first history entry
				this._latencyHistory.shift();
			}
			
			// Get the average latency over the history sample and store
			var averageLatency = parseFloat((this.averageArray(this._latencyHistory)).toFixed(1));
			
			this.latestLatency = latency; // Store the latest value for quick lookup
			this.clientNetLatency = averageLatency;
			this.clientNetLag = timeDiff;
			this.serverTimeDiff = timeDiff;
			
			// Set the value that all engine functions will use when computing time difference between server and client
			this.clientNetDiff = timeDiff + averageLatency;
			this.totalServerToClientClockLatency = timeDiff; // + averageLatency
		}
	},
	
	average: function () {
		var sum = 0;
		for (var i = 0, j = arguments.length; i < j; i++) {
			sum += arguments[i];
		}
		return sum / arguments.length;
	},
	
	averageArray: function (arr) {
		var sum = 0;
		for (var i = 0, j = arr.length; i < j; i++) {
			sum += arr[i];
		}
		return sum / arr.length;
	},
	
});