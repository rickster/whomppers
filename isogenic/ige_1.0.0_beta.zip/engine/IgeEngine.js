/** IgeEngine - The main class of the engine, all other class instances are accessible through this. {
	category:"class",
} **/

/** starting - Fired when the engine is starting up. {
	category: "event",
} **/
/** started - Fired when the engine has finished starting up. {
	category: "event",
} **/
/** stopped - Fired when the engine has been stopped. {
	category: "event",
} **/
/** loadingModule - Fired before a module is sent to the bootstrap clas to be loaded. {
	category: "event",
	engine_ver:"0.2.0",
	arguments: [{
		type:"string",
		name:"moduleName",
		desc:"The name of the module this event is about.",
	}, {
		type:"string",
		name:"moduleUrl",
		desc:"The url of the module this event is about.",
	}],
} **/
/** moduleLoaded - Fired after a module has loaded successfully. {
	category: "event",
	engine_ver:"0.2.0",
	arguments: [{
		type:"string",
		name:"moduleName",
		desc:"The name of the module this event is about.",
	}, {
		type:"string",
		name:"moduleUrl",
		desc:"The url of the module this event is about.",
	}],
} **/
IgeEngine = new IgeClass({
	Extends: [IgeEvents, IgeState, IgeUtils, IgeDataLoader],
	
	/** events - The events controller for this class. {
		category:"property",
		type:"object",
		instanceOf:"IgeEvents",
	} **/
	//events: null,
	
	/** events - The instance of this class. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** database - Instance of the IgeDatabase class. {
		category:"property",
		type:"object",
		instanceOf:"IgeDatabase",
	} **/
	database: null,
	
	/** network - Instance of the IgeNetwork class. {
		category:"property",
		type:"object",
		instanceOf:"IgeNetwork",
	} **/	
	network: null,
	
	/** templates - Instance of the IgeTemplates class. {
		category:"property",
		type:"object",
		instanceOf:"IgeTemplates",
	} **/
	templates: null,
	
	/** users - Instance of the IgeUsers class. {
		category:"property",
		type:"object",
		instanceOf:"IgeUsers",
	} **/	
	users: null,
	
	/** assets - Instance of the IgeAssets class. {
		category:"property",
		type:"object",
		instanceOf:"IgeAssets",
	} **/
	assets: null,
	
	/** animations - Instance of the IgeAnimations class. {
		category:"property",
		type:"object",
		instanceOf:"IgeAnimations",
	} **/
	animations: null,
	
	/** dirtyRects - Instance of the IgeDirtyRects class. {
		category:"property",
		type:"object",
		instanceOf:"IgeDirtyRects",
	} **/
	dirtyRects: null,
	
	/** maps - Instance of the IgeMaps class. {
		category:"property",
		type:"object",
		instanceOf:"IgeMaps",
	} **/
	maps: null,
	
	/** entities - Instance of the IgeEntities class. {
		category:"property",
		type:"object",
		instanceOf:"IgeEntities",
	} **/
	entities: null,
	
	/** paths - Instance of the IgePaths class. {
		category:"property",
		type:"object",
		instanceOf:"IgePaths",
	} **/
	paths: null,
	
	/** screens - Instance of the IgeScreens class. {
		category:"property",
		type:"object",
		instanceOf:"IgeScreens",
	} **/
	screens: null,
	
	/** cameras - Instance of the IgeCameras class. {
		category:"property",
		type:"object",
		instanceOf:"IgeCameras",
	} **/
	cameras: null,
	
	/** viewports - Instance of the IgeViewports class. {
		category:"property",
		type:"object",
		instanceOf:"IgeViewports",
	} **/
	viewports: null,
	
	/** ui - Instance of the IgeUi class. {
		category:"property",
		type:"object",
		instanceOf:"IgeUi",
	} **/
	ui: null,
	
	/** renderer - Instance of the IgeRenderer class. {
		category:"property",
		type:"object",
		instanceOf:"IgeRenderer",
	} **/
	renderer: null,
	
	/** time - Instance of the IgeTime class. {
		category:"property",
		type:"object",
		instanceOf:"IgeTime",
	} **/
	time: null,
	
	/** idFactory - Instance of the IgeIdFactory class. {
		category:"property",
		type:"object",
		instanceOf:"IgeIdFactory",
	} **/
	idFactory: null,
	
	/** pallete - Instance of the IgePallete class. {
		category:"property",
		type:"object",
		instanceOf:"IgePallete",
	} **/
	pallete: null,
	
	/** windowManager - Instance of the IgeWindow class. {
		category:"property",
		type:"object",
		instanceOf:"IgeWindow",
	} **/
	windowManager: null,
	
	/** defaultContext - The default context to use when aquiring a context from a canvas element before drawing to it. {
		category:"property",
		type:"string",
	} **/
	defaultContext: '2d',
	
	/** config - A reference to the configuration object passed to this class instance when it is created. {
		category:"property",
		type:"string",
		flags:"server",
	} **/	
	config: null,
	
	/** isServer - Is set to true if the engine is running as a server, false if not. {
		category:"property",
		type:"bool",
	} **/		
	isServer: false,
	
	/** isSlave - Is set to true if the engine is running as a slave (usually because another process has taken over the renderer, audio and sometimes networking), false if not. {
		category:"property",
		type:"bool",
	} **/		
	isSlave: false,
	
	/** _requirementList - An array of methods that must all return true when called before the engine will start. {
		category:"property",
		type:"integer",
		seeAlso:"registerRequirement",
	} **/	
	_requirementList: null,
	
	/** _loadedModules - An array with a string index holding boolean values denoting if a module is loaded or not. {
		category:"property",
		type:"array",
		index:"string",
	} **/	
	_loadedModules: null,
	
	/** _moduleFrameworkMethods - An array with an integer index holding string values of method names to call when initialising a module. {
		category:"property",
		type:"array",
		index:"integer",
	} **/	
	_moduleFrameworkMethods: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"opts",
			desc:"The options object that gives the engine information about how what mode it is in and how to execute rendering etc.",
		},
	} **/
	init: function (opts) {
		this._className = 'IgeEngine';
		
		this.engine = this;
		this._requirementList = [];
		
		this._preWorldTick = {
			client: [],
			server: [],
			both: [],
		};
		
		this._postWorldTick = {
			client: [],
			server: [],
			both: [],
		};
		
		if (typeof(IgeNetwork) != 'undefined') { this._IgeNetwork = true; } else { this._IgeNetwork = false; }
		if (typeof(IgeUsers) != 'undefined') { this._IgeUsers = true; } else { this._IgeUsers = false; }
		
		if (opts != null) {
			var config = opts.config;
			var slave = opts.isSlave;
		}
		
		/* Set if we are a server or not - passing a config object to the engine init when running
		client-side will break a lot of engine code... don't do it! */
		/* CEXCLUDE */
		if (config) {
			this.isServer = true;
			this.config = config;
			//this.obfuscator = new IgeObfuscate(this); // depreciated in 1.0.0
			this.log('Running in Node.js server mode.');
			this.vm = require('vm');
			this.fs = require('fs');
		}
		/* CEXCLUDE */
		
		if (slave) {
			this.isSlave = slave;
		}
		
		// Defined a load of item types as an enum
		this.itemType = new IgeEnum([
			'animation',
			'asset',
			'background',
			'camera',
			'entity',
			'map',
			'screen',
			'template',
			'viewport',
		]);
		
		// Make sure that all the engine parts that the engine relies on are loaded
		// and fire an error if we find one that isn't!
		
		// The order that these objects is created is of importance, best not to play with it,
		// as some of them rely on the others existing when they init.
		if (this.isServer) { this.database = new IgeDatabase(this); }
		if (this._IgeNetwork) { this.network = new IgeNetwork(this); }
		this.templates = new IgeTemplates(this);
		if (this._IgeUsers) { this.users = new IgeUsers(this); }
		this.gamepads = new IgeGamepad(this);
		this.animations = new IgeAnimations(this);
		this.assets = new IgeAssets(this);
		this.dirtyRects = new IgeDirtyRects(this);
		this.entities = new IgeEntities(this);
		this.screens = new IgeScreens(this);
		this.maps = new IgeMaps(this);
		this.paths = new IgePaths(this);
		this.cameras = new IgeCameras(this);
		this.viewports = new IgeViewports(this);
		this.backgrounds = new IgeBackgrounds(this);
		this.ui = new IgeUi(this);
		this.time = new IgeTime(this);
		this.idFactory = new IgeIdFactory(this);
		this.pallete = new IgePallete(this);
		this.windowManager = new IgeWindow(this);
		this.bootstrap = new IgeBootstrap(null, true);
		
		/* CEXCLUDE */
		if (this.isServer) {
			this._moduleList = [];
			this._moduleListClientData = [];
		}
		/* CEXCLUDE */
		
		//this.ui = new IgeUi(this);
		this.renderer = new IgeRenderer(this);
		
		this.firstTick = 0;
		this.lastTick = 0;
		this._moduleCount = 0;
		this._moduleLoadedCount = 0;
		
		// Define the default module framework methods
		this._moduleFrameworkMethods = [];
		if (this._IgeNetwork) {
			this._moduleFrameworkMethods.push('networkInit');
		}
		this._moduleFrameworkMethods.push('engineHooks');
		this._moduleFrameworkMethods.push('networkCommands');
		this._moduleFrameworkMethods.push('networkProperties');
		this._moduleFrameworkMethods.push('modules');
		this._moduleFrameworkMethods.push('moduleHooks');
		this._moduleFrameworkMethods.push('ready');
		
		if (!this.isSlave && !this.isServer) {
			this.intervalSecond = setInterval(this.bind(this.secondTick), 1000);
		}
		
		// Check if we have a network
		if (this._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}	
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		this.network.registerCommand('startClientEngine', this.bind(this.start));
		//this.network.registerCommand('loadModule', this.bind(this._loadModule));
	},
	
	/** preWorldTick - Registers a method that will be called on every world tick just
	before the renderer is invoked to render the scene for the current tick. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"function",
			name:"method",
			desc:"The method to add to the call list.",
		}, {
			type:"string",
			name:"locale",
			desc:"The locale that the passed method will be called in. Valid values are 'client', 'server' and 'both'. If none is specified the locale will default to 'both'.",
			default:"The locale will default to 'both' when none is specified.",
			validValues: [
				"client",
				"server",
				"both",
			],
		}],
	} **/
	preWorldTick: function (method, locale) {
		switch (locale) {
			case 'client':
				this._preWorldTick.client.push(method);
			break;
			
			case 'server':
				this._preWorldTick.server.push(method);
			break;
			
			default:
				this._preWorldTick.both.push(method);
			break;
		}
	},
	
	/** postWorldTick - Registers a method that will be called on every world tick just
	after the renderer is invoked to render the scene for the current tick. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"function",
			name:"method",
			desc:"The method to add to the call list.",
		}, {
			type:"string",
			name:"locale",
			desc:"The locale that the passed method will be called in. Valid values are 'client', 'server' and 'both'. If none is specified the locale will default to 'both'.",
			default:"The locale will default to 'both' when none is specified.",
			validValues: [
				"client",
				"server",
				"both",
			],
		}],
	} **/
	postWorldTick: function (method, locale) {
		switch (locale) {
			case 'client':
				this._postWorldTick.client.push(method);
			break;
			
			case 'server':
				this._postWorldTick.server.push(method);
			break;
			
			default:
				this._postWorldTick.both.push(method);
			break;
		}
	},
	
	/** setSlave - Tells the engine to switch to slave mode. {
		category:"method",
	} **/	
	setSlave: function () {
		this.isSlave = true;
	},
	
	/** registerRequirement - Stores the passed method in an array that is checked before the 
	engine is allowed to start. Every method in the list must return true before the engine
	will start. This allows modules to delay engine startup until they have loaded their
	required assets, scripts, files etc. {
		category:"method",
		engine_ver:"0.1.3",
		arguments: [{
			type:"function",
			name:"func",
			desc:"A method to add to the requirementList array that must return true when called before the engine will start.",
		}],
	} **/	
	registerRequirement: function (func) {
		this._requirementList.push(func);
	},
	
	/** start - Asks the engine to start! {
		category:"method",
	} **/	
	start: function () {
		if (!this._requirementCheckInterval) {
			this._requirementCheckInterval = setInterval(this.bind(this._requirementCheck), 50);
		}
	},
	
	/** _requirementCheck - Checks the requirement list by calling each method and recording the
	response. If all methods respond with true, the check interval will be cancelled and the 
	engine will be told to start. {
		category:"method",
		engine_ver:"0.1.3",
	} **/	
	_requirementCheck: function () {
		var responseOkCount = 0;
		if (this._requirementList.length > 0) {
			for (var i = 0; i < this._requirementList.length; i++) {
				if (this._requirementList[i].call()) {
					responseOkCount++;
				}
			}
		}
		
		if (responseOkCount == this._requirementList.length) {
			// Cancel the check interval
			clearInterval(this._requirementCheckInterval);
			// Start the engine
			this._start();
		}
	},
	
	/** _start - Called when all requirment list methods return true. This is the real start
	method. The one names "start" will kick-off the requirement list checker which will only
	call this method (_start) once all requirement list methods return true. This allows us
	to delay the start of the engine until all the different modules check in that they have
	loaded their required assets, files, data etc ok. {
		category:"method",
	} **/	
	_start: function () {
		this.emit('starting', this);
		/* CEXCLUDE */
		if (this.isServer) {
			// Server code
			this.log('Starting engine as server...');
			
			if (this.config.db) {
				this._startDb();
			} else {
				this.log('No database configuration, assuming non-persistent game environment.');
				this._startServer();
			}
		}
		/* CEXCLUDE */
		
		if (!this.isServer) {
			// Client code
			this.log('Starting engine as client...');
			this._started();
		}
	},
	
	/* CEXCLUDE */
	
	/** startClient - Issue a network command to a client to start the client engine. When the
	client receives this command it will automatically start itself and start rendering any
	active viewports etc. Once this command is issued, no further action is required for the
	engine to start. {
		category:"method",
		flags:"server",
		arguments: [{
			type:"object",
			name:"client",
			desc:"The socket.io client object to send the data to.",
		}],
	} **/	
	startClient: function (client) {
		this.network.send('startClientEngine', null, client);
	},
	
	/** _startDb - Starts the database connection process on the server. {
		category:"method",
		flags:"server",
	} **/	
	_startDb: function () {
		this.log('Starting database connect...');
		this.database.setProvider(this.config.db.type);
		this.database.setOptions(this.config.db);
		this.database.on('connected', this.bind(function () { this._startServer(); }));
		this.database.on('connectionError', this.bind(function () { this._databaseError(); }));
		this.database.connect();
	},
	
	/** _databaseError - Called by the database module when an error occurs with the database. {
		category:"method",
		flags:"server",
	} **/
	_databaseError: function () {
		console.log('Could not connect to the database!');
	},
	
	/** _startServer - Asks the network module to start up in server mode. {
		category:"method",
		flags:"server",
	} **/
	_startServer: function () {
		this.network.on('serverStarted', this.bind(function () { this._started(); }));
		this.log('Starting VM...');
		this.emit('initVM');
	},
	
	/** _serverStarted - Called when the network module has successfully started up in server mode. {
		category:"method",
		flags:"server",
	} **/
	_serverStarted: function () {
		this.intervalRender = setInterval(this.bind(this._worldTick), 1000 / 60);
		this.log('Engine started as server!');
	},
	/* CEXCLUDE */
	
	/** _started - Called when the engine has started and will fire a 'started' event. {
		category:"method",
	} **/
	_started: function () {
		this.state(ENGINE_STATE_STARTED);
		
		if (this.isServer) {
			/* CEXCLUDE */
			this._serverStarted();
			/* CEXCLUDE */
		} else {
			// Client-side startup
			this._clientStarted();
		}
		
		this.emit('started');
	},
	
	/** _clientStarted - Called when the engine has started and is in client mode. {
		category:"method",
	} **/
	_clientStarted: function () {
		this.log('Engine started as client!');
		
		this._worldTickCount = 0;
		this.renderer.statsOn = true;
		
		if (!this.isSlave) {
			requestAnimFrame(this.bind(this._worldTick));
		}
		
	},
	
	/** _worldTick - Called upon each world tick interval by a timer. Processes all the
	required logic for each world tick. {
		category:"method",
		arguments: [{
			type:"bool",
			name:"noSched",
			desc:"When set to true, the method will not schedule another call of itself after it finishes.",
		}],
	} **/
	_worldTick: function (noSched) {
		// If the engine is still running
		if (!this.isServer) {
			if (noSched == true) {
				// Don't schedule another re-tick from this one
			} else if (this.state() == ENGINE_STATE_STARTED) {
				// The engine is still running so schedule another tick now
				// before processing any other commands
				requestAnimFrame(this.bind(this._worldTick));
			}
		}
		
		var tickStart = new Date().getTime();
		
		// Adjust the tickStart value by the difference between the server and the client
		tickStart -= this.time.clientNetDiff;
		this._worldTickCount++;
		
		if (!this.lastTick) {
			this.lastTick = 0;
			this.currentDelta = tickStart;
			if (!this.isServer) {
				// We're not the server so resize any auto-resizing viewports
				this.screens._doAutoSize();
			}
		} else {
			this.currentDelta = tickStart - this.lastTick;
		}
		
		this.lastTick = tickStart;
		
		// Setup pre-post world-tick arguments and array references
		var args = [this.currentDelta, tickStart];
		var preT = this._preWorldTick;
		var postT = this._postWorldTick;
		
		// Process any pre-world-tick methods
		if (this.isServer) { this._processMethodArray(preT.server, args); }
		if (!this.isServer) { this._processMethodArray(preT.client, args); }
		this._processMethodArray(preT.both, args);
		
		// Execute on client and server
		this.paths.processPaths(this.lastTick); //this.currentDelta
		
		// If we're the client
		if (!this.isServer) {
			this.entities.processInterpolation(this.currentDelta);
			this.entities.processAnimation(this.currentDelta);
			this.renderer.render2(this.currentDelta);
		}
		
		// Process any post-world-tick methods
		if (this.isServer) { this._processMethodArray(postT.server, args); }
		if (!this.isServer) { this._processMethodArray(postT.client, args); }
		this._processMethodArray(postT.both, args);
	},
	
	/** secondTick - Called upon each second tick interval by a timer. Calculates
	current FPS and other stats values and displays them on-screen if a DOM element
	with the ID 'igeLogDiv' exists. {
		category:"method",
	} **/	
	secondTick: function () {
		this.currentRenderFps = this._worldTickCount; // Store current tick count
		this._worldTickCount = 0; // Reset tick count
		
		if (this.options.logPerf) {
			if (!this.isSlave && !this.isServer) {
				if (document.getElementById('igeLogDiv') != null) {
					var statusString = '';
					statusString += this.currentRenderFps + ' fps | ';
					statusString += 'Ping: ' + this.time.latestLatency + 'ms (' + (this.time.clientNetLatency) + 'ms) | ';
					if (this.network && this.network._statsEnabled) {
						statusString += 'Sent: ' + this.network._dataSendAll + ' bytes | ';
						statusString += 'Recv: ' + this.network._dataRecvAll + ' bytes | ';
					}
					statusString += this.entities.byIndex.length + ' entities | ';
					statusString += this.renderer.renderCount + ' draws/sec | ';
					document.getElementById('igeLogDiv').innerHTML = statusString;
				}
			}
		}
		
		this.renderer.renderCount = 0;
	},
	
	/** stop - Stops the engine. {
		category:"method",
	} **/	
	stop: function () {
		this.log('Stopping engine...');
		/* CEXCLUDE */
		if (this.isServer) {
			// Server code
			this.server.stop();
		}
		/* CEXCLUDE */
		if (!this.isServer) {
			// Client code
			// kill all the timers! (except if we are slave, then only kill ones that slave uses)
			clearInterval(this.intervalSecond);
			//clearInterval(this.intervalRender);
			this._stopped();
		}
	},
	
	/** _stopped - Called when the engine has stopped. Will fire a 'stopped' event. {
		category:"method",
	} **/		
	_stopped: function () {
		this.state(ENGINE_STATE_STOPPED);
		this.emit('stopped');
		this.log('Engine state set to stopped.');
	},
	
});