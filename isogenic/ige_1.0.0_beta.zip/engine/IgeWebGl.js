IgeWebGl = new IgeClass({
	
	Extends: IgeEvents,
	
	engine: null,
	
	// Constructor
	init: function (engine) {
		this._className = 'IgeWebGl';
		
		this.engine = engine;
	},
	
	
	
});