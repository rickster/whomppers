/** IgeTransform - Provides transformation methods to the extending class. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeTransform = new IgeClass({
	/** init - The constructor for this class. {
		category:"method",
	} **/
	init: function () {
		this.transformProp = new IgeEnum([
			// Translate
			'translateX',
			'translateY',
			'translateZ',
			// Rotate
			'rotateX',
			'rotateY',
			'rotateZ',
			// Scale
			'scaleX',
			'scaleY',
			'scaleZ',
			// Origin
			'originX',
			'originY',
			'originZ',
			// Opacity
			'opacityX',
			'opacityY',
			'opacityZ',
		]);
	},
	
	/** applyTransform - Applies transform data to an item based upon
	the transform information held in either the item itself or the passed
	transform object. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns true on success or false on error.",
		},
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to apply transform data to.",
		}, {
			name:"transform",
			type:"object",
			desc:"If supplied, will overide any existing transform data held in the item.",
			flags:"optional",
		}],
	} **/
	applyTransform: function (pItem, transform) {
		// Check if we were given a new transform object as a method argument
		if (typeof(transform) == 'undefined') {
			// Check if the item already has a transform object property
			if (typeof(pItem._transform) == 'undefined') {
				// We don't have any transform object so see if we have some
				// transform instructions in the item
				if (typeof(pItem[this.collectionId + '_transform']) != 'undefined') {
					transform = pItem[this.collectionId + '_transform'];
				} else {
					// We have no transform data at all... see if we have legacy data and
					// set the equivelent non-legacy values
					pItem[this.collectionId + '_transform'] = {}; // make a blank object
					transform = {};
					
					// Legacy tile-based translate
					if (typeof(pItem.entity_x) != 'undefined' && typeof(pItem.entity_y) != 'undefined') {
						transform.translate = [
							pItem.entity_x,
							pItem.entity_y,
							pItem.entity_z || 0,
							false, // Non-relative
							true, // Tile-based
						];
						this.log('entity_x and entity_y are depreciated. Please use the new entity_transform object.', 'depreciated');
					}
					
					// Legacy world-based translate
					if (typeof(pItem.entity_actual_x) != 'undefined' && typeof(pItem.entity_actual_y) != 'undefined') {
						transform.translate = [
							pItem.entity_actual_x,
							pItem.entity_actual_y,
							pItem.entity_actual_z || 0,
							false, // Non-relative
							false, // Non-tile-based
						];
						this.log('entity_actual_x and entity_actual_y are depreciated. Please use the new entity_transform object.', 'depreciated');
					}
					
					// Legacy tile-based scale
					if (typeof(pItem.entity_tile_width) != 'undefined' && typeof(pItem.entity_tile_height) != 'undefined') {
						transform.scaleTarget = [
							pItem.entity_tile_width,
							pItem.entity_tile_height,
							pItem.entity_tile_depth || 1,
							true, // Tile-based
						];
						this.log('entity_tile_width and entity_tile_height are depreciated. Please use the new entity_transform object.', 'depreciated');
					}
					
					// Legacy world-based scale
					if (typeof(pItem.entity_actual_width) != 'undefined' && typeof(pItem.entity_actual_height) != 'undefined') {
						transform.scaleTarget = [
							pItem.entity_actual_width,
							pItem.entity_actual_height,
							pItem.entity_actual_depth || 0,
							false, // Non-tile-based
						];
						this.log('entity_actual_width and entity_actual_height are depreciated. Please use the new entity_transform object.', 'depreciated');
					}
					
					// Legacy opacity
					if (typeof(pItem.entity_opacity) != 'undefined') {
						transform.opacity = [
							pItem.entity_opacity,
							pItem.entity_opacity,
							pItem.entity_opacity,
							false, // Non-relative
						];
						this.log('entity_opacity is depreciated. Please use the new entity_transform object.', 'depreciated');
					}
				}
			} else {
				// There was no new transform data argument and the item already has
				// transform data in the _transform property so exit without changing
				// anything because we don't have anything to update from!
				return false;
			}
		}
		
		// Create a new transformation array for this item
		// if one does not already exist
		if (typeof(pItem._transform) == 'undefined') {
			// Set the current item size to it's original size
			if (pItem.$local && pItem.$local.$originalSize) {
				pItem._size = pItem.$local.$originalSize;
			} else {
				// Set a default size of 10x10 pixels and warn
				pItem._size = [10, 10];
				this.log('Setting default size of item because no size exists in the item.$local.$originalSize variable. This variable is usually set by the width/height of an entity\'s asset or the width/height variables in the item itself.', 'warning', pItem);
			}
			// Create a pre-filled array
			pItem._transform = [
				0.0, 0.0, 0.0, // position
				0.0, 0.0, 0.0, // rotation
				1.0, 1.0, 1.0, // scale
				0.5, 0.5, 0.5, // origin
				1.0, 1.0, 1.0, // opacity
			];
		}
		
		if (transform) {
			// Check for origin
			if (typeof(transform.origin) != 'undefined') {
				if (!this.origin(
					pItem,
					transform.origin[0], // x
					transform.origin[1], // y
					transform.origin[2], // z
					transform.origin[3]  // relative
				)) {
					this.log('Transform::origin() failed');
					return false;
				}
			}				
			
			// Check for translate
			if (typeof(transform.translate) != 'undefined') {
				if (!this.translate(
					pItem,
					transform.translate[0], // x
					transform.translate[1], // y
					transform.translate[2], // z
					transform.translate[3], // relative
					transform.translate[4]  // tile-based
				)) {
					this.log('Transform::translate() failed');
					return false;
				}
			}
			
			// Check for rotate
			if (typeof(transform.rotate) != 'undefined') {
				if (!this.rotate(
					pItem,
					transform.rotate[0], // x
					transform.rotate[1], // y
					transform.rotate[2], // z
					transform.rotate[3]  // relative
				)) {
					this.log('Transform::rotate() failed');
					return false;
				}
			}
			
			// Check for scale
			if (typeof(transform.scale) != 'undefined') {
				if (!this.scale(
					pItem,
					transform.scale[0], // x
					transform.scale[1], // y
					transform.scale[2], // z
					transform.scale[3], // relative
					transform.scale[4]  // tile-based
				)) {
					this.log('Transform::scale() failed');
					return false;
				}
			}
			
			// Check for opacity
			if (typeof(transform.opacity) != 'undefined') {
				if (!this.opacity(
					pItem,
					transform.opacity[0], // x
					transform.opacity[1], // y
					transform.opacity[2], // z
					transform.opacity[3]  // relative
				)) {
					this.log('Transform::opacity() failed');
					return false;
				}
			}
			
			// Check for scale target - this sets the scale based upon
			// a target width/height and the original width/height of
			// the item
			if (typeof(transform.scaleTarget) != 'undefined') {
				if (!this.scaleToTarget(
					pItem,
					transform.scaleTarget[0], // x
					transform.scaleTarget[1], // y
					transform.scaleTarget[2], // z
					transform.scaleTarget[3]  // tile-based
				)) {
					this.log('Transform::scaleTarget() failed');
					return false;
				}
			}
			return true;
		}
	},
	
	/** translate - Translates (moves) the item's position to the new co-ordinates
	specified. If tileBased is set to true the passed co-ordinates will be taken
	as tile co-ordinates and converted from tile to world co-ordinates when applied. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"X value to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"Y value to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"Z value to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}, {
			name:"tileBased",
			type:"bool",
			desc:"If set to true, takes the X, Y, Z co-ordinates passed as tile rather than world co-ordinates and converts them to world co-ordinates before applying them to the item.",
		}],
	} **/
	translate: function (pItem, x, y, z, relative, tileBased) {
		pItem._transform = pItem._transform || [];
		if (arguments.length > 1) {
			// Is the item initialised?
			if (pItem.$local) {
				// Grab some variables and set some defaults
				if (typeof(x) == 'undefined') { x = 0; }
				if (typeof(y) == 'undefined') { y = 0; }
				if (typeof(z) == 'undefined') { z = 0; }
				
				var oldX = x;
				var oldY = y;
				var oldZ = z;
				
				// Check if the movement is based on tile co-ordinates
				if (tileBased && pItem.$local.$map) {
					// Multiply the co-ordinates by tile size to get world co-ordinates
					var map = pItem.$local.$map;
					x *= map.map_tilesize;
					y *= map.map_tilesize;
					z *= map.map_tilesize;
				}
				
				// Calculate the final values
				var fx = 0, fy = 0, fz = 0;
				
				if (relative) {
					fx = pItem._transform[0] + x;
					fy = pItem._transform[1] + y;
					fz = pItem._transform[2] + z;
				} else {
					fx = x;
					fy = y;
					fz = z;
				}
				
				// Check if any values are different and bug out if not
				if (fx != pItem._transform[0] || fy != pItem._transform[1] || fz != pItem._transform[2]) {
					// Call the receiver method if it exists
					var cancelAction = false;
					
					if (typeof(this._beforeTranslate) == 'function') {
						cancelAction = this._beforeTranslate(pItem, [oldX, oldY, oldZ, x, y, z, fx, fy, fz], relative, tileBased);
					}
					
					if (!cancelAction) {
						if (!this.emit('beforeTranslate', pItem)) {
							// Assign world co-ordinates
							pItem._transform[0] = fx;
							pItem._transform[1] = fy;
							pItem._transform[2] = fz;
							
							// Call the receiver method if it exists
							if (typeof(this._afterTranslate) == 'function') {
								this._afterTranslate(pItem, x, y, z, relative, tileBased);
							}
							this.emit('afterTranslate', pItem);
							
							return true;
						}
					} else {
						return false;
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			// We are not updating, simly return the value
			return [pItem._transform[0], pItem._transform[1], pItem._transform[2]];
		}
	},
	
	/** rotate - Rotates the item to the new angle specified in degrees. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"Angle in degrees along the X plane to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"NOT CURRENTLY USED - A HOLDING ARGUMENT FOR LATER 3D USE - Angle in degrees along the Y plane to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"NOT CURRENTLY USED - A HOLDING ARGUMENT FOR LATER 3D USE - Angle in degrees along the Z plane to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}],
	} **/
	rotate: function (pItem, x, y, z, relative) {
		pItem._transform = pItem._transform || [];
		if (arguments.length > 1) {
			// Is the item initialised?
			if (pItem.$local) {
				// Grab some variables and set some defaults
				if (typeof(x) == 'undefined') { x = 0; }
				if (typeof(y) == 'undefined') { y = 0; }
				if (typeof(z) == 'undefined') { z = 0; }
				
				// Calculate the final values
				var fx = 0, fy = 0, fz = 0;
				
				if (relative) {
					fx = pItem._transform[3] + x;
					fy = pItem._transform[4] + y;
					fz = pItem._transform[5] + z;
				} else {
					fx = x;
					fy = y;
					fz = z;
				}
				
				// Check if any values are different and bug out if not
				if (fx != pItem._transform[3] || fy != pItem._transform[4] || fz != pItem._transform[5]) {
					// Call the receiver method if it exists
					var cancelAction = false;
					
					if (typeof(this._beforeRotate) == 'function') {
						cancelAction = this._beforeRotate(pItem, [x, y, z, x, y, z, fx, fy, fz], relative);
					}
					
					if (!cancelAction) {
						if (!this.emit('beforeRotate', pItem)) {
							// Assign world rotation
							pItem._transform[3] = fx;
							pItem._transform[4] = fy;
							pItem._transform[5] = fz;
							
							// Call the receiver method if it exists
							if (typeof(this._afterRotate) == 'function') {
								this._afterRotate(pItem, x, y, z, relative);
							}
							this.emit('afterRotate', pItem);
							
							return true;
						}
					} else {
						return false;
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			// We are not updating, simly return the value
			return [pItem._transform[3], pItem._transform[4], pItem._transform[5]];
		}
	},
	
	/** scale - Scales the item to the new X, Y and Z scales specified. Specifying a
	scale value of 1.0 make the item match it's original scale. Less than 1.0 reduces
	the item's scale and more than 1.0 increases the item's scale. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"X value to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"Y value to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"Z value to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}],
	} **/
	scale: function (pItem, x, y, z, relative, tileBased) {
		pItem._transform = pItem._transform || [];
		if (arguments.length > 1) {
			// Is the item initialised?
			if (pItem.$local) {
				// Grab some variables and set some defaults
				if (typeof(x) == 'undefined') { x = 1; }
				if (typeof(y) == 'undefined') { y = 1; }
				if (typeof(z) == 'undefined') { z = 1; }
				
				var oldX = x;
				var oldY = y;
				var oldZ = z;
				
				if (tileBased && pItem.$local.$map) {
					// Multiply the co-ordinates by tile size to get world co-ordinates
					var map = pItem.$local.$map;
					x *= map.map_tilesize;
					y *= map.map_tilesize;
					z *= map.map_tilesize;
				}
				
				// Calculate the final values
				var fx = 0, fy = 0, fz = 0;
				
				if (relative) {
					fx = pItem._transform[6] + x;
					fy = pItem._transform[7] + y;
					fz = pItem._transform[8] + z;
				} else {
					fx = x;
					fy = y;
					fz = z;
				}
				
				// Check if any values are different and bug out if not
				if (fx != pItem._transform[6] || fy != pItem._transform[7] || fz != pItem._transform[8]) {
					// Call the receiver method if it exists
					var cancelAction = false;
					
					if (typeof(this._beforeScale) == 'function') {
						cancelAction = this._beforeScale(pItem, [oldX, oldY, oldZ, x, y, z, fx, fy, fz], relative, tileBased);
					}
					
					if (!cancelAction) {
						if (!this.emit('beforeScale', pItem)) {
							// Assign world scale
							pItem._transform[6] = fx;
							pItem._transform[7] = fy;
							pItem._transform[8] = fz;
							
							// Call the receiver method if it exists
							if (typeof(this._afterScale) == 'function') {
								this._afterScale(pItem, x, y, z, relative, tileBased);
							}
							this.emit('afterScale', pItem);
								
							return true;
						}
					} else {
						return false;
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			// We are not updating, simly return the value
			return [pItem._transform[6], pItem._transform[7], pItem._transform[8]];
		}
	},
	
	/** scaleToTarget - Sets the scale values of the item so that the output
	matches the width, height and depth values specified. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"X value to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"Y value to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"Z value to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}],
	} **/
	scaleToTarget: function (pItem, x, y, z, tileBased) {
		// Check for tile-based and convert accordingly
		if (tileBased && pItem.$local.$map) {
			var map = pItem.$local.$map;
			if (x != null) { x *= map.map_tilesize; }
			if (y != null) { y *= map.map_tilesize; }
			if (z != null) { z *= map.map_tilesize; }
		}
		
		// Calculate the ratios
		if (x != null) {
			var xRatio = 1 / (pItem.$local.$originalSize[0] / x);
		}
		if (y != null) {
			var yRatio = 1 / (pItem.$local.$originalSize[1] / y);
		}
		var zRatio = 1; // No z value on a 2d image
		
		// Now we have ratio for at least one value, calculate the other
		// if the value passed was null
		if (x == null) {
			// Calculate the x ratio from the yRatio
			xRatio = yRatio;
		}
		if (y == null) {
			// Calculate the x ratio from the yRatio
			yRatio = xRatio;
		}
		
		// Set the scale
		return this.scale(pItem, xRatio, yRatio, zRatio);
	},
	
	/** origin - Sets / returns the current origin point co-ordinates of the item.
	The point (0.5, 0.5, 0.5) is the center of the item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"X value to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"Y value to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"Z value to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}],
	} **/
	origin: function (pItem, x, y, z, relative) {
		pItem._transform = pItem._transform || [];
		if (arguments.length > 1) {
			// Is the item initialised?
			if (pItem.$local) {
				// Grab some variables and set some defaults
				if (typeof(x) == 'undefined') { x = 1; }
				if (typeof(y) == 'undefined') { y = 1; }
				if (typeof(z) == 'undefined') { z = 1; }
				
				// Calculate the final values
				var fx = 0, fy = 0, fz = 0;
				
				if (relative) {
					fx = pItem._transform[9] + x;
					fy = pItem._transform[10] + y;
					fz = pItem._transform[11] + z;
				} else {
					fx = x;
					fy = y;
					fz = z;
				}
				
				// Check if any values are different and bug out if not
				if (fx != pItem._transform[9] || fy != pItem._transform[10] || fz != pItem._transform[11]) {
					// Call the receiver method if it exists
					var cancelAction = false;
					
					if (typeof(this._beforeOrigin) == 'function') {
						cancelAction = this._beforeOrigin(pItem, [x, y, z, x, y, z, fx, fy, fz], relative);
					}
					
					if (!cancelAction) {
						if (!this.emit('beforeOrigin', pItem)) {
							// Assign world orign
							pItem._transform[9] = fx;
							pItem._transform[10] = fy;
							pItem._transform[11] = fz;
							
							// Call the receiver method if it exists
							if (typeof(this._afterOrigin) == 'function') {
								this._afterOrigin(pItem, x, y, z, relative);
							}
							this.emit('afterOrigin', pItem);
							
							return true;
						}
					} else {
						return false;
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			// We are not updating, simly return the value
			return [pItem._transform[9], pItem._transform[10], pItem._transform[11]];
		}
	},
	
	/** opacity - Sets / returns the current opacity of the item. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"x",
			type:"float",
			desc:"X value to use in the operation.",
		}, {
			name:"y",
			type:"float",
			desc:"Y value to use in the operation.",
		}, {
			name:"z",
			type:"float",
			desc:"Z value to use in the operation.",
		}, {
			name:"relative",
			type:"bool",
			desc:"If set to true, the values specified will be added to the current values rather than replace them.",
		}],
	} **/
	opacity: function (pItem, x, y, z, relative) {
		pItem._transform = pItem._transform || [];
		if (arguments.length > 1) {
			// Is the item initialised?
			if (pItem.$local) {
				// Grab some variables and set some defaults
				if (typeof(x) == 'undefined') { x = 1; }
				if (typeof(y) == 'undefined') { y = 1; }
				if (typeof(z) == 'undefined') { z = 1; }
				
				// Calculate the final values
				var fx = 0, fy = 0, fz = 0;
				
				if (relative) {
					fx = pItem._transform[12] + x;
					fy = pItem._transform[13] + y;
					fz = pItem._transform[14] + z;
				} else {
					fx = x;
					fy = y;
					fz = z;
				}
				
				// Check if any values are different and bug out if not
				if (fx != pItem._transform[12] || fy != pItem._transform[13] || fz != pItem._transform[14]) {
					// Call the receiver method if it exists
					var cancelAction = false;
					
					if (typeof(this._beforeOpacity) == 'function') {
						cancelAction = this._beforeOpacity(pItem, [x, y, z, x, y, z, fx, fy, fz], relative);
					}
					
					if (!cancelAction) {
						if (!this.emit('beforeOpacity', pItem)) {
							// Assign opacity
							pItem._transform[12] = fx;
							pItem._transform[13] = fy;
							pItem._transform[14] = fz;
							
							// Call the receiver method if it exists
							if (typeof(this._afterOpacity) == 'function') {
								this._afterOpacity(pItem, x, y, z, relative);
							}
							this.emit('afterOpacity', pItem);
							
							return true;
						}
					} else {
						return false;
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			// We are not updating, simly return the value
			return [pItem._transform[12], pItem._transform[13], pItem._transform[14]];
		}
	},
	
	/** bounds - Calculates, stores and returns the new bounding box 
	that the transformed item now fits inside. This	is used when doing
	mouse-to-item hit checking and also dirty-rectangle rendering. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"multi",
			desc:"The object or ID of the item who's data is to be modified by this method.",
		}, {
			name:"update",
			type:"bool",
			desc:"If set to true will update the bounds with current transform values before returning.",
		}],
	} **/
	bounds: function (pItem, update) {
		// Using the translated and scaled bounding box before we rotate it,
		// apply the rotate and then determine the outer extents to return a
		// final bounding box - uses x, y, width, height, scale and rotation
		
		if (update) {
			// Original box
			var currentRect = [
				pItem._transform[0] - ((pItem._size[0] * pItem._transform[6]) * pItem._transform[9]), // x
				pItem._transform[1] - ((pItem._size[1] * pItem._transform[7]) * pItem._transform[10]), // y
				pItem._size[0] * pItem._transform[6], // width
				pItem._size[1] * pItem._transform[7]  // height
			];
			
			pItem._nonRotatedRect = currentRect;
			
			// Determine the bounding point co-ordinates clockwise
			var rectPoints = [];
			rectPoints[0] = [currentRect[0], currentRect[1]]; // top-left
			rectPoints[1] = [currentRect[0] + currentRect[2], currentRect[1]]; // top-right
			rectPoints[2] = [currentRect[0] + currentRect[2], currentRect[1] + currentRect[3]]; // bottom-right
			rectPoints[3] = [currentRect[0], currentRect[1] + currentRect[3]]; // bottom-left
			
			var angle = (-pItem._transform[3]) * Math.PI / 180;
			
			// Now rotate those points
			var cosAngle = Math.cos(angle);
			var sinAngle = Math.sin(angle);
			
			var rotatedPoint = [];
			rotatedPoint = [
				[
					pItem._transform[0] + (rectPoints[0][0] - pItem._transform[0]) * Math.cos(angle) + (rectPoints[0][1] - pItem._transform[1]) * Math.sin(angle),
					pItem._transform[1] - (rectPoints[0][0] - pItem._transform[0]) * Math.sin(angle) + (rectPoints[0][1] - pItem._transform[1]) * Math.cos(angle),
				], [
					pItem._transform[0] + (rectPoints[1][0] - pItem._transform[0]) * Math.cos(angle) + (rectPoints[1][1] - pItem._transform[1]) * Math.sin(angle),
					pItem._transform[1] - (rectPoints[1][0] - pItem._transform[0]) * Math.sin(angle) + (rectPoints[1][1] - pItem._transform[1]) * Math.cos(angle),
				], [
					pItem._transform[0] + (rectPoints[2][0] - pItem._transform[0]) * Math.cos(angle) + (rectPoints[2][1] - pItem._transform[1]) * Math.sin(angle),
					pItem._transform[1] - (rectPoints[2][0] - pItem._transform[0]) * Math.sin(angle) + (rectPoints[2][1] - pItem._transform[1]) * Math.cos(angle),
				], [
					pItem._transform[0] + (rectPoints[3][0] - pItem._transform[0]) * Math.cos(angle) + (rectPoints[3][1] - pItem._transform[1]) * Math.sin(angle),
					pItem._transform[1] - (rectPoints[3][0] - pItem._transform[0]) * Math.sin(angle) + (rectPoints[3][1] - pItem._transform[1]) * Math.cos(angle),
				]
			];
			
			pItem._rotatedRect = rotatedPoint;
			
			var minX1 = Math.min(rotatedPoint[0][0], rotatedPoint[1][0]);
			var minX2 = Math.min(rotatedPoint[2][0], rotatedPoint[3][0]);
			var minX = Math.min(minX1, minX2);
			
			var minY1 = Math.min(rotatedPoint[0][1], rotatedPoint[1][1]);
			var minY2 = Math.min(rotatedPoint[2][1], rotatedPoint[3][1]);
			var minY = Math.min(minY1, minY2);
			
			var maxX1 = Math.max(rotatedPoint[0][0], rotatedPoint[1][0]);
			var maxX2 = Math.max(rotatedPoint[2][0], rotatedPoint[3][0]);
			var maxX = Math.max(maxX1, maxX2);
			
			var maxY1 = Math.max(rotatedPoint[0][1], rotatedPoint[1][1]);
			var maxY2 = Math.max(rotatedPoint[2][1], rotatedPoint[3][1]);
			var maxY = Math.max(maxY1, maxY2);
			
			pItem._bounds = [minX, minY, maxX - minX, maxY - minY];
		}
		
		return pItem._bounds;
	},
	
	/** depth - Sets and returns the depth value for an item. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the depth value for the passed item.",
		},
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to apply transform data to.",
		}, {
			name:"depth",
			type:"float",
			desc:"If supplied, will set the current depth value of the item to this value.",
			flags:"optional",
		}, {
			name:"relative",
			type:"bool",
			desc:"If supplied, will sum the current depth with the newly specified one instead of overwriting the current value with the new one.",
			flags:"optional",
		}],
	} **/
	depth: function (pItem, depth, relative) {
		if (typeof(depth) != 'undefined') {
			if (relative) {
				depth = pItem._depth + depth;
			}
			
			pItem._depth = depth;
		}
		
		if (typeof(pItem._depth) == 'undefined') {
			if (pItem._bounds) {
				pItem._depth = (pItem._transform[0] + (pItem._bounds[2] * pItem._transform[9])) + (pItem._transform[1] + (pItem._bounds[3] * pItem._transform[10])) + (pItem._transform[2]);
			}
		}
		
		return pItem._depth;
	},
	
	/** transformByIndex - Applies a transform to the supplied item
	based upon the passed index and value. {
		category:"method",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item to apply transform data to.",
		}, {
			name:"index",
			type:"integer",
			desc:"If supplied, will set the current depth value of the item to this value.",
			flags:"optional",
		}, {
			name:"value",
			type:"float",
			desc:"If supplied, will sum the current depth with the newly specified one instead of overwriting the current value with the new one.",
			flags:"optional",
		}],
	} **/
	transformByIndex: function(pItem, index, value) {
		pItem._transform = pItem._transform || [];
		if (typeof(value) != 'undefined') {
			// Is the item initialised?
			if (pItem.$local) {
				// Check if values are different and bug out if not
				if (value != pItem._transform[index]) {
					if (index < 3) {
						// Translate
						this.emit('beforeTranslate', pItem);
					}
					
					if (index >= 3 && index < 6) {
						// Rotate
						this.emit('beforeRotate', pItem);
					}
					
					if (index >= 6 && index < 9) {
						// Scale
						this.emit('beforeScale', pItem);
					}
					
					if (index >= 9 && index < 12) {
						// Origin
						this.emit('beforeOrigin', pItem);
					}
					
					if (index >= 12 && index < 15) {
						// Opacity
						this.emit('beforeOpacity', pItem);
					}
					
					// Assign value
					pItem._transform[index] = value;
					
					if (index < 3) {
						// Translate
						// Call the receiver method if it exists
						if (typeof(this._afterTranslate) == 'function') {
							this._afterTranslate(pItem, index, value);
						}
						this.emit('afterTranslate', pItem);
					}
					
					if (index >= 3 && index < 6) {
						// Rotate
						// Call the receiver method if it exists
						if (typeof(this._afterRotate) == 'function') {
							this._afterRotate(pItem, index, value);
						}
						this.emit('afterRotate', pItem);
					}
					
					if (index >= 6 && index < 9) {
						// Scale
						// Call the receiver method if it exists
						if (typeof(this._afterScale) == 'function') {
							this._afterScale(pItem, index, value);
						}
						this.emit('afterScale', pItem);
					}
					
					if (index >= 9 && index < 12) {
						// Origin
						// Call the receiver method if it exists
						if (typeof(this._afterOrigin) == 'function') {
							this._afterOrigin(pItem, index, value);
						}
						this.emit('afterOrigin', pItem);
					}
					
					if (index >= 12 && index < 15) {
						// Opacity
						// Call the receiver method if it exists
						if (typeof(this._afterOpacity) == 'function') {
							this._afterOpacity(pItem, index, value);
						}
						this.emit('afterOpacity', pItem);
					}
				}
			}
		}
	},
	
	/** _rotatePoint - Rotates a point in 2d space by the given
	angle using the origin data in the transform parameter. {
		category:"method",
		arguments:[{
			name:"x",
			type:"float",
			desc:"The x co-ordinate of the point to rotate.",
		}, {
			name:"y",
			type:"float",
			desc:"The y co-ordinate of the point to rotate.",
		}, {
			name:"angle",
			type:"float",
			desc:"The angle in radians to rotate the point by.",
		}, {
			name:"transform",
			type:"object",
			desc:"The array that contains the origin to rotate around.",
		}],
	} **/
	_rotatePoint: function (x, y, angle, transform) {
		var cosAngle = Math.cos(angle);
		var sinAngle = Math.sin(angle);
		
		return [
			transform[0] + (x - transform[0]) * cosAngle + (y - transform[1]) * sinAngle,
			transform[1] - (x - transform[0]) * sinAngle + (y - transform[1]) * cosAngle
		];
	},
});