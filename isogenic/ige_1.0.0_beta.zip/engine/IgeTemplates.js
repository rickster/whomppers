/** IgeTemplates - The template management class. {
	category:"class",
} **/
IgeTemplates = new IgeClass({
	Extends: [IgeCollection, IgeItem, IgeEvents],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: null,
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeTemplates';
		this.collectionId = 'template';
		
		this.ige = engine;
		this.engine = engine;
		
		this.byIndex = [];
		this.byId = [];
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('templatesCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand('templatesRead', this.read);
		this.engine.network.registerCommand('templatesUpdate', this.update);
		this.engine.network.registerCommand('templatesRemove', this.remove);
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'template_id',
			'template_contents',
		]);
	},
	
	_itemDefaults: function (pItem) {
		this.ensureIdExists(pItem);
		this.ensureLocalExists(pItem);
		return true;
	},
	
	_itemIntegrity: function (pItem) {
		if (this.byId[pItem[this.collectionId + '_id']]) {
			this.log('Attempted to create a ' + this.collectionId + ' that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		if (pItem.template_contents == null || typeof(pItem.template_contents) == 'undefined') {
			this.log("Cannot create template because the template has no template_contents object!", "error", template);
			return false;
		}
		return true;
	},	
	
	/** _create - Create a new template. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the newly created item on success or false on failure.",
		},
		argument: {
			type:"object",
			name:"template",
			desc:"The template object to be created.",
			link:"templateData",
		},
	} **/
	_create: function (pItem) {
		this.byIndex.push(pItem);
		this.byId[pItem.template_id] = pItem;
		
		// Check for a callback function embedded in the item
		if (typeof(pItem.$local.create_callback) == 'function') {
			pItem.$local.create_callback.apply(this, [pItem]);
			delete pItem.$local.create_callback;
		}
		
		// Trigger the afterCreate event
		this.emit('afterCreate', pItem);
		
		return pItem;
	},
	
	update: function () {},
	remove: function () {},
	
	/** applyTemplate - Applies the contents of the template identified by templateId to the passed object. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true on success or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to apply the template to.",
		}, {
			type:"multi",
			name:"templateId",
			desc:"The id of the template or the template object itself to apply to the passed object (obj). If this argument is not supplied the method will attempt to use the template_id parameter in the object from argument 1.",
			flags:"optional",
		}],
	} **/
	applyTemplate: function (obj, templateId) {
		// Check for a passed template ID and if none, see if the object itself has one
		if (!templateId) {
			if (obj.template_id) {
				templateId = obj.template_id;
			}
		}
		
		if (templateId) {
			
			if (typeof(templateId) == 'string') {
				// Get the template
				var tpl = this.read(templateId);
				
				// Check for the template
				if (tpl) {
					// Now iterate through the obj object and replace any template properties with
					// the object's properties
					this.deepCopy(obj, tpl.template_contents); // 1.0.0b
					
					return true;
				} else {
					this.log('Attempted to apply template that does not exist with id: ' + templateId, 'error', obj);
					return false;
				}
			} else {
				// The template is an array of template id's so iterate and apply
				for (var tplIndex = 0; tplIndex < templateId.length; tplIndex++) {
					// Get the template
					var tpl = this.read(templateId[tplIndex]);
					// Check for the template
					if (tpl != null) {
						// Now iterate through the obj object and replace any template properties with
						// the object's properties
						this.deepCopy(obj, tpl.template_contents); // 1.0.0b
					} else {
						this.log('Attempted to apply template that does not exist with id: ' + templateId, 'error', obj);
					}	
				}
			}
		} else {
			this.log('Attempted to apply template to an object without specifying a template_id!', 'error', obj);
			return false;
		}
	},
	
	/** deepCopy - Clones and copies (not by reference) any data in obj2 to obj1
	recursively. If obj1 already has a particular property it will not be overwritten
	however if the property is an object, that object will also be checked recursively
	and any properties in that object that exist in obj2 but not obj1 will also be
	copied to obj1. {
		category:"method",
		arguments:[{
			name:"obj1",
			type:"object",
			desc:"The destination object that will have data copied into it.",
		}, {
			name:"obj2",
			type:"object",
			desc:"The source object that contains data to be copied to the destination object.",
		}],
	} **/
	deepCopy: function (obj1, obj2) {
		var clone = this.ige.objClone(obj2);
		
		if (clone) {
			for (var i in clone) {
				if (typeof(obj1[i]) == 'undefined' || obj1[i] == null) {
					obj1[i] = clone[i];
				} else {
					// The receiving object already has a property in this name,
					// so if the source data property is an object, copy any missing
					// data from the source object recursively
					if (typeof(clone[i]) == 'object') {
						this.deepCopy(obj1[i], clone[i]);
					}
				}
			}
		}
	},
	
	/** applyTemplateByVoodoo - Applies the contents of the template identified by templateId to the passed object
	by altering the fundamental getter and setter methods of the properties. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true on success or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"obj",
			desc:"The object to apply the template to.",
		}, {
			type:"multi",
			name:"templateId",
			desc:"The id of the template or the template object itself to apply to the passed object (obj).",
		}],
	} **/
	applyTemplateByVoodoo: function (obj, templateId) {
		
		if (!obj.$local.__igeTplOn) {
			// Get the template
			var tpl = this.read(templateId);
			
			// Check for the template
			if (tpl != null) {
				var tplContents = tpl.template_contents;
				obj.$local.__igeTplCts = tplContents;
				obj.$local.__igeTplOn = true;
				
				for (var i in tplContents) {
					eval('var templateGetter = function () { return this.__' + i + ' || this.$local.__igeTplCts.' + i + '; }');
					eval('var templateSetter = function (val) { this.__' + i + ' = val; }');
					
					if (Object.defineProperty) {
						
						// Use the ES5 defineProperty to set/get define
						Object.defineProperty(obj, i, {get: templateGetter, set: templateSetter});
						
					} else if (obj.__defineGetter__) {
						
						// Use older versions of the get/set define
						obj.__defineGetter__(i, templateGetter);
						obj.__defineSetter__(i, templateSetter);
						
					} else {
						
						// This is the worst-case scenario, fall back to copying the data
						obj[i] = tplContents[i];
						
					}
				}
				
				return true;
			} else {
				this.log('Attempted to apply template that does not exist named: ' + templateId, 'error');
				return false;
			}
			
		} else {
			this.log('Attempted to apply template to an object that already has a template applied!', 'error', obj);
			return false;
		}
	},
	
});