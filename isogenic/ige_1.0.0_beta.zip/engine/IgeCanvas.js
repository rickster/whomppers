/** IgeCanvas - The canvas drawing class. {
	category:"class",
} **/
IgeCanvas = new IgeClass({
	Extends: IgeEvents,
	
	engine: null,
	entities: null,
	assets: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeCanvas';
		
		this.ige = engine;
		this.engine = engine;
		
		this.entities = this.engine.entities;
		this.assets = this.engine.assets;
	},
	
	/** rectIntersect - Tests for an intersection of two rectangles. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns true if the rectangles intersect or false if not.",
		},
		arguments: [{
			type:"float",
			name:"sX1",
			desc:"Rect 1 x.",
		}, {
			type:"float",
			name:"sY1",
			desc:"Rect 1 y.",
		}, {
			type:"float",
			name:"sW",
			desc:"Rect 1 width.",
		}, {
			type:"float",
			name:"sH",
			desc:"Rect 1 height.",
		}, {
			type:"float",
			name:"dX1",
			desc:"Rect 2 x.",
		}, {
			type:"float",
			name:"dY1",
			desc:"Rect 2 y.",
		}, {
			type:"float",
			name:"dW",
			desc:"Rect 2 width.",
		}, {
			type:"float",
			name:"dH",
			desc:"Rect 2 height.",
		}],
	} **/
	rectIntersect: function (sX1, sY1, sW, sH, dX1, dY1, dW, dH) {
		var sX2 = sX1 + sW;
		var sY2 = sY1 + sH;
		var dX2 = dX1 + dW;
		var dY2 = dY1 + dH;
		
		if (sX1 < dX2 && sX2 > dX1 && sY1 < dY2 && sY2 > dY1) {
			return true;
		}
		return false;
	},
	
	/** renderFull - Draws the entire canvas. {
		category:"method",
		return: {
			type:"integer",
			desc:"Returns the total number of draw operations executed during the method call.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport to render.",
		}, {
			type:"integer",
			name:"layerIndex",
			desc:"The layer on the viewport to render.",
		}],
	} **/
	renderFull: function (viewport, layerIndex) {
		var renderCount = 0;
		var vpAdjX = viewport.$viewportAdjustX;
		var vpAdjY = viewport.$viewportAdjustY;
		
		// Check that the viewport has had precalculation data run
		if (vpAdjX != null && vpAdjY != null) {
			
			var map = viewport.$local.$map;
			var backBuffer = viewport.$local.$backBuffer; //$('#' + viewport.viewport_id + '_backBuffer')[0];
			var backCtx = viewport.$local.$backBufferCtx;
			
			var frontBuffer = viewport.$local.$frontBuffer[layerIndex];
			var frontCtx = viewport.$local.$frontBufferCtx[layerIndex];
			
			frontCtx.clearRect(0, 0, frontBuffer.width, frontBuffer.height);
			
			// Loop through all the entities on this layer and render them
			if (this.entities.byMapIdAndLayer[viewport.map_id] != null && 
			    this.entities.byMapIdAndLayer[viewport.map_id][layerIndex]) {
				
				var tempEntArray = this.entities.byMapIdAndLayer[viewport.map_id][layerIndex];
				var entCount = tempEntArray.length;
				var cellRatioX = 0;
				var cellRatioY = 0;
				var backWidth = 0;
				var backHeight = 0;
				var depth = 0;
				var tileCordsToDepth = this.engine.renderer.tileCordsToDepth;
				var entity = null;
				var renderMode = viewport.$local.$map.map_render_mode; // 2d = 0, iso = 1
				
				var camera = viewport.$local.$camera;
				var cameraScale = camera.camera_scale;
				
				// Define the redraw list array which will store the entities to redraw
				var redrawList = [];
				var dupList = [];
				
				// Define the redraw area clipping zone
				if (!viewport.viewport_clipping) {
					var rzX = 0;
					var rzY = 0;
					var rzW = viewport.panLayer.width;
					var rzH = viewport.panLayer.height;
				} else {
					var rzX = viewport.$local.$renderX;
					var rzY = viewport.$local.$renderY;
					var rzW = viewport.$local.$renderWidth;
					var rzH = viewport.$local.$renderHeight;
				}
				
				// Loop through the entities array
				while (entCount--) {
					// Store the current entity and get it's dimensions
					entity = tempEntArray[entCount];
					
					// Check if the entity is already on the duplist
					if (!dupList[entity.entity_id]) {
						
						// Check if the entity is actually on screen in the viewport!
						var entSize = this.entities.getSize(entity, viewport);
						var entPos = this.entities.getPosition(entity, viewport);
						
						if (this.rectIntersect(entPos[renderMode][0] + vpAdjX, entPos[renderMode][1] + vpAdjY, entSize[2], entSize[3], rzX, rzY, rzW, rzH)) {
							// If the entity needs redrawing...
							//if (entity.$local.$entity_dirty) {
							
							// Calculate depth by screen co-ordinates
							depth = tileCordsToDepth(entity.entity_x, entity.entity_y, entity.entity_z, entity.entity_tile_width, entity.entity_tile_height, 0);
							// Add entity to the redraw list
							dupList[entity.entity_id] = true;
							redrawList.push([entity, depth]);
						}
							
						//}
					}
					
				}
				
				redrawList.sort(function (a, b) { return b[1] - a[1]; });
				var redrawCount = redrawList.length;
				
				while (redrawCount--) {
					
					entity = redrawList[redrawCount][0];
					var assetSize = entity.$local.$asset.$local.$size;
					var entSize = this.entities.getSize(entity, viewport);
					var entPos = this.entities.getPosition(entity, viewport);
					
					var fp = [entPos[renderMode][0] + vpAdjX, 
							  entPos[renderMode][1] + vpAdjY,
							  entSize[2], entSize[3]];
							  
					frontCtx.save();
					frontCtx.scale(cameraScale, cameraScale);

					if (entity.entity_scale) {
						frontCtx.save();
						frontCtx.scale(entity.entity_scale[0], entity.entity_scale[1]);
					}
					
					if (entity.entity_base_draw) {
						// Draw the tiles that the entity SHOULD be occupying
						var XY1 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x, entity.entity_y, entity.entity_z, viewport, TILE_CORNER_1);
						var XY2 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x + (entity.entity_tile_width - 1), entity.entity_y, entity.entity_z, viewport, TILE_CORNER_2);
						var XY3 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x + (entity.entity_tile_width - 1), entity.entity_y + (entity.entity_tile_height - 1), entity.entity_z, viewport, TILE_CORNER_3);
						var XY4 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x, entity.entity_y + (entity.entity_tile_height - 1), entity.entity_z, viewport, TILE_CORNER_4);
						
						if (XY1 && XY2 && XY3 && XY4) {
							frontCtx.beginPath();
							frontCtx.moveTo(XY1[0], XY1[1]);
							frontCtx.lineTo(XY2[0], XY2[1]);
							frontCtx.lineTo(XY3[0], XY3[1]);
							frontCtx.lineTo(XY4[0], XY4[1]);
							frontCtx.lineTo(XY1[0], XY1[1]);
							if (entity.entity_base_draw[0] == 0) {
								frontCtx.strokeStyle = entity.entity_base_draw[1];
								frontCtx.stroke();
							}
							if (entity.entity_base_draw[0] == 1) {
								frontCtx.fillStyle = entity.entity_base_draw[1];
								frontCtx.fill();
							}
						}
					}
					
					if (entity.entity_opacity && entity.entity_opacity != 1) {
						frontCtx.globalAlpha = entity.entity_opacity;
					}
					frontCtx.drawImage(entity.$local.$assetImage, entSize[0], entSize[1], assetSize[0], assetSize[1], fp[0], fp[1], fp[2], fp[3]);
					if (entity.entity_opacity && entity.entity_opacity < 1) {
						frontCtx.globalAlpha = 1;
					}
					
					if (entity.entity_highlight) {
						frontCtx.save();
						frontCtx.globalCompositeOperation = 'lighter';
						frontCtx.drawImage(entity.$local.$assetImage, entSize[0], entSize[1], assetSize[0], assetSize[1], fp[0], fp[1], fp[2], fp[3]);
						frontCtx.restore();
					}
					
					if (map.map_debug_entities || entity.$local.entity_debug) {
						// Draw bounding boxes around the entity on the designated debug layer
						frontCtx.strokeStyle = '#00c6ff';
						frontCtx.strokeRect(fp[0], fp[1], fp[2], fp[3]);
						
						frontCtx.fillStyle = '#333333';
						frontCtx.fillRect(fp[0] + 3, fp[1] + 3, 25, 15);
						
						frontCtx.fillStyle = '#ffffff';
						frontCtx.fillText(parseFloat(redrawList[redrawCount][1]).toFixed(2), fp[0] + 5, fp[1] + 14);
					}
					
					frontCtx.restore();

					if (entity.entity_scale) {
						frontCtx.restore();
					}
					
					// Mark the entity as clean
					entity.$local.$entity_dirty = false;
					
					// Increment the render count
					renderCount++;
					
				}
				
			}
			
		} else {
			this.log('Viewport precalculations not available!', 'warning', viewport);
		}
		
		return renderCount;
		
	},
	
	/** renderRects - Draws all the dirty sections of the canvas. {
		category:"method",
		return: {
			type:"integer",
			desc:"Returns the total number of draw operations executed during the method call.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport to render.",
		}, {
			type:"integer",
			name:"layerIndex",
			desc:"The layer on the viewport to render.",
		}, {
			type:"integer",
			name:"tickTime",
			desc:"The current world tick time.",
		}, {
			type:"object",
			name:"map",
			desc:"The map that the viewport is rendering from.",
		}, {
			type:"array",
			name:"dirtyRectArray",
			desc:"The dirty rectangle array.",
		}],
	} **/
	renderRects: function (viewport, layerIndex, tickTime, map, dirtyRectArray) {
		var renderCount = 0;
		var vpAdjX = viewport.$viewportAdjustX;
		var vpAdjY = viewport.$viewportAdjustY;
		
		// Check that the viewport has had precalculation data run
		if (vpAdjX != null && vpAdjY != null) {
			
			// Grab the buffers
			var backBuffer = viewport.$local.$backBuffer,
			backCtx = viewport.$local.$backBufferCtx,
			frontBuffer = viewport.$local.$frontBuffer[layerIndex],
			frontCtx = viewport.$local.$frontBufferCtx[layerIndex],
			
			// Grab the camera data
			camera = viewport.$local.$camera,
			cameraScale = viewport.$local.$camera.camera_scale,
			
			// Define the redraw list array which will store the entities to redraw
			redrawList = [],
			dupList = [],
			
			// Get dirty rects object
			dr = map.$local.$dirtyRects;
			
			var drRects = dirtyRectArray, //dr.layer[layerIndex].dirty;
			drCount = dirtyRectArray.length,
			entityCache = map.$local.$entityCache[layerIndex],
			
			tileCordsToDepth = this.engine.renderer.tileCordsToDepth,
			entity = null,
			entSize = null,
			entPos = null,
			assetSize = null,
			depth = 0,
			rect = null,
			screenX = 0,
			screenY = 0,
			tileWidth = dr.tileWidth,
			tileHeight = dr.tileHeight,
			finalWidth = dr.tileWidth,
			finalHeight = dr.tileHeight,
			renderMode = viewport.$local.$map.map_render_mode, // 2d = 0, iso = 1
			bbScreenX = 0,
			bbScreenY = 0,
			bbFinalWidth = 0,
			bbFinalHeight = 0; 
			
			// Define the redraw area clipping zone
			if (!viewport.viewport_clipping) {
				// Render the whole canvas area even if the viewport
				// cannot "see" the entities
				var rzX = 0;
				var rzY = 0;
				var rzW = viewport.panLayer.width;
				var rzH = viewport.panLayer.height;
			} else {
				// Viewport clipping is enabled so only render entities that
				// intersect the viewport's "visible viewing" area
				var rzX = viewport.$local.$renderX;
				var rzY = viewport.$local.$renderY;
				var rzW = viewport.$local.$renderWidth;
				var rzH = viewport.$local.$renderHeight;
			}
			
			// Scale the buffers before doing clear and draw functions
			frontCtx.save();
			backCtx.save();
			frontCtx.scale(cameraScale, cameraScale);
			backCtx.scale(cameraScale, cameraScale);
			
			// Check if the dirty mode wants us to output the dirty rectangle debug grid
			if (map.map_use_dirty && map.map_debug_dirty) {
				this.engine.dirtyRects.drawGridRects(viewport, map.map_debug_layer, dirtyRectArray);
			}
			
			// Loop dirty rects
			while (drCount--) {
				
				// Clear back & front buffer rect and store redraw entities
				// Get the individual rect co-ordinates
				rect = drRects[drCount];
				
				// Store entities
				if (entityCache && entityCache[rect[0]]) {
					var entList = entityCache[rect[0]][rect[1]];
					
					if (entList != null) {
						var entCount = entList.length;
						while (entCount--) {
							// Grab the entity
							entity = entList[entCount];
							
							// Check if the entity exists in the redraw list
							if (!dupList[entity.entity_id]) {
								// Check if the entity is actually on screen in the viewport!
								entSize = this.entities.getSize(entity, viewport);
								entPos = this.entities.getPosition(entity, viewport);
								
								if (this.rectIntersect(entPos[renderMode][0] + vpAdjX, entPos[renderMode][1] + vpAdjY, entSize[2], entSize[3], rzX, rzY, rzW, rzH)) {
									// Calculate depth by screen co-ordinates
									depth = tileCordsToDepth(entity.entity_x, entity.entity_y, entity.entity_z, entity.entity_tile_width, entity.entity_tile_height, 0);
									// Add entity to the redraw list
									dupList[entity.entity_id] = true;
									redrawList.push([entity, depth]);
								}
							}
						}
					}
				}
				
				// Calculate the screen co-ordinates
				screenX = (rect[0] * tileWidth) + vpAdjX;
				screenY = (rect[1] * tileHeight) + vpAdjY;
				
				// Clear the rect
				frontCtx.clearRect(screenX, screenY, tileWidth, tileHeight);
				backCtx.clearRect(screenX, screenY, tileWidth, tileHeight);
				
			}
			
			// Do we have any entities to redraw?
			var redrawCount = redrawList.length;
			if (redrawCount) {
				// Sort the entities by depth
				redrawList.sort(function (a, b) { return b[1] - a[1]; });
				
				// Draw the entities
				while (redrawCount--) {
					// Grab the entity to draw
					entity = redrawList[redrawCount][0];
					
					// Calculate the entity's dimensions and position
					assetSize = entity.$local.$asset.$local.$size;
					entSize = this.entities.getSize(entity, viewport);
					entPos = this.entities.getPosition(entity, viewport);
					
					if (entity.entity_scale) {
						frontCtx.save();
						frontCtx.scale(entity.entity_scale[0], entity.entity_scale[1]);
					}
					
					if (entity.entity_base_draw) {
						// Draw the tiles that the entity SHOULD be occupying
						var XY1 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x, entity.entity_y, entity.entity_z, viewport, TILE_CORNER_1);
						var XY2 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x + (entity.entity_tile_width - 1), entity.entity_y, entity.entity_z, viewport, TILE_CORNER_2);
						var XY3 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x + (entity.entity_tile_width - 1), entity.entity_y + (entity.entity_tile_height - 1), entity.entity_z, viewport, TILE_CORNER_3);
						var XY4 = this.engine.renderer.viewToScreen[renderMode](entity.entity_x, entity.entity_y + (entity.entity_tile_height - 1), entity.entity_z, viewport, TILE_CORNER_4);
						
						if (XY1 && XY2 && XY3 && XY4) {
							backCtx.beginPath();
							backCtx.moveTo(XY1[0], XY1[1]);
							backCtx.lineTo(XY2[0], XY2[1]);
							backCtx.lineTo(XY3[0], XY3[1]);
							backCtx.lineTo(XY4[0], XY4[1]);
							backCtx.lineTo(XY1[0], XY1[1]);
							if (entity.entity_base_draw[0] == 0) {
								backCtx.strokeStyle = entity.entity_base_draw[1];
								backCtx.stroke();
							}
							if (entity.entity_base_draw[0] == 1) {
								backCtx.fillStyle = entity.entity_base_draw[1];
								backCtx.fill();
							}
						}
					}
					
					var fp = [entPos[renderMode][0] + vpAdjX, entPos[renderMode][1] + vpAdjY, entSize[2], entSize[3]];
					
					if (entity.entity_opacity && entity.entity_opacity < 1) {
						backCtx.globalAlpha = entity.entity_opacity;
					}
					
					backCtx.drawImage(entity.$local.$assetImage, entSize[0], entSize[1], assetSize[0], assetSize[1], fp[0], fp[1], fp[2], fp[3]);
					
					if (entity.entity_opacity && entity.entity_opacity < 1) {
						backCtx.globalAlpha = 1;
					}
					
					if (entity.entity_highlight) {
						backCtx.save();
						backCtx.globalCompositeOperation = 'lighter';
						backCtx.drawImage(entity.$local.$assetImage, entSize[0], entSize[1], assetSize[0], assetSize[1], fp[0], fp[1], fp[2], fp[3]);
						backCtx.restore();
					}
					
					if (map.map_debug_entities || entity.$local.entity_debug) {
						// Draw bounding boxes around the entity on the designated debug layer
						backCtx.strokeStyle = '#00c6ff';
						backCtx.strokeRect(fp[0], fp[1], fp[2], fp[3]);
						
						backCtx.fillStyle = '#333333';
						backCtx.fillRect(fp[0] + 3, fp[1] + 3, 25, 15);
						
						backCtx.fillStyle = '#ffffff';
						backCtx.fillText(parseFloat(redrawList[redrawCount][1]).toFixed(2), fp[0] + 5, fp[1] + 14);
					}
					
					if (entity.entity_scale) {
						frontCtx.restore();
					}
					
					// Mark the entity as clean
					entity.$local.$entity_dirty = false;
					
					// Increment the render count
					renderCount++;
					
				}
				
				// Copy back-buffer rects to front buffer
				drCount = drRects.length;
				while (drCount--) {
					// Get the individual rect co-ordinates
					rect = drRects[drCount];
					
					// Calculate the screen co-ordinates
					screenX = (rect[0] * tileWidth) + vpAdjX;
					screenY = (rect[1] * tileHeight) + vpAdjY;
					finalWidth = tileWidth;
					finalHeight = tileHeight;
					
					// Adjust for camera scale
					screenX = (screenX * cameraScale);
					screenY = (screenY * cameraScale);
					finalWidth = (finalWidth * cameraScale);
					finalHeight = (finalHeight * cameraScale);
					
					// Check the bounds of the copy to ensure we don't try to copy outside the canvas and throw an INDEX_SIZE_ERR
					if (screenX < 0) { // Check screen x
						finalWidth += screenX;
						screenX = 0;
					}
					if (screenY < 0) { // Check screen x
						finalHeight += screenY;
						screenY = 0;
					}
					if ((screenX + finalWidth) > backBuffer.width) { // Width check
						finalWidth = backBuffer.width - screenX;
					}
					if ((screenY + finalHeight) > backBuffer.height) { // Height check
						finalHeight = backBuffer.height - screenY;
					}
					
					if (finalWidth > 0 && finalHeight > 0) {
						// Draw the back-buffer data to the front-buffer!
						screenX = Math.floor(screenX);
						screenY = Math.floor(screenY);
						finalWidth = Math.ceil(finalWidth);
						finalHeight = Math.ceil(finalHeight);
						frontCtx.drawImage(backBuffer, screenX, screenY, finalWidth, finalHeight, screenX, screenY, finalWidth, finalHeight);
					}
					
				}
				
			}
			
			// Restore the buffer states
			frontCtx.restore();
			backCtx.restore();			
			
		} else {
			this.log('Viewport precalculations not available!', 'warning', viewport);
		}
		
		return renderCount;
		
	},
	
	///////////////////////////////////////////////////////////////////////////
	// 1.0.0 re-code of canvas renderer
	///////////////////////////////////////////////////////////////////////////
	renderFull2: function (viewport, layerIndex, map) {
		// Check if there are actually entities to render on this map and layer
		if (this.engine.entities.byMapIdAndLayer[map.map_id] && this.engine.entities.byMapIdAndLayer[map.map_id][layerIndex]) {
			// Get the array of entities that exist on this map and layer
			var entArr = this.engine.entities.byMapIdAndLayer[map.map_id][layerIndex];
			
			// If we have entities to draw...
			if (entArr) {
				// Get the render mode for this map layer
				var renderMode = map.map_layers[layerIndex].layer_render_mode;
				
				// Copy the entArr to the drawArr not by reference because we are going to sort it!
				var drawArr = [];
				var count = entArr.length;
				while (count--) {
					drawArr.push(entArr[count]);
				}
				
				// Now sort the entities by depth
				drawArr.sort(function (a, b) { return b._depth - a._depth; });
				
				// Grab the buffers
				var frontBuffer = viewport.$local.$frontBuffer[layerIndex];
				var frontCtx = viewport.$local.$frontBufferCtx[layerIndex];
				
				// Grab the camera data
				var camera = viewport.$local.$camera;
				
				// Clear the canvas
				frontCtx.clearRect(0, 0, viewport.panLayer.width, viewport.panLayer.height);
				
				// Translate, rotate and scale the canvas
				frontCtx.save();
				frontCtx.translate(viewport.$local.$centerX - camera._transform[0], viewport.$local.$centerY - camera._transform[1]);
				frontCtx.rotate(camera._transform[3] * Math.PI / 180);
				frontCtx.scale(camera._transform[6], camera._transform[7]);
				
				// Loop all entities
				var entCount = drawArr.length;
				while (entCount--) {
					var ent = drawArr[entCount];
					
					if (!ent.entity_hide) {
						// Render the entity
						this.entityRender(frontCtx, ent, renderMode);
					}
				}
				
				frontCtx.restore();
				return drawArr.length;
			}
		}
		
		return 0;
	},
	
	/** entityRender - Draws an entity to the passed context. {
		category:"method",
		return: {
			type:"integer",
			desc:"Returns the total number of draw operations executed during the method call.",
		},
		arguments: [{
			type:"object",
			name:"ctx",
			desc:"The canvas context to draw to.",
		}, {
			type:"object",
			name:"ent",
			desc:"The entity to render.",
		}, {
			type:"integer",
			name:"renderMode",
			desc:"The render mode (0 = 2d, 1 = isometric).",
		}],
	} **/
	entityRender: function (ctx, ent, renderMode) {
		var entLocal = ent.$local;
		
		// Check if the entity is visible based upon its opacity
		if (ent._transform[12] > 0) {
			// Draw actual entity with transforms on the canvas
			var entCenter = [ent._size[0] * ent._transform[9], ent._size[1] * ent._transform[10]];
			ctx.save();
			if (renderMode == 0 || !renderMode) { // RENDER_MODE_2D
				ctx.translate(ent._transform[0], ent._transform[1]);
			}
			
			if (renderMode == 1) { // RENDER_MODE_ISOMETRIC
				var finalXY = this.engine.renderer.toIso(ent._transform[0], ent._transform[1]);
				ctx.translate(finalXY[0], finalXY[1]);
			}
			ctx.rotate(ent._transform[3] * Math.PI / 180);
			
			//if (renderMode == 0 || !renderMode) { // RENDER_MODE_2D
				ctx.scale(ent._transform[6], ent._transform[7]);
			//}
			
			//if (renderMode == 1) { // RENDER_MODE_ISOMETRIC
				//ctx.scale(ent._transform[6], ent._transform[7] / 2);
			//}
			
			// Translate the context to center the entity
			ctx.translate(-entCenter[0], -entCenter[1]);
			
			// Set the alpha for this entity
			ctx.globalAlpha = ent._transform[12];
			
			// Check if the entity has it's own render method
			if (ent.entity_self_render) {
				// Call the self-render method
				entLocal.$selfRender(ctx);
			} else {
				// Asset-based render
				var asset = entLocal.$asset;
				var assetLocal = asset.$local;
				
				if (asset.asset_self_render) {
					// Call the self-render method
					if (assetLocal.$script) {
						ctx.save();
						assetLocal.$script.render(ctx, ent);
						ctx.restore();
						
						if (ent.entity_highlight) {
							ctx.save();
							ctx.globalCompositeOperation = 'lighter';
								ctx.save();
								assetLocal.$script.render(ctx, ent);
								ctx.restore();
							ctx.restore();
						}
					}
				} else {
					// Draw the entity image
					var assetSize = assetLocal.$size;
					ctx.drawImage(
						entLocal.$assetImage,
						assetLocal.$sheetFrames[ent.asset_sheet_frame][0],
						assetLocal.$sheetFrames[ent.asset_sheet_frame][1],
						assetSize[0],
						assetSize[1],
						0,
						0,
						entLocal.$originalSize[0],
						entLocal.$originalSize[1]
					);
					
					if (ent.entity_highlight) {
						ctx.save();
						ctx.globalCompositeOperation = 'lighter';
						ctx.drawImage(
							entLocal.$assetImage,
							assetLocal.$sheetFrames[ent.asset_sheet_frame][0],
							assetLocal.$sheetFrames[ent.asset_sheet_frame][1],
							assetSize[0],
							assetSize[1],
							0,
							0,
							entLocal.$originalSize[0],
							entLocal.$originalSize[1]
						);
						ctx.restore();
					}
					
					if (ent.entity_transform.debug) {
						// Move to the center relative to the entity
						ctx.translate(entCenter[0], entCenter[1]);
						
						// Entity center point
						ctx.strokeStyle = '#003cff';
						ctx.strokeRect(-5, -5, 10, 10);
						
						// Entity contents markers
						var halfOrigSize = [
							(entLocal.$originalSize[0] / 2),
							(entLocal.$originalSize[1] / 2)
						];
						ctx.beginPath();
						ctx.moveTo(-10, -10);
						ctx.lineTo(-halfOrigSize[0] + 10, -halfOrigSize[1] + 10);
						ctx.moveTo(10, -10);
						ctx.lineTo(halfOrigSize[0] - 10, -halfOrigSize[1] + 10);
						ctx.moveTo(10, 10);
						ctx.lineTo(halfOrigSize[0] - 10, halfOrigSize[1] - 10);
						ctx.moveTo(-10, 10);
						ctx.lineTo(-halfOrigSize[0] + 10, halfOrigSize[1] - 10);
						ctx.stroke();
						
						// Entity bounding rect
						ctx.strokeRect(-halfOrigSize[0], -halfOrigSize[1], entLocal.$originalSize[0], entLocal.$originalSize[1]);
					}
				}
			}
			
			if (ent.entity_text) {
				var tx = ent.entity_text;
				ctx.save();
				// Center the text
				tx.origin = tx.origin || [0.5, 0.5];
				ctx.translate(ent._size[0] * tx.origin[0], ent._size[1] * tx.origin[1]);
				// Draw the text
				ctx.font = tx.font || "normal 12px Verdana";
				ctx.textAlign = tx.align || 'center';
				ctx.textBaseline = tx.baseline || 'middle';
				ctx.fillStyle = tx.color || '#000000';
				ctx.fillText(tx.value, 0, 0);
				// Restore the context
				ctx.restore();
			}
			
			// Now check if the entity has any mounts
			var mounts = ent.$local.$mounts;
			if (mounts && mounts.length) {
				// Loop each mount and render it according to the mount position
				mountCount = mounts.length;
				while (mountCount--) {
					// Get the mounted entity
					var mountEntity = mounts[mountCount];
					
					// Retrieve the mounted entity's mount point
					var mountTranslate = ent.entity_mounts[mountEntity.mount_at];
					ctx.save();
					// Translate the context to the mount point position
					ctx.translate(ent._size[0] * mountTranslate[0], ent._size[1] * mountTranslate[1]);
					// Render the mounted entity
					this.entityRender(ctx, mountEntity, renderMode);
					ctx.restore();
				}
			}
			
			ctx.restore();
		}
	},
	
	renderRects2: function (viewport, layerIndex, map) {
		// Define our draw array, which holds the final list of entities to draw
		var drawArr = [];
		
		// Get the list of dirty rectangles for the map and layer
		var drArr = map.$local.$dr2;
		
		// Check if there are any layers to process
		if (drArr) {
			var drLayer = drArr[layerIndex];
			
			// Check if this layer has any dirty rectangles
			if (drLayer) {
				// Grab the buffers
				var backBuffer = viewport.$local.$backBuffer;
				var backCtx = viewport.$local.$backBufferCtx;
				var frontBuffer = viewport.$local.$frontBuffer[layerIndex];
				var frontCtx = viewport.$local.$frontBufferCtx[layerIndex];
				var debugBuffer = viewport.$local.$frontBuffer[3];
				var debugCtx = viewport.$local.$frontBufferCtx[3];
				
				viewport.viewport_anchor = [0.5, 0.5]; // Center everything
				viewport.$local.$centerX = Math.floor(viewport.panLayer.width * viewport.viewport_anchor[0]);
				viewport.$local.$centerY = Math.floor(viewport.panLayer.height * viewport.viewport_anchor[1]);
				
				// Grab the camera data
				var camera = viewport.$local.$camera;
				
				// Translate, rotate and scale the canvas
				backCtx.save();
				backCtx.translate(viewport.$local.$centerX, viewport.$local.$centerY);
				backCtx.rotate(camera._transform[3] * Math.PI / 180);
				backCtx.scale(camera._transform[6], camera._transform[7]);
				
				///////////////////////////////////////////////////////
				// Detect entity intersections with dirty rectangles //
				///////////////////////////////////////////////////////
				// Get the array of entities that exist on this map and layer
				var entArr = this.engine.entities.byMapIdAndLayer[map.map_id][layerIndex];
				var entityRegister = [];
				
				// Check if we have any entities on this map and layer
				//backCtx.lineWidth = 3;
				if (entArr) {
					var drCount = drLayer.length;
					
					// Loop all dirty rectangles
					while (drCount--) {
						var entCount = entArr.length;
						var dr = drLayer[drCount];
						
						// Check that the dr is within the canvas bounds
						/*
						var drX = viewport.$local.$centerX + dr[0];
						var drY = viewport.$local.$centerX + dr[1];
						var drW = viewport.$local.$centerX + dr[0];
						var drH = viewport.$local.$centerX + dr[0];
						if (drX < 0) { dr[0] = -viewport.$local.$centerX; }
						if (drX > viewport.panLayer.width) { dr[0] = viewport.panLayer.width; }
						if (drY < 0) { dr[1] = -viewport.$local.$centerY; }
						if (drY > viewport.panLayer.height) { dr[1] = viewport.panLayer.height; }
						*/
						// Clear the dirty rectangle draw area
						backCtx.clearRect(dr[0], dr[1], dr[2], dr[3]);
						
						// Draw the dirty rect outline
						//backCtx.strokeStyle = '#ff0000';
						//backCtx.strokeRect(dr[0], dr[1], dr[2], dr[3]);
						
						// Loop all entities
						while (entCount--) {
							var ent = entArr[entCount];
							// Is the entity hidden?
							if (!ent.entity_hide) {
								// Has the entity already been added to the draw array?
								if (!entityRegister[ent.entity_id]) {
									// Check if the current entity bounds intersects the dirty rectangle
									if (this.engine.dirtyRects.rectIntersect(ent._bounds, dr)) {
										// The entity intersects the dirty rectangle so add it to the draw list
										entityRegister[ent.entity_id] = true;
										drawArr.push(ent);
									}
								}
							}
						}
					}
				}
				
				//backCtx.lineWidth = 1;
				
				var entArr = drawArr;
				var entCount = entArr.length;
				
				// Loop all entities
				while (entCount--) {
					var ent = entArr[entCount];
					var tempRect = ent._bounds;
					
					if (ent.entity_transform.debug) {
						// Draw bounding rect
						backCtx.strokeStyle = '#00baff';
						backCtx.strokeRect(tempRect[0] + 1, tempRect[1] + 1, tempRect[2] - 2, tempRect[3] - 2);
					}
					
					// Draw actual entity with transforms on the canvas
					var entCenter = [ent._size[0] * ent._transform[9], ent._size[1] * ent._transform[10]];
					backCtx.save();
					backCtx.translate(ent._transform[0], ent._transform[1]);
					backCtx.rotate(ent._transform[3] * Math.PI / 180);
					backCtx.scale(ent._transform[6], ent._transform[7]);
					
					// Draw the entity image
					backCtx.translate(-entCenter[0], -entCenter[1]);
					var asset = entLocal.$asset;
					var assetLocal = asset.$local;
					var assetSize = assetLocal.$size;
					
					// Check that the sheet frame the entity is set with actually exists
					if (assetLocal.$sheetFrames[ent.asset_sheet_frame] == null) {
						this.log('Cannot render an entity with a sheet frame that doesn\'t exist!', 'error', ent);
						this.engine.stop();
					}
					
					backCtx.drawImage(
						entLocal.$assetImage,
						assetLocal.$sheetFrames[ent.asset_sheet_frame][0],
						assetLocal.$sheetFrames[ent.asset_sheet_frame][1],
						assetSize[0],
						assetSize[1],
						0,
						0,
						entLocal.$originalSize[0],
						entLocal.$originalSize[1]
					);
					
					if (ent.entity_transform.debug) {
						// Move to the center relative to the entity
						backCtx.translate(entCenter[0], entCenter[1]);
						
						// Entity center point
						backCtx.strokeStyle = '#003cff';
						backCtx.strokeRect(-5, -5, 10, 10);
						
						// Entity contents markers
						var halfOrigSize = [
							(entLocal.$originalSize[0] / 2),
							(entLocal.$originalSize[1] / 2)
						];
						backCtx.beginPath();
						backCtx.moveTo(-10, -10);
						backCtx.lineTo(-halfOrigSize[0] + 10, -halfOrigSize[1] + 10);
						backCtx.moveTo(10, -10);
						backCtx.lineTo(halfOrigSize[0] - 10, -halfOrigSize[1] + 10);
						backCtx.moveTo(10, 10);
						backCtx.lineTo(halfOrigSize[0] - 10, halfOrigSize[1] - 10);
						backCtx.moveTo(-10, 10);
						backCtx.lineTo(-halfOrigSize[0] + 10, halfOrigSize[1] - 10);
						backCtx.stroke();
					}
					
					backCtx.restore();
				}
				backCtx.restore();
				
				// Transform the front buffer
				frontCtx.save();
				frontCtx.translate(viewport.$local.$centerX, viewport.$local.$centerY);
				frontCtx.rotate(camera._transform[3] * Math.PI / 180);
				frontCtx.scale(camera._transform[6], camera._transform[7]);
				
				// Now loop the dirty rects again and copy their
				// contents from the back buffer to the front buffer
				var drCount = drLayer.length;
				
				// Loop all dirty rectangles
				while (drCount--) {
					var dr = drLayer[drCount];
					
					// Clear the dirty rectangle draw area
					frontCtx.clearRect(dr[0], dr[1], dr[2], dr[3]);
					//frontCtx.strokeRect(dr[0], dr[1], dr[2], dr[3]);
					
					// Copy the DR data
					frontCtx.drawImage(
						backBuffer,
						Math.floor(viewport.$local.$centerX) + dr[0], viewport.$local.$centerY + dr[1], dr[2], dr[3],
						dr[0], dr[1], dr[2], dr[3]
					);
				}
				
				frontCtx.restore();
				
			}
		}
		
		return drawArr.length;
	},
});