/* CEXCLUDE */
IgeNetwork.prototype.startFileServer = function (callback) {
	return;
	if (this.engine.isServer) {
		
		// Generate a client deployment of all the required javascript files into one script, maintaining load order
		if (igeConfig.clientDeploy != null) {
			var packageData = '';
			
			if (igeConfig.mode == 'debug') {
				// Deploy for debug
				this.log('WARNING - CURRENTLY DEPLOYING IN DEBUG MODE -- DO NOT USE ON OPEN PRODUCTION SERVER', 'warning', null, true);
				packageData = 'window.igeBootstrap.init(';
				packageData += JSON.stringify(igeConfig.clientDeploy);
				packageData += ');';
			} else {
				// Deploy for release
				for (var i in igeConfig.clientDeploy) {
					// Get the next file to add to the deployment file
					var localPath = igeConfig.mapUrl(igeConfig.clientDeploy[i] + '.js');
					// Read the file's data
					//this.log('Reading data to protect from: ' + localPath);
					var data = fs.readFileSync(localPath, 'utf8');
					// If we got the file's data
					if (data) {
						// Obfuscate the data
						//this.log('Packaging protected script file: ' + localPath);
						try {
							var finData = this.engine.obfuscator.obfuscate(data, null, null, true);
						} catch (err) {
							this.log('Failed to obfuscate file: ' + localPath, 'error', err);
						}
						packageData += finData + ";";
					} else {
						this.log('Failed attempt to load file from path: ' + localPath);
					}
				}
			}
			
			// Write the data to the deployment file
			fs.writeFileSync(igeConfig.mapUrl('/client/_deploy.js'), packageData);
		} else {
			//this.log('Error - You must define a string-array of files in your config.js that tells the server what files to wrap into a single deployment for the client. See http://www.isogenicengine.com/documentation/general-engine-information/game-configuration-file-config-js/', 'error');
		}
		
		// Server code
		this.log('Starting networking for the server...');
		
		// Define node requirements
		this.http = require('http');
		this.url = require('url');
		this.fs = require('fs');
		this.sys = require('sys');
		this.path = require('path');
		
		// Node plugin modules
		this.static = require(igeConfig.mapUrl('/node_modules/node-static'));
		this.mime = require(igeConfig.mapUrl('/node_modules/node-static/lib/node-static/mime'));
		var clientFileServer = new (this.static.Server)(igeConfig.mapUrl('/client/'));
		var assetFileServer = new (this.static.Server)(igeConfig.mapUrl('/assets/'));
		var engineFileServer = new (this.static.Server)(igeConfig.mapUrl('/engine/'));
		var moduleFileServer = new (this.static.Server)(igeConfig.mapUrl('/modules/'));
		
		// Add htm to the mime types!
		this.mime.contentTypes['htm'] = this.mime.contentTypes['html'];
		
		this.emit('serverStarting');
		
		// Create the server object
		this.httpServer = this.http.createServer(this.bind(function(req, res){
			req.connection.finalRemoteAddress = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
			
			if (!this._serveClients) {
				this.emit('serveFile_deny', req.url);
				
				res.writeHead(404);
				res.write('404');
				res.end();
			} else {
				this.emit('serveFile_accept', req.url);
				
				var serveEngineFile = false;
				var serveAssetFile = false;
				var serveModuleFile = false;
				var serveClientFile = false;
				var served = false;
				
				// Set some serving defaults
				if (!igeConfig.serveClient) { igeConfig.serveClient = '/'; }
				if (!igeConfig.serveAssets) { igeConfig.serveAssets = '/assets/'; }
				if (!igeConfig.serveEngine) { igeConfig.serveEngine = '/engine/'; }
				
				// Get the path of the requested resource / file
				var pathName = this.url.parse(req.url).pathname;
				
				// Remove any serverFrom string data from the path
				if (igeConfig.serveClient != '/') {
					pathName = pathName.replace(igeConfig.serveClient, '');
					if (pathName == '') { pathName = '/'; }
				}
				
				// Remove the ability to get lower down the dir chain
				if (pathName.replace('..', '') != pathName) {
					// Access attempted to a folder that we don't want to serve from
					this.log('Failed attempt to load file from path because url contains ".." (' + req.connection.finalRemoteAddress + '): ' + pathName);
					res.writeHead(404);
					res.write('404');
					res.end();
				}
				
				// Check for an engine file request
				var mappedPath = igeConfig.mapUrl(pathName, true);
				var pathType = mappedPath[0];
				var localPath = mappedPath[1];
				
				// Define the path that the static file server would use to access the file,
				// given that the static server is "listening" in a path already
				var adjustedPath = localPath.replace(mappedPath[2], '/');
				
				switch (pathType) {
					case 'engine':
						serveEngineFile = true;
					break;
					
					case 'assets':
						serveAssetFile = true;
					break;
					
					case 'modules':
						serveModuleFile = true;
					break;				
					
					case 'client':
						serveClientFile = true;
						if (pathName == '/') {
							pathName = '/index.htm';
							mappedPath = igeConfig.mapUrl(pathName, true);
							localPath = mappedPath[1];
							adjustedPath = '/index.htm';
						}
					break;				
				}
				
				/*
				console.log('-----------------------------------------');
				console.log('request url: ' + req.url);
				console.log('localPath:', localPath);
				console.log('adjustedPath:', adjustedPath);
				console.log('type', pathType);
				console.log('-----------------------------------------');
				*/
				
				this.path.exists(localPath, this.bind(function (exists) {
					if (exists) {
						// File exists
						if (this.engine.config.mode == 'release' && pathName.substr(pathName.length - 3, 3) == '.js') {
							// The file is JavaScript and we're in release mode so we need to obfuscate and pack all JS data
							this.serveObfuscated(req, res, localPath);
						} else {
							// Serve the file via static
							switch (pathType) {
								case 'engine':
									this.log('Serving engine data file (' + req.connection.finalRemoteAddress + '): ' + localPath);
									engineFileServer.serveFile(adjustedPath, 200, {}, req, res);
								break;
								
								case 'assets':
									assetFileServer.serveFile(adjustedPath, 200, {}, req, res);
								break;
								
								case 'modules':
									this.log('Serving module data file (' + req.connection.finalRemoteAddress + '): ' + localPath);
									moduleFileServer.serveFile(adjustedPath, 200, {}, req, res);
								break;
								
								case 'client':
									this.log('Serving game data file (' + req.connection.finalRemoteAddress + '): ' + localPath);
									clientFileServer.serveFile(adjustedPath, 200, {}, req, res);
								break;
							}
						}
					} else {
						// File does not exist
						// Check the server configuration for the file to see if we should serve it
						for (var i in this.engine.config.serveFile) {
							if (this.engine.config.serveFile[i].file != null) {
								if (this.engine.config.serveFile[i].file == pathName) {
									//console.log('path exists in config');
									if (this.engine.config.serveFile[i].type != null) {
										// We are serving a file so output it!
										fs.readFile(__dirname + pathName, function(err, data) {
											if (!err) {
												this.log('Serving config-registered static file data (' + req.connection.finalRemoteAddress + '): ' + pathName);
												res.writeHead(200, {'Content-Type': this.engine.config.serveFile[i].type})
												res.write(data, 'utf8');
												res.end();
												served = true;
											} else {
												// Access attempted to a folder that we don't want to serve from
												this.log('Failed attempt to load config-registered static file from path (' + req.connection.finalRemoteAddress + '): ' + pathName, 'warning');
												res.writeHead(404);
												res.write('404');
												res.end();
												served = true;
											}
										});
									}
									
									if (this.engine.config.serveFile[i].call != null) {
										// We need to call a function so do it
										this.log('Serving config-registered dynamic file data (' + req.connection.finalRemoteAddress + '): ' + pathName);
										this.engine.config.serveFile[i].call.apply(this.engine.config.serveFile[i].context || this, [req, res]);
										served = true;
									}
								}
							}
						}
						
						// Check if we STILL haven't served a file... if so then 404 the request!
						if (!served) {
							try {
								// Access attempted to a folder that we don't want to serve from
								console.log('access failed to:', pathName, req.connection.finalRemoteAddress, localPath);
								this.log('Failed attempt to load file from path (' + req.connection.finalRemoteAddress + '): ' + pathName, 'warning', null, true);
								res.writeHead(404);
								res.write('404');
								res.end();
								served = true;
							} catch (err) {
								// There might have been an error so output it and continue. We don't want to crash here!
								this.log('Error when a file serve request was being processed in IgeNetwork2_FileServer.js: ' + err, 'warning', null, true);
							}
						}
					}
				}));
			}
		}));
		
		// Starting listener
		this.setState(4);
		this.httpServer.listen(this.engine.config.port, null, this.bind(function () {
			this.emit('fileServerStarted');
			if (typeof callback == 'function') {
				callback.apply(this);
			}
		}));
	}
	
};

IgeNetwork.prototype.serveObfuscated = function (req, res, localPath) {
	fs.readFile(localPath, 'utf8', this.bind(function(err, data) {
		if (!err) {
			// Server obfuscated js
			if (this.engine.config.mode == 'release') {
				this.log('Serving protected JavaScript file (' + req.connection.finalRemoteAddress + '): ' + localPath);
			} else {
				this.log('Serving JavaScript file (' + req.connection.finalRemoteAddress + '): ' + localPath);
			}
			var finData = this.engine.obfuscator.obfuscate(data);
			res.writeHead(200, {'Content-Type': 'text/javascript'});
			res.write(finData, 'utf8');
			res.end();
		} else {
			this.log('Failed attempt to load JavaScript file from path (' + req.connection.finalRemoteAddress + '): ' + localPath, 'warning');
			res.writeHead(404);
			res.write('404');
			res.end();
		}
	}));
};

IgeNetwork.prototype.setState = function (state) {
	this.state = state;
	this.emit('stateChanged', state);
};

IgeNetwork.prototype.contentTypes = {
  "aiff": "audio/x-aiff",
  "arj": "application/x-arj-compressed",
  "asf": "video/x-ms-asf",
  "asx": "video/x-ms-asx",
  "au": "audio/ulaw",
  "avi": "video/x-msvideo",
  "bcpio": "application/x-bcpio",
  "ccad": "application/clariscad",
  "cod": "application/vnd.rim.cod",
  "com": "application/x-msdos-program",
  "cpio": "application/x-cpio",
  "cpt": "application/mac-compactpro",
  "csh": "application/x-csh",
  "css": "text/css",
  "deb": "application/x-debian-package",
  "dl": "video/dl",
  "doc": "application/msword",
  "drw": "application/drafting",
  "dvi": "application/x-dvi",
  "dwg": "application/acad",
  "dxf": "application/dxf",
  "dxr": "application/x-director",
  "etx": "text/x-setext",
  "ez": "application/andrew-inset",
  "fli": "video/x-fli",
  "flv": "video/x-flv",
  "gif": "image/gif",
  "gl": "video/gl",
  "gtar": "application/x-gtar",
  "gz": "application/x-gzip",
  "hdf": "application/x-hdf",
  "hqx": "application/mac-binhex40",
  "html": "text/html",
  "ice": "x-conference/x-cooltalk",
  "ico": "image/x-icon",
  "ief": "image/ief",
  "igs": "model/iges",
  "ips": "application/x-ipscript",
  "ipx": "application/x-ipix",
  "jad": "text/vnd.sun.j2me.app-descriptor",
  "jar": "application/java-archive",
  "jpeg": "image/jpeg",
  "jpg": "image/jpeg",
  "js": "text/javascript",
  "json": "application/json",
  "latex": "application/x-latex",
  "less": "text/css",
  "lsp": "application/x-lisp",
  "lzh": "application/octet-stream",
  "m": "text/plain",
  "m3u": "audio/x-mpegurl",
  "man": "application/x-troff-man",
  "manifest": "text/cache-manifest",
  "me": "application/x-troff-me",
  "midi": "audio/midi",
  "mif": "application/x-mif",
  "mime": "www/mime",
  "movie": "video/x-sgi-movie",
  "mp4": "video/mp4",
  "mpg": "video/mpeg",
  "mpga": "audio/mpeg",
  "ms": "application/x-troff-ms",
  "nc": "application/x-netcdf",
  "oda": "application/oda",
  "ogm": "application/ogg",
  "pbm": "image/x-portable-bitmap",
  "pdf": "application/pdf",
  "pgm": "image/x-portable-graymap",
  "pgn": "application/x-chess-pgn",
  "pgp": "application/pgp",
  "pm": "application/x-perl",
  "png": "image/png",
  "pnm": "image/x-portable-anymap",
  "ppm": "image/x-portable-pixmap",
  "ppz": "application/vnd.ms-powerpoint",
  "pre": "application/x-freelance",
  "prt": "application/pro_eng",
  "ps": "application/postscript",
  "qt": "video/quicktime",
  "ra": "audio/x-realaudio",
  "rar": "application/x-rar-compressed",
  "ras": "image/x-cmu-raster",
  "rgb": "image/x-rgb",
  "rm": "audio/x-pn-realaudio",
  "rpm": "audio/x-pn-realaudio-plugin",
  "rtf": "text/rtf",
  "rtx": "text/richtext",
  "scm": "application/x-lotusscreencam",
  "set": "application/set",
  "sgml": "text/sgml",
  "sh": "application/x-sh",
  "shar": "application/x-shar",
  "silo": "model/mesh",
  "sit": "application/x-stuffit",
  "skt": "application/x-koan",
  "smil": "application/smil",
  "snd": "audio/basic",
  "sol": "application/solids",
  "spl": "application/x-futuresplash",
  "src": "application/x-wais-source",
  "stl": "application/SLA",
  "stp": "application/STEP",
  "sv4cpio": "application/x-sv4cpio",
  "sv4crc": "application/x-sv4crc",
  "svg": "image/svg+xml",
  "swf": "application/x-shockwave-flash",
  "tar": "application/x-tar",
  "tcl": "application/x-tcl",
  "tex": "application/x-tex",
  "texinfo": "application/x-texinfo",
  "tgz": "application/x-tar-gz",
  "tiff": "image/tiff",
  "tr": "application/x-troff",
  "tsi": "audio/TSP-audio",
  "tsp": "application/dsptype",
  "tsv": "text/tab-separated-values",
  "txt": "text/plain",
  "unv": "application/i-deas",
  "ustar": "application/x-ustar",
  "vcd": "application/x-cdlink",
  "vda": "application/vda",
  "vivo": "video/vnd.vivo",
  "vrm": "x-world/x-vrml",
  "wav": "audio/x-wav",
  "wax": "audio/x-ms-wax",
  "wma": "audio/x-ms-wma",
  "wmv": "video/x-ms-wmv",
  "wmx": "video/x-ms-wmx",
  "wrl": "model/vrml",
  "wvx": "video/x-ms-wvx",
  "xbm": "image/x-xbitmap",
  "xlw": "application/vnd.ms-excel",
  "xml": "text/xml",
  "xpm": "image/x-xpixmap",
  "xwd": "image/x-xwindowdump",
  "xyz": "chemical/x-pdb",
  "zip": "application/zip"
};
/* CEXCLUDE */