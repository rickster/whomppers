/** IgeState - Provides state management methods to the extending class.
This class is designed to be extended and does not do anything by itself. {
	category:"class",
	engine_ver:"1.0.0",
} **/
IgeState = new IgeClass({
	init: function () {},
	
	/** state - Sets and gets the current state. If a newState is passed, will set the
	current state before returning it. {
		engine_ver:"1.0.0",
		category:"method",
		return: {
			type:"integer",
			desc:"Returns the current state as an integer value.",
		},	
		arguments: [{
			type:"integer",
			name:"newState",
			desc:"The new state value to set.",
		}],
	} **/	
	state: function (newState) {
		if (typeof(newState) != 'undefined') {
			this._state = newState;
		}
		
		return this._state;
	},
});