IgeNetworkProvider_Websocket = new IgeClass({
	
	networkProvider: 'websocket',
	state: 0,
	clientList: null,
	
	setOptions: function (obj) {
		this.io.websocket.options = obj;
		if (typeof(this.io.websocket.options.gameServer) == 'undefined') {
			// Set the host to null
			this.io.websocket.options.gameServer = '';
		}
	},
	
	providerInit: function () {
		if (typeof(this.io.websocket.options) == 'undefined') {
			this.io.websocket.options = {};
		}
		if (typeof(this.io.websocket.options.gameServer) == 'undefined') {
			this.io.websocket.options.gameServer = '';
		}
		
		this._state = 1;
		this.registerCommand('keepAlive', this.bind(this._keepAliveC), this.bind(this._keepAliveS));
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Load the websocket node module
			this.io.websocket.library = require(igeConfig.mapUrl('/node_modules/ws'));
			this.clientList = [];
			this.log('Network provider ready');
			this.emit('networkProviderReady');
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer) {
			// Ask the client to include our client-side library
			this.log('Network provider ready');
			this.emit('networkProviderReady');
		}
	},
	
	keepAlive: function (data, sessionId) {
		this.send('keepAlive');
		this.log('Sending keepAlive');
	},
	
	_keepAliveS: function (data, sessionId) {
		this.log('Received keepAlive');
		this.send('keepAlive', {}, sessionId);
	},
	
	_keepAliveC: function (data, sessionId) {
		this.log('Received keepAlive');
		this.send('keepAlive', {}, sessionId);
	},	
	
	_start: function (callback) {
		var self = this;
		this.io.websocket.onStart = callback;
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Set the websocket pipe settings and create instance
			this.log('Starting listener on port ' + this.engine.config.port);
			this.io.websocket.connection = new this.io.websocket.library.Server({port: this.engine.config.port},
				this.bind(function () {
					// Listen for websocket client events
					this.io.websocket.connection.on('connection', function (client) {
						if (!self._serveClients) {
							self.log('Rejecting client connect, we are not serving clients yet!');
							client.disconnect();
						} else {
							client.id = self.clientList.length;
							self.clientList[client.id] = client;
							
							client.on('message', function (data, flags) {
								self._websocketServer_ClientMessage(data, client, flags);
							});
							
							client.on('close', function () {
								self.log('Client disconnected from session id ' + client.id);
								self.emit('clientDisconnect', client.id);
							});
							
							self.log('Client connected with session id ' + client.id + ' from IP ' + client.address + ':' + client.port);
							self.emit('clientConnect', client.id);
						}
					});
					
					// Set the socket as ready
					this.io.websocket.state = 2;
					
					// Setup the sync tick
					//setInterval(this.bind(this._sendSyncData), Math.floor(1000 / this._cl_updaterate));
					
					// Server is UP!!
					this.setState(5);
					this.emit('networkProviderUp');
					
					if (typeof(this.io.websocket.onStart) == 'function') {
						this.io.websocket.onStart.apply(this);
					}
				})
			);
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer) {
			// Create new websocket instance
			this.io.websocket.connection = new WebSocket("ws://" + this.io.websocket.options.host + ":" + this.io.websocket.options.port + "/");
			
			// Listen for state changes
			this.io.websocket.connection.onopen = function (event) {
				console.log('Connection open', arguments);
				
				// Set the socket as ready
				self.io.websocket.state = 2;
				
				self.emit('networkProviderUp');
				self.emit('serverConnect');
			};
			
			this.io.websocket.connection.onmessage = function (event) {
				self._websocketClient_Receive(event.data);
			};
			
			this.io.websocket.connection.onclose = this.bind(function () {
				self.io.websocket.state = 0;
				console.log('Connection closed', arguments);
			});
		}
	},
	
	/* CEXCLUDE */
	_websocketServer_ClientMessage: function(data, client) {
		if (this._statsEnabled) {
			var bytes = JSON.stringify(data).length;
			this._dataRecv[new Date().getSeconds()] += bytes;
			this._dataRecvAll += bytes;
		}
		
		// Grab the command ID
		var cmdId = data.charCodeAt(0);
		var command = this._commandList._reverse[cmdId];
		var jsonEncoded = data.substr(1, 1);
		
		// Kill the command ID and jsonEncoded bytes from the data
		data = data.slice(2);
		
		// Convert the data from text to an object
		if (jsonEncoded == 1) {
			data = JSON.parse(data);
		}
		
		if (typeof(command) == 'undefined') {
			this.log('Error in network packet, command is undefined!', 'error', packet);
		} else {
			var packetData = data || {};
			if (command == 'clientRequest') {
				//console.log('IGEN REQ DATA:', packet);
				var requestId = packetData.__igeRI;
				delete packetData.__igeRI;
				this.emit('clientRequest', {command:command, data:packetData, requestId:requestId, client:client.id});
			} else {
				this.emit(command, [packetData, client.id]);
			}
		}
	},
	/* CEXCLUDE */
	
	// If websocket connects with us
	_websocketClient_Connect: function () {
		this.log('websocket API connected!');
		this.io.websocket.state = 2;
		
		// Emit an event that we are connected
		this.emit('serverConnect');
	},
	
	// If websocket has an error
	_websocketClient_Error: function () {
		this.log('websocket API error!', 'error', arguments);
		this.io.websocket.state = -1;
	},
	
	_websocketClient_Receive: function (data) {
		if (this._statsEnabled) {
			var bytes = JSON.stringify(data).length;
			this._dataRecv[new Date().getSeconds()] += bytes;
			this._dataRecvAll += bytes;
		}
		
		// Grab the command ID
		var cmdId = data.charCodeAt(0);
		var command = this._commandList._reverse[cmdId];
		var jsonEncoded = data.substr(1, 1);
		
		// Kill the command ID and jsonEncoded bytes from the data
		data = data.slice(2);
		
		// Convert the data from text to an object
		if (jsonEncoded == 1) {
			data = JSON.parse(data);
		}
		
		if (typeof command == 'undefined') {
			this.log('Error in network packet, command is undefined!', 'error', data);
		} else {
			var packetData = data || {};
			if (command == 'serverResponse') {
				var requestId = packetData.__igeRI;
				var requestObj = this._requests[requestId];
				//delete finalData.data.__igeRI;
				if (typeof requestObj.callback == 'function') { requestObj.callback.apply(requestObj.callback, [packetData]); }
			} else {
				this.emit(command, [packetData]);
			}
		}
	},
	
	_stop: function () {
		
	},
	
	send: function (command, sendData, clientId, debug) {
		// Check for a quick exit
		if (this.engine.isServer && !this.clientList.length) { return false; }
		
		//if (!this._doneAlready) { this._doneAlready = 0; }
		//if (this._doneAlready > 10) { return; }
		//this._doneAlready++;
		// Check that we have a socket object to work with
		if (debug) { this.log('Send: Starting...'); }
		if (this.io.websocket.state == 2) {
			var jsonEncoded = 0;
			
			if (sendData && sendData.$local != null) {
				var strippedData = this.engine.stripLocal(sendData);
			} else {
				var strippedData = sendData;
			}
			
			if (typeof(strippedData) == 'object') {
				strippedData = JSON.stringify(strippedData);
				jsonEncoded = 1;
			}
			
			var cmdId = this._commandList[command];
			if (debug) { this.log('Send: Command ID is: ' + cmdId); }
			if (cmdId != null) {
				// Create and encode a new data packet
				var finalPacketData = String.fromCharCode(this._commandList[command]) + jsonEncoded + strippedData;// strippedData);
				
				if (this._statsEnabled) {
					if (debug) { this.log('Send: Recording stats...'); }
					var bytes = JSON.stringify(finalPacketData).length;
					this._dataSend[new Date().getSeconds()] += bytes;
					this._dataSendAll += bytes;
				}
				
				//console.log('Sending:', finalPacketData);
				
				// Depending upon if we are client or server, send the packet accordingly
				/* CEXCLUDE */
				if (this.engine.isServer) {
					// Server code
					if (clientId) {
						if (clientId instanceof Array) {
							// An array of client id's to send to
							if (debug) { this.log('Send: Sending to array of socketId\'s...'); }
							//console.log('Sending data to clients ID by array: ', clientId);
							for (var i in clientId) {
								this.clientList[clientId[i]].send(finalPacketData);
							}
						} else if (typeof clientId == 'object') {
							// A single client object to send to
							if (debug) { this.log('Send: Sending to a single client with session: ' + socketId); }
							//console.log('Sending data to client ID by object: ', clientId.id);
							clientId.send(finalPacketData);
						} else {
							// A single client id to send to
							if (debug) { this.log('Send: Sending broadcast data...'); }
							//console.log('Sending data to client ID: ', clientId);
							this.clientList[clientId].send(finalPacketData);
						}
					} else {
						// Send message to all connected clients
						if (this.clientList.length) {
							var count = this.clientList.length;
							while (count--) {
								var client = this.clientList[count];
								client.send(finalPacketData);
							}
						}
					}
				}
				/* CEXCLUDE */
				if (!this.engine.isServer){
					// Client code
					//console.log('Sending data to server...');
					//console.log(finalPacketData);
					this.io.websocket.connection.send(finalPacketData);
				}
				return true;
			} else {
				this.log('Attempted to send a network packet using a command that does not exist!', 'warning', command);
				return false;
			}
		} else {
			this.log('Websocket state error, cannot send messages in this state!', 'warning', this.io.websocket.state);
		}
	},
	
});

// Register this provider with the network class
IgeNetwork.prototype.io = IgeNetwork.prototype.io || [];
IgeNetwork.prototype.io.websocket = {};
IgeNetwork.prototype.io.websocket.classMethod = IgeNetworkProvider_Websocket;