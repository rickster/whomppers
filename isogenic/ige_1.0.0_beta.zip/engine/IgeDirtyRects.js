/** IgeDirtyRects - Manages dirty rectangles for the rendering system. {
	category:"class",
} **/
IgeDirtyRects = new IgeClass({
	
	Extends: IgeEvents,
	
	engine: null,
	
	// Constructor
	init: function (engine) {
		this._className = 'IgeDirtyRects';
		
		this.engine = engine;
	},
	
	/* create - Create a dirty rectangle map attached to the map object passed, with the
	specified width and height of each rectangle. */
	create: function (map, width, height) {
		// Check the width and height are divisible by 2
		var w2 = width / 2;
		var h2 = height / 2;
		
		if (Math.floor(w2) != w2) {
			this.log('Trying to set the width of the dirty rectangles to a value not divisible by 2!', 'error', 'Error on Width: ' + width);
		} else if (Math.floor(h2) != h2) {
			this.log('Trying to set the height of the dirty rectangles to a value not divisible by 2!', 'error', 'Error on Height: ' + height);
		} else {
			// Setup a local variable in the map object to store dirty regions in
			map.$local.$dirtyRects = {
				tileWidth: width,
				tileHeight: height,
				layer: [],
			};
			
			map.$local.$entityCache = [];
			
			// Loop through the map's layers and create the arrays that will hold data on the layer drs
			this.cleanMap(map);
		}
	},
	
	/* addEntityToCache - Adds an entity to the map's entity cache that allows the dirty rect system to identify
	which entities are inside a specific dirty rectangle and draw only those entities without looping and doing
	expensive hit-testing against rects and entity bounds every render-frame. */
	addEntityToCache: function (entity, map, rect) {
		// TO-DO - This is no longer valid in 1.0.0 because of the new transform system
		// and also getSize and getPosition are depreciated
		if (entity.$local != null) {
			// Check if we were given a map object
			if (!map) {
				map = entity.$local.$map;
			}
			
			if (map != null) {
				// Check if we were passed the rect to use
				if (!rect) {
					// No rect passed so calculate it from the entity
					var entSize = this.engine.entities.getSize(entity);
					var entPos = this.engine.entities.getPosition(entity);
					
					var renderMode = map.map_render_mode;
					
					// Generate rect array (left, top, width, height)
					rect = [entPos[renderMode][0], entPos[renderMode][1], entSize[2], entSize[3]];
				}
				
				// Store the entity layer and map's dirty rect object
				var layerIndex = entity.entity_layer;
				var dr = map.$local.$dirtyRects;
				
				// Define the cache based upon the layer the entity resides on
				map.$local.$entityCache[layerIndex] = map.$local.$entityCache[layerIndex] || [];
				
				// Calculate which dirty rects the corners of the rect intersect
				// Top-left
				var tile1 = this.pointInTile(rect[0], rect[1], dr);
				// Top-right
				var tile2 = this.pointInTile(rect[0] + rect[2], rect[1], dr);
				// Bottom-left
				var tile3 = this.pointInTile(rect[0], rect[1] + rect[3], dr);
				// Bottom-right
				var tile4 = this.pointInTile(rect[0] + rect[2], rect[1] + rect[3], dr);
				
				// Loop through all the rects this entity intersects and add this entity to the cache
				for (var dirtyTileX = tile1[0]; dirtyTileX <= tile2[0]; dirtyTileX++) {
					
					for (var dirtyTileY = tile1[1]; dirtyTileY <= tile3[1]; dirtyTileY++) {
						
						map.$local.$entityCache[layerIndex][dirtyTileX] = map.$local.$entityCache[layerIndex][dirtyTileX] || [];
						map.$local.$entityCache[layerIndex][dirtyTileX][dirtyTileY] = map.$local.$entityCache[layerIndex][dirtyTileX][dirtyTileY] || [];
						
						// Add the entity to the map's entity cache by layer, x and y
						map.$local.$entityCache[layerIndex][dirtyTileX][dirtyTileY].push(entity);
						
						// Add the dirty rect details to the entity's dirty rect cache by x, y and map cache array index
						entity.$local.$dirtyRectCache = entity.$local.$dirtyRectCache || [];
						entity.$local.$dirtyRectCache.push([dirtyTileX, dirtyTileY]);
						
					}
					
				}
			}
		}
	},
	
	/* removeEntityFromCache - Removes the passed entity from the dirty rectangle cache so that it will not be
	rendered if the dirty rectangles that the entity resides on in the cache are redrawn. */
	removeEntityFromCache: function (entity) {
		var layerIndex = entity.entity_layer;
		
		if (entity.$local != null) {
			var map = entity.$local.$map;
			
			if (map != null) {
				var mapCache = map.$local.$entityCache;
				
				var entityCache = entity.$local.$dirtyRectCache;
				
				if (entityCache != null) {
					var cacheCount = entityCache.length;
					
					while (cacheCount--) {
						var cacheEntry = entityCache[cacheCount];
						var spliceIndex = mapCache[layerIndex][cacheEntry[0]][cacheEntry[1]].indexOf(entity);
						
						if (spliceIndex > -1) {
							mapCache[layerIndex][cacheEntry[0]][cacheEntry[1]].splice(spliceIndex, 1);
						}
					}
					
					entity.$local.$dirtyRectCache = [];
				}
				
			}
		}
	},
	
	/* cleanMap - Removes all dirty rectangles from the given map. */
	cleanMap: function (map) {
		var dr = map.$local.$dirtyRects;
		var layerCount = map.map_layers.length;
		
		// Create a layer array
		dr.layer = [];
		
		// Loop through the map layers
		while (layerCount--) {
			
			dr.layer[layerCount] = {
				isSet: [],
				dirty: [],
			}
			
		}
	},
	
	/* isMapDirty - Returns 0 if map is clean or a positive integer detailing the number of dirty
	rectangles that this map currently has. */
	isMapDirty: function (map, layerIndex) {
		if (map.$local.$dirtyRects && map.$local.$dirtyRects.layer) {
			return (map.$local.$dirtyRects.layer[layerIndex].dirty.length);
		}
		
		return 0;
	},
	
	/* markDirtyByRect - Marks dirty rectangles by the corner co-ordinates of the rect passed. */
	markDirtyByRect: function (map, rect, layerIndex) {
		// Calculate the corner co-ordinates of the rect and then make dirty which ever
		// rects they reside in. Each corner can reside in a different rect.
		var dr = map.$local.$dirtyRects;
		
		// Calculate which dirty rects the corners of the rect intersect
		// Top-left
		var tile1 = this.pointInTile(rect[0], rect[1], dr);
		// Top-right
		var tile2 = this.pointInTile(rect[0] + rect[2], rect[1], dr);
		// Bottom-left
		var tile3 = this.pointInTile(rect[0], rect[1] + rect[3], dr);
		// Bottom-right
		var tile4 = this.pointInTile(rect[0] + rect[2], rect[1] + rect[3], dr);
		
		// Now that we have the corners, loop through the tiles and mark them dirty
		for (var dirtyTileX = tile1[0]; dirtyTileX <= tile2[0]; dirtyTileX++) {
			
			for (var dirtyTileY = tile1[1]; dirtyTileY <= tile3[1]; dirtyTileY++) {
				
				this.markDirtyByTile(dr, dirtyTileX, dirtyTileY, layerIndex);
				
			}
			
		}
		
	},
	
	/* pointInTile - Returns the dirty rectangle x and y that the given screen x and y is inside. */
	pointInTile: function (x, y, dirtyRects) {
		return [Math.floor(x / dirtyRects.tileWidth), Math.floor(y / dirtyRects.tileHeight)];
	},
	
	/* markDirtyByTile - Mark dirty rectangle by a given dirty rectangle x and y. */
	markDirtyByTile: function (dirtyRects, tileX, tileY, layerIndex) {
		dirtyRects.layer[layerIndex].isSet = dirtyRects.layer[layerIndex].isSet || [];
		dirtyRects.layer[layerIndex].isSet[tileX] = dirtyRects.layer[layerIndex].isSet[tileX] || [];
		
		if (!dirtyRects.layer[layerIndex].isSet[tileX][tileY]) {
			dirtyRects.layer[layerIndex].dirty = dirtyRects.layer[layerIndex].dirty || [];
			dirtyRects.layer[layerIndex].dirty.push([tileX, tileY]);
			dirtyRects.layer[layerIndex].isSet[tileX][tileY] = true;
		}
	},
	
	/* clearCanvasDirtyRects - Clears all the dirty rectangles that need redrawing. Can clear either the back or front buffer
	by specifying the second argument. 0 = back buffer, 1 = front buffer. If using the front buffer, a
	third argument is required which is the layer index (integer) of the layer to clear. */
	clearCanvasDirtyRects: function (viewport, buffer, layerIndex) {
		if (!buffer) {
			// Operate on the back-buffer
			var bufCtx = viewport.$local.$backBufferCtx;
		} else {
			// Opertate on a front-buffer
			var bufCtx = viewport.$local.$frontBufferCtx[layerIndex];
		}
		
		// Get the rects data
		var vpDrs = viewport.$local.$map.$local.$dirtyRects;
		var rects = vpDrs.layer[layerIndex].dirty;
		var rectCount = rects.length;
		var rect = null;
		var screenX = null;
		var screenY = null;
		var tileWidth = vpDrs.tileWidth;
		var tileHeight = vpDrs.tileHeight;
		var centerX = viewport.$viewportAdjustX;
		var centerY = viewport.$viewportAdjustY;
		var camera = viewport.$local.$camera;
		var cameraScale = camera.camera_scale;
		
		// Scale the grid
		bufCtx.save();
		bufCtx.scale(cameraScale, cameraScale);
		
		// Loop through all the dirty rects
		while (rectCount--) {
			// Get the individual rect co-ordinates
			rect = rects[rectCount];
			
			// Calculate the screen co-ordinates
			screenX = (rect[0] * tileWidth) + centerX;
			screenY = (rect[1] * tileHeight) + centerY;
			
			// Clear the rect
			bufCtx.clearRect(screenX, screenY, tileWidth, tileHeight);
		}
		
		bufCtx.restore();
	},
	
	drawGrid: function (viewport, layerIndex) {
		// Get front-buffer
		var buffer = viewport.$local.$frontBuffer[layerIndex];
		var bufCtx = viewport.$local.$frontBufferCtx[layerIndex];
		
		if (bufCtx != null) {
			var vpDrs = viewport.$local.$map.$local.$dirtyRects;
			var isSet = vpDrs.layer[layerIndex].isSet;
			var tileX = 0;
			var tileY = 0;
			var startTileX = -Math.floor((viewport.viewport_container.width / 2) / vpDrs.tileWidth);
			var startTileY = -Math.floor((viewport.viewport_container.height / 2) / vpDrs.tileHeight);
			var screenX = 0;
			var screenY = 0;
			var centerX = viewport.$viewportAdjustX;
			var centerY = viewport.$viewportAdjustY;
			var camera = viewport.$local.$camera;
			var cameraScale = camera.camera_scale;
			
			// Clear the buffer
			//bufCtx.clearRect(0, 0, buffer.width, buffer.height);
			
			if (vpDrs.tileWidth && vpDrs.tileHeight) {
				
				// Set the line colour
				bufCtx.strokeStyle = '#ff0000';
				
				// Scale the grid
				bufCtx.save();
				bufCtx.scale(cameraScale, cameraScale);
				
				// Draw the rects
				for (tileX = startTileX; (tileX * (vpDrs.tileWidth * cameraScale)) < (viewport.viewport_container.width / 2); tileX++) {
					
					screenX = (tileX * vpDrs.tileWidth) + centerX;
					
					bufCtx.beginPath();
					bufCtx.moveTo(screenX, 0);
					bufCtx.lineTo(screenX, viewport.panLayer.height / cameraScale);
					bufCtx.stroke();
					
					for (tileY = startTileY; (tileY * (vpDrs.tileHeight * cameraScale)) < (viewport.viewport_container.height / 2); tileY++) {
						
						screenY = (tileY * vpDrs.tileHeight) + centerY;
						
						bufCtx.beginPath();
						bufCtx.moveTo(0, screenY);
						bufCtx.lineTo(viewport.panLayer.width / cameraScale, screenY);
						bufCtx.stroke();
						
						bufCtx.fillStyle = '#ffffff';
						bufCtx.fillText(tileX + ', ' + tileY, screenX + 10, screenY + 10);
						
					}
				}
				
				bufCtx.restore();
				
			}
		} else {
			this.log('Trying to output dirty rectangle debug grid to layer ' + layerIndex + ' but it is not a canvas layer!', 'error');
		}
	},
	
	drawGridRects: function (viewport, layerIndex, drs) {
		this.log('DR grid rects is currently disabled in 1.0.0.');
		return;
		// Get front-buffer
		var buffer = viewport.$local.$frontBuffer[layerIndex];
		var bufCtx = viewport.$local.$frontBufferCtx[layerIndex];
		var vpDrs = viewport.$local.$map.$local.$dirtyRects;
		var isSet = vpDrs.layer[layerIndex].isSet;
		var tileX = 0;
		var tileY = 0;
		var startTileX = -Math.floor(viewport.$viewportAdjustX / vpDrs.tileWidth) - 1;
		var startTileY = -Math.floor(viewport.$viewportAdjustY / vpDrs.tileHeight) - 1;
		var screenX = 0;
		var screenY = 0;
		var centerX = viewport.$viewportAdjustX;
		var centerY = viewport.$viewportAdjustY;
		var camera = viewport.$local.$camera;
		
		// Clear the buffer
		//bufCtx.clearRect(0, 0, buffer.width, buffer.height);
		
		if (vpDrs.tileWidth && vpDrs.tileHeight) {
			
			// Set the line colour
			bufCtx.strokeStyle = '#ff0000';
			
			// Scale the grid
			bufCtx.save();
			bufCtx.scale(cameraScale, cameraScale);
			
			for (var drIndex = 0; drIndex < drs.length; drIndex++) {
				var tileX = drs[drIndex][0];
				var tileY = drs[drIndex][1];
				
				screenX = (tileX * vpDrs.tileWidth) + centerX;
				screenY = (tileY * vpDrs.tileHeight) + centerY;
				
				var cRed = Math.floor(Math.random() * 255);
				var cGreen = Math.floor(Math.random() * 255);
				var cBlue = Math.floor(Math.random() * 255);
				
				// This rect is dirty so mark it on the map
				bufCtx.fillStyle = 'rgba(' + cRed + ', ' + cGreen + ', ' + cBlue + ', 0.5)';
				//bufCtx.fillStyle = '#0000ff';
				bufCtx.clearRect(screenX, screenY, vpDrs.tileWidth, vpDrs.tileHeight);
				bufCtx.fillRect(screenX, screenY, vpDrs.tileWidth, vpDrs.tileHeight);
			}
			
			bufCtx.restore();
			
		}
	},
	
	/////////////////////////////////////////////////////////////
	// 1.0.0 re-code of dr system
	/////////////////////////////////////////////////////////////
	/** storeRect - Stores dirty rectangles for the renderer to use later. {
		category:"method",
	} **/
	storeRect: function (map, layerIndex, rect1, rect2) {
		// Add 1 to all values to ensure bounding covers rendering
		
		rect1[0] = Math.floor(rect1[0] -= 1);
		rect1[1] = Math.floor(rect1[1] -= 1);
		rect1[2] = Math.ceil(rect1[2] += 2);
		rect1[3] = Math.ceil(rect1[3] += 2);
		
		if (rect2) {
			rect2[0] = Math.floor(rect2[0] -= 1);
			rect2[1] = Math.floor(rect2[1] -= 1);
			rect2[2] = Math.ceil(rect2[2] += 2);
			rect2[3] = Math.ceil(rect2[3] += 2);
		}
		
		// Ensure the dr2 array exists
		var mapLocal = map.$local;
		mapLocal.$dr2 = mapLocal.$dr2 || [];
		
		var dr2 = mapLocal.$dr2;
		dr2[layerIndex] = dr2[layerIndex] || [];
		
		var drLayer = dr2[layerIndex];
		
		// Check if we were passed one or two rects
		if (typeof(rect2) == 'undefined') {
			// A single rect was passed, store it
			drLayer.push(rect1);
		} else {
			// Two rects were passed, check for intersect
			var intersect = this.rectIntersect(rect1, rect2);
			
			if (intersect) {
				// The rects intersect, merge them and store the result
				drLayer.push(this.mergeRects(rect1, rect2));
			} else {
				// The rects do not intersect, store them both
				drLayer.push(rect1);
				drLayer.push(rect2);
			}
		}
	},
	
	/** consolidateRects - Scans all the rects in memory and merges those that
	intersect each other to reduce the overall number of rects. {
		category:"method",
	} **/
	consolidateRects: function (map) {
		var finalArr = [];
		var layerArr = map.$local.$dr2;
		
		if (layerArr) {
			var layerCount = layerArr.length;
			
			while (layerCount--) {
				finalArr[layerCount] = [];
				var drArr = map.$local.$dr2[layerCount];
				
				// Check if there is a dirty rectangle array for this layer
				if (drArr) {
					var count1 = drArr.length;
					
					while (count1--) {
						var rect1 = drArr[count1];
						var count2 = drArr.length;
						while (count2--) {
							if (count1 != count2) {
								// Check if rect1 intersects rect2
								var rect2 = drArr[count2];
								var intersect = this.rectIntersect(rect1, rect2);
								
								// If intersecting, merge
								if (intersect) {
									// Merge the rects
									finalArr[layerCount].push(this.mergeRects(rect1, rect2));
								}
							}
						}
					}
				}
			}
		}
		
		return finalArr;
	},
	
	mergeIntersects: function () {
		
	},
	
	/** clearRects - Clears all rects in memory for a particular map. {
		category:"method",
	} **/
	clearRects: function (map) {
		map.$local.$dr2 = [];
	},
	
	/** rectIntersect - Checks if the two rects passed intersect each other. {
		category:"method",
	} **/
	rectIntersect: function (rect1, rect2) {
		if (rect1 && rect2) {
			var sX1 = rect1[0];
			var sY1 = rect1[1];
			var sW = rect1[2];
			var sH = rect1[3];
			
			var dX1 = rect2[0];
			var dY1 = rect2[1];
			var dW = rect2[2];
			var dH = rect2[3];
			
			var sX2 = sX1 + sW;
			var sY2 = sY1 + sH;
			var dX2 = dX1 + dW;
			var dY2 = dY1 + dH;
			
			if (sX1 < dX2 && sX2 > dX1 && sY1 < dY2 && sY2 > dY1) {
				return true;
			}
		}
		return false;
	},
	
	/** mergeRects - Merges the passed rects into one larger rect which has
	the bounds of the minimum and maximum extents of both rects then returns a
	single rect. {
		category:"method",
	} **/
	mergeRects: function (rect1, rect2) {
		// Check for duplicate
		if (rect1[0] == rect2[0] &&
			rect1[1] == rect2[1] &&
			rect1[2] == rect2[2] &&
			rect1[3] == rect2[3]) { 
				return rect1;
		}
		
		// Min and max
		var minX = Math.min(rect1[0], rect2[0]);
		var minY = Math.min(rect1[1], rect2[1]);
		var maxW = Math.max(rect1[2], rect2[2]);
		var maxH = Math.max(rect1[3], rect2[3]);
		
		var absW = Math.abs(rect1[0] - rect2[0]) + maxW;
		var absH = Math.abs(rect1[1] - rect2[1]) + maxH;
		
		// Merged rect
		return [
			minX,
			minY,
			absW,
			absH
		];
	}
	
});