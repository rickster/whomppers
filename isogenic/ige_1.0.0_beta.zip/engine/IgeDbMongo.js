//var sys = require("sys");
var mongo = {};
mongo.Db = require(igeConfig.mapUrl('/node_modules/mongodb')).Db;
mongo.Connection = require(igeConfig.mapUrl('/node_modules/mongodb')).Connection;
mongo.Server = require(igeConfig.mapUrl('/node_modules/mongodb')).Server;
mongo.BSON = mongo.Db.bson_serializer;

/** IgeDatabaseProvider_Mongo - The MongoDB database provider class. {
	category:"class",
	externalLibs:[{
		name:"node-mongodb-native",
		desc:"MongoDB Native Node.js Driver",
		url:"https://github.com/christkv/node-mongodb-native",
	}]
} **/
IgeDatabaseProvider_Mongo = new IgeClass({
	
	_currentProvider: 'mongo',
	client: null, // Holds the client connection
	
	/* Server settings */
	_ip: null,
	_port: null,
	_id: null,
	_username: null,
	_password: null,
	_strict: null,
	_nativeParser: null,
	
	// Constructor
    init: function() {},
	
	/** setOptions - Set the internal DB connection settings. {
		category:"method",
		arguments:[{
			name:"params",
			type:"object",
			desc:"An object containing the database parameters to use to connect to the database.",
		}],
	}**/
	setOptions: function (params) {
		this._host = params.host;
		this._port = params.port;
		this._database = params.database;
		this._username = params.user;
		this._password = params.pass;
		this._strict = params.strict;
		this._nativeParser = params.nativeParser;
		
		if (!this._port) { this._port = 27017; }
	},
	
	/** connect - Use the internal DB settings to connect to the
	mongo database server. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"A callback method that will be called when the mongo connection is established.",
			flags:"optional",
		}],
	}**/
	connect: function (callback) {
		this.log('Connecting to mongo database "'  + this._database + '" @' + this._host + ':' + this._port);
		var mongoServer = new mongo.Server(
			this._host,
			parseInt(this._port),
			{}
		);
		
		this.client = new mongo.Db(
			this._database,
			mongoServer,
			{native_parser: this._nativeParser}
		);
		
		this.client.strict = this._strict;
		
		// Open the database connection
		this.client.open(this.bind(function(err, db) {
			// If we have a username then authenticate!
			if (this._username) {
				this.client.authenticate(this._username, this._password, this.bind(function (err) {
					if (err) {
						this.log('Error when connecting to the database!');
						console.log(err);
					} else {
						this.log('Connected to mongo DB ok, processing callbacks...');
						this._connected.apply(this, [err, db, callback]);
					}
				}));
			} else {
				if (err) {
					this.log('Error when connecting to the database!');
					console.log(err);
				} else {
					this.log('Connected to mongo DB ok, processing callbacks...');
					this._connected.apply(this, [err, db, callback]);
				}
			}
		}));
		
	},
	
	/** disconnect - Disconnect from the current mongo connection. {
		category:"method",
		arguments:[{
			name:"callback",
			type:"function",
			desc:"A callback method that will be called when the mongo connection is disconnected.",
			flags:"optional",
		}],
	}**/
	disconnect: function (callback) {
		this.log("Closing DB connection...");
		this.client.close();	
	},
	
	/** _connected - Called by the connect() method. {
		category:"method",
		arguments:[{
			name:"err",
			type:"string",
			desc:"The error string if one was created.",
		}, {
			name:"db",
			type:"object",
			desc:"The database connection object.",
		}, {
			name:"callback",
			type:"function",
			desc:"A callback method.",
			flags:"optional",
		}],
	}**/
	_connected: function (err, db, callback) {
		if (!err) {
			this.log('MongoDB connected successfully.');
			this.emit('connected');
		} else {
			this.log('MongoDB connection error', 'error', err);
			this.emit('connectionError');
		}
		
		if (typeof callback == 'function') { callback.apply(this, [err, db]); }
	},
	
	/* createIndex - Creates an index with the following passed paramters:
		coll - The collection name to create the index on
		indexName - The name of the index
		indexFields - A json object of fields and the index order e.g.
			{name:1} - indexes the name field ascending
			{name:1, age:-1} - indexes the name field ascending and age descending
		params - Json object of index options e.g.
			{unique:true} - Creates a unique index on the passed fields in indexFields
			{unique:true, dropDups:true} - Creates a unique index on the passed fields
				in indexFields and also removes rows that are duplicates to unique data
	*/
	createIndex: function (coll, indexName, indexFields, params, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				var tmpFields = [];
				tmpFields.push([indexName]);
				
				for (var i in indexFields)
				{
					tmpFields.push([i, indexFields[i]]);
				}
				
				___tempCollection.createIndex(tmpFields, this.bind(
					function(___err, ___indexName) {
						
						var ___success;
						___success = ___indexName || false;
						
						// Callback the result
						if (typeof callback == 'function') { callback.apply(this, [___success, ___indexName]); }
						
					}
				))
				
			}
		));
		
	},
	
	/* insert - Insert a row into the DB */
	insert: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot get collection ' + coll + ' with error: ' + ___err, 'warning', ___tempCollection);
				} else {
					// Got the collection (or ___err)
					___tempCollection.insert(json, this.bind(
						function (___err, ___docs) {
							
							if (!___err) {
							
								if (___docs.length > 1) {
									for (var i in ___docs)
									{
										this.idToCollectionId(coll, ___docs[i]);
									}
								} else {
									___docs = ___docs[0];
									this.idToCollectionId(coll, ___docs);
								}
							
							} else {
								this.log('Items you submit to be inserted in the database must be wrapped in an array. Are you wrapping it like [jsonObj] ?');
								this.log('Mongo cannot insert item into database, error: ' + ___err, 'warning', json);
							}
							
							// Callback the result
							if (typeof callback == 'function') { callback(___err, ___docs); }
							
						}
					));
				}
				
			}
			
		));
		
	},
	
	/* update - Update rows in the DB */
	update: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot update collection ' + coll + ' with error: ' + ___err, 'warning', ___tempCollection);
				} else {
					
					this.collectionIdToId(coll, json);
					
					___tempCollection.update({'_id':json._id}, json, {upsert: false, safe: false}, this.bind(
						function (___err, ___docs) {
							// Check the status of the last message
							/*this.client.lastStatus(function(err, status) {
								console.log('status', err, status);
							});*/
							
							this.idToCollectionId(coll, json);
							
							// Callback the result
							if (typeof callback == 'function') { callback.apply(this, [___err, ___docs]); }
							
						}
					));
					
				}
				
			}
			
		));
		
	},
	
	/* A more flexable update function that is not limited to selecting by ID values */
	flexUpdate: function (coll, jsonCriteria, jsonNewObj, options, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot update collection ' + coll + ' with error: ' + ___err, 'error', ___tempCollection);
				} else {
					var ___options = options || {upsert: false, safe: false, multi:true};
					
					___tempCollection.update(jsonCriteria, jsonNewObj, ___options, this.bind(
						function (___err, ___docs) {
							// Callback the result
							if (typeof callback == 'function') { callback.apply(this, [___err, ___docs]); }
							
						}
					));
					
				}
				
			}
			
		));
		
	},
	
	/* Drop a collection */
	clear: function (col1, callback) {
	
		this.client.collection(col1, this.bind(
			function (__err, __tempCollection) {
			
				if (__err)
				{
					this.log('Mongo cannot drop collection ' + col1 + ' with error: ' + __err, 'error', __tempCollection);
				} else {
					__tempCollection.remove(this.bind(
						function (__err, __tempCollection)
						{
							if (__err)
							{
								callback(false, __err);
							} else {
								callback(true);
							}
						}
					));
				}
			
			}
		));
	
	},
	
	/* find - Finds either 1 or more rows of data and returns them (single row returns object,
	multiple rows return an array of objects */
	find: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot run a find on collection ' + coll + ' with error: ' + ___err, 'error', ___tempCollection);
				} else {
					
					// Got the collection (or ___err)
					___tempCollection.find(json, this.bind(
						function (___err, ___tempCursor) {
							
							if (___tempCursor.length > 1)
							{
								
								// Got the result cursor (or ___err)
								___tempCursor.toArray(this.bind(
									function (___err, ___results) {
										
										var ___gotData;
										if (___results) { ___gotData = true; } else { ___gotData = false; ___results = ___err; }
										
										if (___gotData)
										{
											
											for (var i in ___results)
											{
												
												this.idToCollectionId(coll, ___results[i]);
												
											}
											
										}
										
										// Got results array (or ___err)
										// Callback the result array
										if (typeof callback == 'function') { callback.apply(this, [___gotData, ___results]); }
										
									}
								))
								
							} else {
								
								// Got the result cursor (or ___err)
								___tempCursor.nextObject(this.bind(
									function (___err, ___results) {
										
										var ___gotData;
										___gotData = ___results || false;
										
										// Process a single return value
										if (___gotData)
										{
											
											this.idToCollectionId(coll, ___results);
											
										}
										
										// Got results array (or ___err)
										// Callback the result array
										if (typeof callback == 'function') { callback.apply(this, [___gotData, ___results]); }
										
									}
								))
								
							}
							
						}
					));
					
				}
				
			}
		));
		
	},
	
	/* findOne - Finds 1 row of data and returns it as a single object */
	findOne: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot run a findOne on collection ' + coll + ' with error: ' + ___err, 'error', ___tempCollection);
				} else {
					
					// Got the collection (or ___err)
					___tempCollection.find(json, this.bind(
						function (___err, ___tempCursor) {
							
							// Got the result cursor (or ___err)
							___tempCursor.nextObject(this.bind(
								function (___err, ___results) {
									
									var ___gotData;
									___gotData = ___results || false;
									
									if (___gotData)
									{
										
										this.idToCollectionId(coll, ___results);
										
									}
									
									// Got results array (or ___err)
									// Callback the result array
									if (typeof callback == 'function') { callback.apply(this, [___gotData, ___results]); }
									
								}
							))
							
						}
					));
					
				}
				
			}
		));
		
	},
	
	/* findAll - Finds many rows of data and returns them as an array */
	findAll: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot run a findAll on collection ' + coll + ' with error: ' + ___err, 'error', ___tempCollection);
				} else {
					
					// Got the collection (or ___err)
					___tempCollection.find(json, this.bind(
						function (___err, ___tempCursor) {
							
							// Got the result cursor (or ___err)
							___tempCursor.toArray(this.bind(
								function (___err, ___results) {
									
									var ___gotData;
									if (___results.length) { ___gotData = true; } else { ___gotData = false; ___results = ___err; }
									
									if (___gotData)
									{
										
										for (var i in ___results)
										{
											
											this.idToCollectionId(coll, ___results[i]);
											
										}
										
									}
									
									// Got results array (or ___err)
									// Callback the result array
									if (typeof callback == 'function') { callback.apply(this, [___gotData, ___results]); }
									
								}
							))
							
						}
					));
					
				}
				
			}
		));
		
	},
	
	/* remove - Removes all rows that match the passed criteria */
	remove: function (coll, json, callback) {
		
		var result = this.client.collection(coll, this.bind(
			function (___err, ___tempCollection) {
				
				if (___err) {
					this.log('Mongo cannot run a remove on collection ' + coll + ' with error: ' + ___err, 'error', ___tempCollection);
				} else {
					
					this.collectionIdToId(coll, json);
					
					//console.log('removing', json);
					
					// Got the collection (or ___err)
					___tempCollection.remove(json, {safe:true}, this.bind(
						function (___err, ___tempCollection) {
							
							// Got results array (or ___err)
							// Callback the result array
							if (typeof callback == 'function') { callback.apply(this, [___err]); }
							
						}
					));
					
				}
				
			}
		));
		
	},
	
	/* idToCollectionId - MongoDB specific - Finds the _id field returned by the database and
	renames it to COLL_id where COLL = collection name e.g. with data from the "test" collection
	the resulting object would have its ID stored in the field called test_id. This is very
	useful when making Mongo data compatible with other databases whose tables will usually have
	their ID (primary key) fields in the format of tableName_dbId */
	idToCollectionId: function (coll, obj) {
		
		obj[coll + '_db_id'] = String(obj._id);
		delete obj._id;
		
	},
	
	/* collectionIdToId - MongoDB specific - Reverse of the idToCollectionId method */
	collectionIdToId: function (coll, obj) {
		
		if (obj[coll + '_db_id']) {
			obj._id = new this.client.bson_serializer.ObjectID(obj[coll + '_db_id']);
			delete obj[coll + '_db_id'];
		}
		
	},
	
});

// Register this provider with the network class
IgeDatabase.prototype._providers = IgeDatabase.prototype._providers || [];
IgeDatabase.prototype._providers.mongo = {};
IgeDatabase.prototype._providers.mongo.classMethod = IgeDatabaseProvider_Mongo;