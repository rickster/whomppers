/** IgeEntities - The entity management class. {
	category:"class",
	examples:[{
		name:"Create an Entity at World Co-ordinates",
		desc:"Create a basic entity that uses a pre-defined asset and exists at the world co-ordinates 0, 0, 0.",
		code:"<pre>
			// Ask the engine to create a new entity using the 'explodingClown' asset
			this.ige.entities.create({
				entity_id:'test1', // Set the entity_id, this is optional as one will be generated if none is presented
				entity_transform:{
					translate:[0, 0, 0],
					scale:[1, 1, 1],
					rotate:[0, 0, 0],
					origin:[0.5, 0.5, 0.5],
					opacity:[1, 1, 1],
				},
				asset_id:'explodingClown',
			});
		</pre>",
	}, {
		name:"Create an Entity at Tile Co-ordinates",
		desc:"Create a basic entity that uses a pre-defined asset and exists at the tile co-ordinates 1, 2, 0.",
		code:"<pre>
			// Ask the engine to create a new entity using the 'explodingClown' asset
			this.ige.entities.create({
				entity_id:'test1', // Set the entity_id, this is optional as one will be generated if none is presented
				entity_transform:{
					// Translate array: x, y, z, relative, tile-based
					translate:[1, 2, 0, false, true],
					scale:[1, 1, 1],
					rotate:[0, 0, 0],
					origin:[0.5, 0.5, 0.5],
					opacity:[1, 1, 1],
				},
				asset_id:'explodingClown',
			});
		</pre>",
	}],
} **/

/** entityData - The properties that can be used in an entity object. {
	category:"definition",
	engine_ver:"0.2.0",
	contents:{
		entity_id: {
			type:"string",
			desc:"The entity's unique id. If none is provided the engine will auto-assign an id for you.",
			flags:"optional",
		},
		entity_type:{
			type:"integer",
			desc:"The type of entity this data represents.",
			valueOf: {
				ENTITY_TYPE_BACKGROUND: {
					type:"integer",
					desc:"The entity is a background image.",
				},
				ENTITY_TYPE_TILE: {
					type:"integer",
					desc:"The entity is a background tile.",
				},
				ENTITY_TYPE_OBJECT: {
					type:"integer",
					desc:"The entity is a static object.",
				},
				ENTITY_TYPE_SPRITE: {
					type:"integer",
					desc:"The entity is a sprite.",
				},
				ENTITY_TYPE_UI: {
					type:"integer",
					desc:"The entity is a user-interface element.",
				},
			},
		},
		entity_layer: {
			type:"integer",
			desc:"The layer to render the entity on. Entities on layer zero are always drawn below entities on layer 1. You cannot simply make up layer numbers, these must match the layers in the map definition.",
		},
		entity_tile_x: {
			type:"integer",
			desc:"The entity tile x co-ordinate.",
			flags:"optional",
		},
		entity_tile_y: {
			type:"integer",
			desc:"The entity tile y co-ordinate.",
			flags:"optional",
		},
		entity_tile_z: {
			type:"integer",
			desc:"The entity z co-ordinate.",
			flags:"optional",
		},
		map_tile_width: {
			type:"integer",
			desc:"The width in tiles that this entity takes up on the tile map.",
			flags:"optional",
		},
		map_tile_height: {
			type:"integer",
			desc:"The height in tiles that this entity takes up on the tile map.",
			flags:"optional",
		},
		entity_persist: {
			type:"integer",
			desc:"The persist flag determines if this data will be removed from the engine, the server, the database and all connected clients when either the server starts up or the client that created the data disconnects from the server. When set to true, the data will NOT be automatically removed.",
			valueOf: {
				PERSIST_ENABLED:  {
					type:"integer",
					desc:"The entity will persist across disconnects and server restarts.",
				},
				PERSIST_DISABLED:  {
					type:"integer",
					desc:"The entity will not persist across disconnects and server restarts.",
				},
			},
		},
		entity_locale: {
			type:"integer",
			desc:"Determines where the entity exists and where it should be propagated to. To specify a locale AND database storage, use the locale + db for example LOCALE_EVERYWHERE + LOCALE_DB.",
			valueOf: {
				LOCALE_EVERYWHERE:  {
					type:"integer",
					desc:"The entity exists everywhere.",
				},
				LOCALE_ALL_CLIENTS:  {
					type:"integer",
					desc:"The entity only exists on clients.",
				},
				LOCALE_SINGLE_CLIENT:  {
					type:"integer",
					desc:"The entity only exists on a single client which is determined by the user_id property.",
				},
				LOCALE_SERVER_ONLY:  {
					type:"integer",
					desc:"The entity will only exist server-side.",
				},
				LOCALE_DB:  {
					type:"integer",
					desc:"The entity will be stored in the database.",
				},
				LOCALE_DEFAULT:  {
					type:"integer",
					desc:"The entity will use the engine default locale setting configured in IgeConstants.js.",
				},
			},
		},
		entity_net_mode: {
			type:"integer",
			desc:"Determines how the engine propagates changes to the entity over the network.",
			valueOf: {
				NET_MODE_FIXED_MOTION:  {
					type:"integer",
					desc:"The entity only moves along designated paths created with the path-finder and that movement is not propagated in realtime because it can be calculated by simple maths instead.",
				},
				NET_MODE_FREE_MOTION:  {
					type:"integer",
					desc:"The entity can be moved arbitrarily via the moveToTile and moveToActual methods and that movement should be propagated in realtime.",
				},
			},
		},
		entity_base_draw: {
			type:"array",
			desc:"If set, will tell the renderer to either stroke or fill the tiles currently being occupied by this entity. The array is in the format [0] = integer, either 0 (stroke) or 1 (fill), [1] = The colour to stroke or fill with.",
		},
		entity_transform: {
			type:"object",
			desc:"The initial transform definition.",
			link:"transformData",
		},
		map_block: {
			type:"integer",
			desc:"Used to tell the engine how this entity interacts with other entities on the tile map. If an entity blocks, it will not allow any entities that use checking to be created on the same tiles as the blocking entity occupies. If an entity checks, before it is created it will check the tile map to see if a blocking entity already occupies one or more of the tiles that the checking entity wants to take up.",
			valueOf: {
				MAP_NOBLOCK_NOCHECK: {
					type:"integer",
					desc:"The entity will not block other entities, will not check for other entities blocking it.",
				},
				MAP_NOBLOCK_CHECK: {
					type:"integer",
					desc:"The entity will not block other entities, will check for other entities blocking it.",
				},
				MAP_BLOCK_NOCHECK: {
					type:"integer",
					desc:"The entity will block other entities, will not check for other entities blocking it.",
				},
				MAP_BLOCK_CHECK: {
					type:"integer",
					desc:"The entity will block other entities, will check for other entities blocking it.",
				},
			},
		},
		asset_id: {
			type:"string",
			desc:"The id of the asset to use when rendering this entity to the screen.",
		},
		animation_id: {
			type:"string",
			desc:"The id of the animation to apply to the entity whilst it is being rendered.",
		},
		animation_dirty: {
			type:"bool",
			desc:"Defaults to true if not specified. When true, causes the entity to be set to dirty (to be redrawn) each time the entity's asset_sheet_frame is updated by the entity animation system.",
		},
		path_class: {
			type:"array",
			desc:"Only set on tile entities. An array of string names that denote the types of paths that can use this tile. This allows you to control which tiles paths can route through.",
		},
		map_id: {
			type:"string",
			desc:"The id of the map that this entity will exist on.",
		},
		template_id: {
			type:"string",
			desc:"The id of the template from which to derive the bulk of the entity's properties from.",
		},
		user_id: {
			type:"string",
			desc:"The id of the user that 'owns' this entity.",
		},
	}
} **/

/** transformData - The properties that can be used in a transform object. {
	category:"definition",
	contents:{
		translate:{
			type:"array",
			desc:"The values that define the item position.",
			link:"translateData",
		},
		scale:{
			type:"array",
			desc:"The values that define the item scale.",
			link:"scaleData",
		},
		scaleToTarget:{
			type:"array",
			desc:"The values that define the item scale by specifying target pixel values rather than scale ratios.",
			link:"scaleToTargetData",
		},
		rotate:{
			type:"array",
			desc:"The values that define the item rotation.",
			link:"rotateData",
		},
		origin:{
			type:"array",
			desc:"The values that define the item origin point.",
			link:"originData",
		},
		opacity:{
			type:"array",
			desc:"The values that define the item opacity.",
			link:"opacityData",
		},
	},
	examples:[{
		name:"Entity Transform Data",
		desc:"An example entity with transform data.",
		code:"<pre>
			// Create a new engine instance
			this.ige.create({
				entity_id:'testEntity',
				entity_transform: {
					translate:[0, 0, 0, false, true],
				},
			});
		</pre>",
	}],
} **/

/** translateData - The array of values that can be used in a translate array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		relative:{
			type:"bool",
			desc:"Array index 3. When set to true, will sum the current position values with the new ones.",
		},
		tileBased:{
			type:"bool",
			desc:"Array index 4. When set to true, will take the co-ordinate values as tile co-ordinates and convert them to world co-ordinates based upon the current tile-map tile size data.",
		},
	}
} **/

/** scaleData - The array of values that can be used in a scale array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		tileBased:{
			type:"bool",
			desc:"Array index 3. When set to true, will take the co-ordinate values as tile co-ordinates and convert them to world co-ordinates based upon the current tile-map tile size data.",
		},
		relative:{
			type:"bool",
			desc:"Array index 4. When set to true, will sum the current position values with the new ones.",
		},
	}
} **/

/** scaleToTargetData - The array of values that can be used in a scaleToTarget array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		tileBased:{
			type:"bool",
			desc:"Array index 3. When set to true, will take the co-ordinate values as tile co-ordinates and convert them to world co-ordinates based upon the current tile-map tile size data.",
		},
	}
} **/

/** rotateData - The array of values that can be used in a rotation array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		relative:{
			type:"bool",
			desc:"Array index 3. When set to true, will sum the current position values with the new ones.",
		},
	}
} **/

/** originData - The array of values that can be used in an origin array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		relative:{
			type:"bool",
			desc:"Array index 3. When set to true, will sum the current position values with the new ones.",
		},
	}
} **/

/** opacityData - The array of values that can be used in an opacity array. {
	category:"definition",
	contents:{
		x:{
			type:"float",
			desc:"Array index 0. The x co-ordinate.",
		},
		y:{
			type:"float",
			desc:"Array index 1. The y co-ordinate.",
		},
		z:{
			type:"float",
			desc:"Array index 2. The z co-ordinate.",
		},
		relative:{
			type:"bool",
			desc:"Array index 3. When set to true, will sum the current position values with the new ones.",
		},
	}
} **/

/** createDeferred - Fired when the create method defers creation of an entity
because it's designated asset has not yet become ready. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** deferCreated - Fired when an entity who's creation was deferred during the
create() method is finally created. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** beforeCreate - Fired before an entity is created. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
	control:"This event can cancel subsequent code if the receiving method returns true.",
} **/
/** afterCreate - Fired after an entity is created. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** beforeUpdate - Fired before updating any data in an entity using the
update() method. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** afterUpdate - Fired after updating any data in an entity using the update()
method. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** beforeMove - Fired before moving an entity. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** afterMove - Fired after moving an entity. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** directionChange - Fired when an entity's direction is changed. {
	category: "event",
	arguments: [{
		type:"object",
		name:"entity",
		desc:"The entity that the event is being fired for.",
		link:"entityData",
	}],
} **/
/** receiveDelta - Fired after a delta update has been received from the server. {
	category: "event",
	engine_ver:"0.2.2",
	flags:"client",
	arguments: [{
		type:"object",
		name:"data",
		desc:"The data that the server has sent over.",
	}],
} **/
IgeEntities = new IgeClass({
	
	Extends: [IgeCollection, IgeNetworkItem, IgeItem, IgeEvents, IgeTransform, IgeTween, IgeUi],
	
	/** engine -  A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** viewports - A reference to this.engine.viewports for fast access. {
		category:"property",
		type:"object",
		instanceOf:"IgeViewports",
	} **/
	viewports: null,
	
	/** viewportsByMapId - A reference to this.engine.viewports.byMapId for fast access. {
		category:"property",
		type:"object",
	} **/	
	viewportsByMapId: null,
	
	/** mapsById - A reference to this.engine.maps.byId for fast access. {
		category:"property",
		type:"object",
	} **/	
	mapsById: null,
	
	/** assetsById - A reference to this.engine.assets.byId for fast access. {
		category:"property",
		type:"object",
	} **/
	assetsById: null,
	
	/** assetImageById - A reference to this.engine.assets.assetImage for fast access. {
		category:"property",
		type:"object",
	} **/
	assetImageById: null,
	
	/** camerasById - A reference to this.engine.cameras.byId for fast access. {
		category:"property",
		type:"object",
	} **/
	camerasById: null,
	
	/** renderer - A reference to this.engine.renderer for fast access. {
		category:"property",
		type:"object",
		instanceOf:"IgeRenderer",
	} **/	
	renderer: null,
	
	/** deferList - The events controller for this class. {
		category:"property",
		type:"array",
		instanceOf:"IgeEvents",
	} **/
	deferList: [],
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: [],
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: [],
	
	/** byMapId - A multi-dimensional array with a string index that allows you to
	access every item created using the create method grouped by the map_id property
	value. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byMapId: [],
	
	/** byMapIdAndLayer - A multi-dimensional array with a string index that allows
	you to access every	item created using the create method grouped by the map_id, then
	the entity_layer property values. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byMapIdAndLayer: [],
	
	/** byAnimate - An array with a string index that allows you to access every item created
	using the create method that has animation data. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byAnimate: [],
	
	/** byPath - An array with a string index that allows you to access every item created
	using the create method that has path data. {
		category:"property",
		type:"array",
		index:"integer",
	} **/	
	byPath: [],
	
	/** tileMapCache - A multi-dimensional array that holds data about the tile map for internal
	use with path finding. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	tileMapCache: [],
	
	/** firstTime - Is true if this is the first time that the class has created an entity during
	this session. {
		category:"property",
		type:"bool",
	} **/
	firstTime: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeEntities';
		this.collectionId = 'entity';
		
		this.ige = engine; // Post 1.0.0 engine reference
		this.engine = engine; // Legacy engine reference
		
		this.byIndex = [];
		this.byId = [];
		this.byMapId = [];
		this.byMapIdAndLayer = [];
		this.byCords = [];
		this.byAnimate = [];
		this.byPath = [];
		this.tileMapCache = [];
		this.firstTime = true;
		
		// Process the entity defer list when a new asset is created
		this.engine.assets.on('assetLoaded', this.bind(this._processDeferList), this);
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}
		
		// Register the tweening processor method as a pre-world-tick method
		this.ige.preWorldTick(this.bind(this.tweenProcess), 'both'); // both = client and server
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('entitysCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand('entitysRead', this.bind(this.read));
		this.engine.network.registerCommand('entitysUpdate', this.bind(this.receiveUpdate));
		this.engine.network.registerCommand('entitysRemove', this.bind(this.receiveRemove));
		
		// Register default entity network properties - the properties that are automatically updated to 
		// clients if they change in an entity's data
		this.engine.network.registerNetProps(this._className, [
			'entity_id',
			'entity_opacity',
			// New entity data for stream / interpolation
			'_wx',
			'_wy',
			'_wz',
			'_wa',
			// Asset data
			'asset_id',
			'asset_sheet_frame',
			// Animation data
			'animation_id',
		]);
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'entity_id',
			'entity_bounds',
			'entity_net_mode',
			'entity_moved',
			'entity_layer',
			'entity_locale',
			'entity_type',
			'entity_persist',
			'entity_db_id',
			'entity_opacity',
			'map_block',
			// New entity data for stream / interpolation
			'_wx',
			'_wy',
			'_wz',
			'_wa',
			// Session data
			'session_id',
		]);
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends
	when creating a new item. Here you can define any object properties that
	are default across all items of this class. If this method returns false
	the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureLocalExists(pItem);
		/* CEXCLUDE */
		if (this.engine.isServer) { this.ensurePersistExists(pItem); }
		/* CEXCLUDE */
		this.ensureIdExists(pItem);
		
		// Ensure the entity has an asset_sheet_frame (default to 1)
		pItem.asset_sheet_frame = pItem.asset_sheet_frame || 1;
		
		// Set the new _targetData variable for entity interpolation
		if (!this.engine.isServer) { pItem._targetData = []; }
		
		// Set the map
		if (pItem.map_id) {
			pItem.$local.$map = this.engine.maps.byId[pItem.map_id];
		}
		
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends
	when creating a new item. Checks the integrity of an item before it is
	allowed to be created. Here you can define custom checks to ensure an item
	being created conforms to the standard your class requires. If this method
	returns false the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		// Check that this entity does not already exist
		if (this.byId[pItem.entity_id]) {
			this.log('Attempted to create an entity that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		
		// Check the entity has a layer defined
		if (typeof(pItem.entity_layer) == 'undefined') {
			this.log('Attempted to create an entity without an entity_layer property!', 'warning', pItem, true);
			return false;
		}
		
		// Check the entity has a map_id defined
		if (typeof(pItem.map_id) == 'undefined') {
			this.log('Attempted to create an entity without a map_id property!', 'warning', pItem, true);
			return false;
		} else {
			// A map_id property exists, check if the map exists with this id
			if (!this.engine.maps.byId[pItem.map_id]) {
				this.log('Attempted to create an entity on a map that does not exist with map_id: ' + pItem.map_id, 'warning', pItem, true);
				return false;
			}
		}
		
		// Check the entity has been assigned transform data correctly
		/*if (typeof(pItem._transform) == 'undefined') {
			this.log('Attempted to create an entity without any _transform object data. Did you supply an entity_transform object property in the entity definition?', 'warning', pItem, true);
			return false;
		}*/
		
		// Check that the asset that this entity uses actually exists!
		if (!this.engine.assets.byId[pItem.asset_id]) {
			this.log('Cannot create entity because the asset it is trying to use does not exist: ' + pItem.asset_id, 'warning', pItem);
			return false;
		}
		
		if (typeof(pItem.entity_tile_block) != 'undefined') {
			this.log('The entity property "entity_tile_block" is depreciated and will be removed in a future version of the engine. Please use the "map_block" property instead. Check the IgeConstants.js file for new constant names starting with MAP_BLOCK and MAP_NOBLOCK.', 'depreciated', pItem);
			this.log('Entity blocking is also no longer based upon the "entity_tile_width" and "entity_tile_height" properties (because they are also depreciated in favour of the new IgeTransform system) and instead uses the new "map_tile_width" and "map_tile_height" properties to determine which tiles to block when placing or moving an entity that has map_block enabled.', 'depreciated', null, true);
			
			// Legacy properties are being used, convert them to the new ones
			pItem.map_block = pItem.entity_tile_block;
			delete pItem.entity_tile_block;
		}
		
		// Is the defer list empty and the entity's asset loaded?
		if (this.deferList.length || !this.engine.assets.assetReady(pItem.asset_id)) {
			// Either the defer list is not empty or the asset is not ready so add the entity to the defer list
			this.deferList.push(pItem);
			this.emit('createDeferred', pItem);
			return false;
		}
		
		// No integrity checks failed so return true to continue processing this item
		return true;
	},
	
	/** _processDeferList - Processes the entities stored in the deferList array and if the
	assets that an entity in the list uses are now available, the entity is created and removed
	from the deferList array. {
		category:"method",
	} **/
	_processDeferList: function () {
		
		if (!this.deferListProcessing) {
			
			this.deferListProcessing = true;
			
			while (this.deferList.length) {
				var entity = this.deferList[0];
				
				if (!this.engine.assets.assetReady(entity.asset_id)) {
					break;
				} else {
					this._propagate(entity, PROPAGATE_CREATE);
					this.deferList.splice(0, 1);
					
					this.emit('deferCreated', entity);
				}
			}
			
			this.deferListProcessing = false;
			
			if (this.deferListFollowUp) {
				//this.log('Defer list processed but follow-up flag set so processing again!');
				this.deferListFollowUp = false;
				this._processDeferList();
			}
			
		} else {
			//this.log('Already processing defer list so setting follow-up flag.');
			this.deferListFollowUp = true;
		}
		
	},
	
	/** _create - The private method that is called by 'this.create' and does the actual creation part. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or null for any other reason.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity object to be created.",
			link:"entityData",
		}],
	} **/
	_create: function (entity) {
		// Delay the definition of some references until they are available in the engine
		if (this.firstTime) {
			// Define some references to speed up access
			this.viewports = this.engine.viewports;
			this.viewportsByMapId = this.engine.viewports.byMapId;
			this.mapsById = this.engine.maps.byId;
			this.assetsById = this.engine.assets.byId;
			this.assetImageById = this.engine.assets.assetImage;
			this.camerasById = this.engine.cameras.byId;
			this.renderer = this.engine.renderer;
			
			// Init the UI system that was extended in the Extends for this class
			this.uiInit();
			
			// Set the firstTime flag to false so we don't execute this stuff again
			this.firstTime = false;
		}
					
		// Set the asset references
		this.setAsset(entity, entity.asset_id);
		
		// Set the size of the entity - called even if the entity does not use sprite sheets
		this.setSheetFrame(entity, entity.asset_sheet_frame);
		
		// Apply the transformation data to the entity
		this.applyTransform(entity);
		//this.bounds(entity, true); // This is called in _afterTranslate() anyway below
		
		// Call the _afterTranslate method because if the server
		// originaly created this entity then it will not have
		// a _afterTranslate call after the transform is applied
		// because the transform data will match so no transform
		// will be applied
		this._afterTranslate(entity);
		this._afterScale(entity);
		
		// Now if we are not the server, check entity bounds
		var stillCreate = true;
		if (!this.engine.isServer) {
			// Check that the entity is within the bounds of a viewport (or culling is disabled)
			if (!entity.entity_disable_cull && this.isOutOfBounds(entity)) {
				stillCreate = false;
			}
		}
		
		if (stillCreate) {
			// Add the entity to the dirty rect system's cache
			var map = entity.$local.$map;
			
			if (map.map_use_dirty) {
				//this.engine.dirtyRects.addEntityToCache(entity, map);
			}
			
			// Mark the entity as dirty so it gets redrawn after being created
			if (!this.engine.isServer) { this.markDirty(entity); }
			
			// Check if this entity blocks the tile map
			this.blockTiles(entity);
			
			// Add the entity to the engine
			this.byIndex.push(entity);
			this.byId[entity.entity_id] = entity;
			this.byMapId[entity.map_id] = this.byMapId[entity.map_id] || [];
			this.byMapId[entity.map_id].push(entity);
			this.byMapIdAndLayer[entity.map_id] = this.byMapIdAndLayer[entity.map_id] || [];
			this.byMapIdAndLayer[entity.map_id][entity.entity_layer] = this.byMapIdAndLayer[entity.map_id][entity.entity_layer] || [];
			this.byMapIdAndLayer[entity.map_id][entity.entity_layer].push(entity);
			
			// If this entity has animation, add it to the animation list
			if (entity.animation_id) {
				// Set the entity animation
				this.setAnimation(entity, entity.animation_id);
				if (typeof(entity.animation_dirty) == 'undefined') { entity.animation_dirty = true; }
				
				// Add the entity to the animation array
				this.byAnimate.push(entity);
			}
			
			this.addToTileMap(entity);
			
			// If the entity has path data, ensure that the pathing system knows this!
			if (entity.path != null) { this.engine.paths.resumePath(entity, PATH_TYPE_ENTITY); }
			
			// If the entity exists on an HTML-based layer, create an element for it
			if (!this.engine.isServer && map.map_layers[entity.entity_layer].layer_type == LAYER_TYPE_HTML) {
				// This array holds the entity's elements for each viewport it exists on
				// and is filled when the renderer creates the element for the first time.
				// On subsequent render ticks, the existing element is modified rather than
				// creating and destroying a whole document fragment each time.
				// We don't create the element here because we don't know which viewports
				// the element should exist on at the moment, but the renderer does so
				// we leave it up to the renderer to do it's work.
				entity.$local.$el = [];
				entity.$local.$elStyle = [];
			}
			
			// If the entity has UI data and the ui system has been enabled, pass it to uiCreate()
			if (entity.ui && typeof(this.uiCreate) == 'function') {
				this.uiCreate(entity);
			}
			
			// 1.0.0 dirty-rect system, add to dirty rect
			if (!this.ige.isServer && map.map_use_dirty2) {
				this.engine.dirtyRects.storeRect(map, entity.entity_layer, this.bounds(entity));
			}
			
			// Check for a callback function embedded in the entity
			if (typeof(entity.$local.create_callback) == 'function') {
				entity.$local.create_callback.apply(this, [entity]);
				delete entity.$local.create_callback;
			}
			
			this.emit('afterCreate', entity);
			
			return entity;
		} else {
			this.log('Cannot create entity because the bounds-check failed.', 'warning', entity);
			
			// Check for a callback function embedded in the entity
			if (typeof(entity.$local.create_callback) == 'function') {
				entity.$local.create_callback.apply(this);
				delete entity.$local.create_callback;
			}
			
			return false;
		}
	},
	
	/** _update - Updates the class collection item with the matching id specified in the updData
	parameter with all properties of the pData parameter. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (tpItem, pData) {
		// Grab the current item object
		var pItem = this.read(tpItem);

		if (pItem != null) {
			// Emit the beforeUpdate event and halt if any listener returns the cancel flag
			if (!this.emit('beforeUpdate', pItem)) {
				// Update the current object with the new object's properties
				for (var i in pData) {
					pItem[i] = pData[i];
				}
			}
		} else {
			this.log('Cannot update item because it could not be located by calling this.read().', 'error', pItem);
			return false;
		}
	},
	
	/** _remove - Private method that removes the entity identified by the passed
	id from the engine. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The entity object to be removed.",
			link:"entityData",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (typeof(pItem) != 'undefined') {
			// Check if the pItem has a callback method and if so, save a reference to it, then fire after removal of the pItem
			var cbMethod = null;
			if (typeof pItem.$local.remove_callback == 'function') {
				cbMethod = pItem.$local.remove_callback;
			}
			
			// Remove it from all the arrays
				// TO-DO - Don't like this implementation - should store the index at create
				// and avoid these costly lookups! - But memory is important too... oh the woe.
			var arr1 = this.byMapIdAndLayer[pItem.map_id][pItem.entity_layer];
			var arr2 = this.byMapId[pItem.map_id];
			var arr5 = this.byIndex;
			
			// Mark the position of the entity as dirty
			this.markDirty(pItem);
			
			// Remove the entity from the dirty rect cache
			if (pItem.$local.$map.map_use_dirty) { this.engine.dirtyRects.removeEntityFromCache(pItem); }
			
			// Remove the entity from the tile map cache
			this.removeFromTileMap(pItem);
			this.unBlockTiles(pItem);
			
			// If this entity has a path, remove it from the processing list
			this.engine.paths.stopPath(pItem, PATH_TYPE_ENTITY);
			
			// Remove the entity from all the lookup arrays
			delete this.byId[pItem[this.collectionId + '_id']];
			var arr1Index = arr1.indexOf(pItem);
			var arr2Index = arr2.indexOf(pItem);
			var arr5Index = arr5.indexOf(pItem);
			arr1.splice(arr1Index, 1);
			arr2.splice(arr2Index, 1);
			arr5.splice(arr5Index, 1);
			
			// If the entity is animated, remove it from the animation lookup array
			if (pItem.animation_id) {
				var arr3 = this.byAnimate;
				var arr3Index = arr3.indexOf(pItem);
				arr3.splice(arr3Index, 1);
			}
			
			// Check if the entity had any HTML elements attached to it and remove them
			if (typeof(pItem.$local.$el) != 'undefined') {
				var elArr = pItem.$local.$el;
				for (var i in elArr) {
					elArr[i].remove();
				}
			}
			
			if (typeof(cbMethod) == 'function') {
				cbMethod.apply(this);
			}
			
			return true;
			
		} else {
			this.log('Cannot remove entity because it does not exist!', 'warning', pItem);
			return false;
		}
		
	},
	
	/** getEntity - DEPRECIATED Takes either an entity object or an entity id and returns an
	entity object. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns an entity or false on failure.",
		},
		arguments: [{
			type:"multi",
			name:"entity",
			desc:"Either a string or an object containing a string property 'entity_id' that identifies the entity to be returned.",
			link:"entityData",
		}],
	} **/
	getEntity: function (entity) {
		this.log('IgeEntities.getEntity is depreciated, please use IgeEntities.read instead.', 'warning');
		return this.read(entity);
	},
	
	/** show - Sets an entity to visible so it will not be ignored by the renderer. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"multi",
			name:"entity",
			desc:"Either a string or an object containing a string property 'entity_id' that identifies the entity to be used.",
			link:"entityData",
		}],
	} **/
	show: function (pItem) {
		pItem = this.read(pItem);
		if (pItem) {
			pItem.entity_hide = false;
		}
	},
	
	/** hide - Sets an entity to hidden so it will be ignored by the renderer. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"multi",
			name:"entity",
			desc:"Either a string or an object containing a string property 'entity_id' that identifies the entity to be used.",
			link:"entityData",
		}],
	} **/
	hide: function (pItem) {
		pItem = this.read(pItem);
		if (pItem) {
			pItem.entity_hide = true;
		}
	},
	
	/** addToTileMap - Adds an entity to the tile map cache (internal use). {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to add to the tile map cache.",
			link:"entityData",
		}],
	} **/
	addToTileMap: function (entity) {
		// Init the type and cords lookup array
		var map = entity.$local.$map;
		this.tileMapCache[map.map_id] = this.tileMapCache[map.map_id] || [];
		this.tileMapCache[map.map_id][entity.entity_type] = this.tileMapCache[map.map_id][entity.entity_type] || [];
		this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x] = this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x] || [];
		
		// Now some special checks if this entity is a tile
		if (entity.entity_type == ENTITY_TYPE_TILE) {
			// Because we are a tile, only one of us can exist on the tile position, so
			// check if a tile already exists at these co-ordinates
			if (this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y]) {
				// Tile already exists so remove it
				this.log('Removing existing entity at map position ' + entity.entity_tile_x + ', ' + entity.entity_tile_y, 'info', this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y]);
				this.remove(this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y].entity_id);
			}
			
			// Add the tile to the cords
			this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y] = entity;
		} else {
			// Add the new entity to the type-co-ordinate lookup array
			this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y] = this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y] || [];
			this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y].push(entity);
		}	
	},
	
	/** removeFromTileMap - Removes an entity from the tile map cache (internal use). {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to remove from the tile map cache.",
			link:"entityData",
		}],
	} **/	
	removeFromTileMap: function (entity) {
		// This could either be an array of objects or a single object so check!
		var map = entity.$local.$map;
		if (this.tileMapCache[map.map_id] != null && this.tileMapCache[map.map_id][entity.entity_type] != null && this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x]  != null && this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y]) {
			var arr = this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y];
			
			if (arr instanceof Array) {
				var arrIndex = arr.indexOf(entity);
				if (arrIndex > -1) {
					arr.splice(arrIndex, 1);
				}
			} else {
				delete this.tileMapCache[map.map_id][entity.entity_type][entity.entity_tile_x][entity.entity_tile_y];
			}
		}
	},
	
	/** tileOnMapHasClass - Checks if a tile at the given co-ordinates has a particular class assigned to it. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns true if the tile position has the specified class or false if not.",
		},
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to check against.",
		}, {
			type:"integer",
			name:"entityType",
			desc:"The type of entity that we want to check.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the map tile to check.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the map tile to check.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the map tile to check.",
		}, {
			type:"string",
			name:"className",
			desc:"The class name to test the tile against.",
		}],
	} **/	
	tileOnMapHasClass: function (mapId, entityType, x, y, z, className) {
		if (this.tileMapCache[mapId] && 
			this.tileMapCache[mapId][entityType] && 
			this.tileMapCache[mapId][entityType][x] && 
			this.tileMapCache[mapId][entityType][x][y] &&
			this.tileMapCache[mapId][entityType][x][y][z]) {
			var pointEntList = this.tileMapCache[mapId][entityType][x][y][z];
			var entCount = pointEntList.length;
			while (entCount--) {
				var entity = pointEntList[entCount];
				if (entity.path_class) {
					if (entity.path_class.indexOf(className)) {
						return true;
					}
				}
			}
		}
		
		return false;
	},
	
	/** directionFromMove - Determines the direction of movement between two points. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"integer",
			desc:"Returns a direction represented as an integer that maps to a direction constant. The direction of movement is calculated from the x1 and y1 co-ordinates towards the x2 and y2 co-ordinates.",
		},
		arguments: [{
			type:"integer",
			name:"x1",
			desc:"The x co-ordinate of the starting position.",
		}, {
			type:"integer",
			name:"y1",
			desc:"The y co-ordinate of the starting position.",
		}, {
			type:"integer",
			name:"x2",
			desc:"The x co-ordinate of the new position.",
		}, {
			type:"integer",
			name:"y2",
			desc:"The y co-ordinate of the new position.",
		}, {
			type:"object",
			name:"map",
			desc:"The map to use when determining direction values (2d and iso maps are calculated differently).",
			link:"mapData",
		}],
	} **/
	directionFromMove: function (x1, y1, z1, x2, y2, z2, map, layerIndex) {
		// TO-DO - Is this method still valid now we are using IgeTransform?
		var finalDirection = DIRECTION_NONE;
		var mapLayers = map.map_layers;
		
		// The movement direction changes if the map is in 2d or iso because the co-ordinates
		// are always in 2d but movement in isometric is rotated, so we need to rotate into iso
		// if in iso mode by adjusting the final values here.
		if (mapLayers[layerIndex].layer_render_mode == RENDER_MODE_2D) {
			// 2D calculations
			if (x2 > x1) { finalDirection += DIRECTION_E; }
			if (x2 < x1) { finalDirection += DIRECTION_W; }
			if (y2 < y1) { finalDirection += DIRECTION_N; }
			if (y2 > y1) { finalDirection += DIRECTION_S; }
		}
		
		if (mapLayers[layerIndex].layer_render_mode == RENDER_MODE_ISOMETRIC) {
			// Iso calculations
			if (x2 > x1 && y2 == y1) { finalDirection = DIRECTION_SE; }
			if (x2 < x1 && y2 == y1) { finalDirection = DIRECTION_NW; }
			if (y2 < y1 && x2 == x1) { finalDirection = DIRECTION_NE; }
			if (y2 > y1 && x2 == x1) { finalDirection = DIRECTION_SW; }
			
			if (x2 < x1 && y2 < y1) { finalDirection = DIRECTION_N; }
			if (x2 > x1 && y2 < y1) { finalDirection = DIRECTION_E; }
			if (x2 > x1 && y2 > y1) { finalDirection = DIRECTION_S; }
			if (x2 < x1 && y2 > y1) { finalDirection = DIRECTION_W; }
		}
		
		return finalDirection;
	},
	
	/** entityBoundsByView - Get the bounds of an entity. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"integer",
			desc:"Returns an array with the co-ordinates of the entity bounds in screen view cords.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to evaluate the bounds data from.",
			link:"entityData",
		}, {
			type:"object",
			name:"viewport",
			desc:"The viewport that the entity's bounds are calculated with (different viewports can have different bounds data because of panning and scaling).",
			link:"viewportData",
		}],
	} **/
	entityBoundsByView: function (entity, viewport) {
		// TO-DO - Still valid in 1.0.0?
		var dims = this.getDimensions(entity, viewport);
		return [dims.destinationX, dims.destinationY, dims.entityWidth, dims.entityHeight];
	},
	
	/** markDirty - Take an entity and make a dirty rect on the map from its dimensions. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to evaluate the bounds data from in order to mark dirty rectangles.",
			link:"entityData",
		}],
	} **/
	markDirty: function (entity) {
		// TO-DO - Still valid in 1.0.0?
		return;
		if (entity != null) {
			if (entity.map_id) {
				
				var map = entity.$local.$map;
				entity.$local.$entity_dirty = true;
				
				if (map.map_use_dirty) {
					
					// Map uses dirty rectangle system so mark dirty rects this entity intersects
					var entSize = this.getSize(entity);
					var entPos = this.getPosition(entity);
					
					var renderMode = map.map_render_mode;
					
					this.engine.dirtyRects.markDirtyByRect(map, [entPos[renderMode][0], entPos[renderMode][1], entSize[2], entSize[3]], entity.entity_layer);
					
				} else {
					
					// Map is set not to use dirty rectangle system so mark whole viewport as dirty
					// Get the list of viewports looking at the map that the entity exists on
					var vpList = this.engine.viewports.byMapId[entity.map_id];
					
					// If we have a list of viewports
					if (vpList != null) {
						
						// Loop through each viewport and add a dirty rect for this entity to it
						for (var vpI in vpList) {
							vpList[vpI].$local.$viewport_dirty = true;
							if (!this.engine.isSlave) { vpList[vpI].drawLayers[entity.entity_layer].$local.$layer_dirty = true; }
						}
						
					}
					
				}
				
			} else {
				this.log('No map_id property found in the entity passed.', 'error', entity);
			}
		} else {
			this.log('No entity passed.', 'warning', entity);
		}
		
	},
	
	/** markDirtyByAssetId - Takes an assetId and marks all entities that use the asset
	as dirty to force them to redraw. *** Not performance optimised, for debug only. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"string",
			name:"assetId",
			desc:"The id of the asset used to mark all entities using the asset as dirty.",
		}],
	} **/
	markDirtyByAssetId: function (assetId) {
		for (var i = 0; i < this.byIndex.length; i++) {
			var entity = this.byIndex[i];
			if (entity.asset_id == assetId) {
				delete entity.$local.$size;
				this.markDirty(entity);
			}
		}
	},
	
	/** detectTileIntersect - Detects the tile that an entity intersects. {
		category:"method",
		engine_ver:"0.3.0",
		return: {
			type:"integer",
			desc:"Returns an array with two entries [0] = x co-ordinate of the tile intersected, [1] = y co-ordinate of the tile intersected.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to use when calculating which tile is being intersected.",
			link:"entityData",
		}, {
			type:"object",
			name:"viewport",
			desc:"The viewport to use when calculating tile intersection.",
			link:"viewportData",
		}],
	} **/
	detectTileIntersect: function (entity, viewport) {
		// TO-DO - Still valid in 1.0.0?
		if (entity.entity_actual_x != null && entity.entity_actual_y != null) {
			// Get the entity's asset
			var asset = this.engine.assets.byId[entity.asset_id]
			
			// Store the x and y of the entity
			var x = entity.entity_actual_x;
			var y = entity.entity_actual_y;
			
			// Check if the asset is sheet-based or a single image
			if (asset.asset_sheet_enabled && entity.asset_sheet_frame != null) {
				// Sheet-based asset so get the sheet source position
				var assetAnchorPoint = asset.asset_anchor_points[entity.asset_sheet_frame];
			} else {
				// Single image so use source as whole image
				var assetAnchorPoint = asset.asset_anchor_points[0];
			}
			
			// Add the asset anchor point to the entity x and y
			x += assetAnchorPoint[0];
			y += assetAnchorPoint[1];
			
			return [];
		} else {
			return false;
		}
	},
	
	/** setAnimation - Sets the animation currently being used when rendering the entity. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"integer",
			desc:"Returns true if successful or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to use when changing the animation.",
			link:"entityData",
		}, {
			type:"string",
			name:"animationId",
			desc:"The id of the animation to apply to the entity.",
		}],
	} **/
	setAnimation: function (entity, animationId, resetFrameIndex) {
		curEntity = this.read(entity);
		
		if (curEntity) {
			if (curEntity.entity_id) {
				if (curEntity.$local) {
					var animation = this.engine.animations.byId[animationId];
					
					if (animation != null) {
						if (resetFrameIndex) { curEntity.asset_sheet_frame = 1; }
						curEntity.$local.$animation = animation;
						
						/* CEXCLUDE */
						// If the entity's net_mode tells us to update clients about every change, 
						// update the diffStore so this change will be propagated to the network on next tick.
						// Do this BEFORE updating the entity so that a comparison between the current object
						// and the new values can determine if an update packet is required.
						if (this.engine.isServer && curEntity.entity_net_mode == NET_MODE_FREE_MOTION) {
							this.updateDifferenceStore({
								entity_id: curEntity.entity_id,
								animation_id: animationId,
							});
						}
						/* CEXCLUDE */
						
						curEntity.animation_id = animationId;
						
						if (animation.animation_fps) {
							//curEntity.$local.$animation_unit = Math.floor(animation.$local.$fpsTime * animation.$local.$frameTime);
							//this.log('Animation set successfully for entity ' + entity.entity_id);
							curEntity.$local.$animation_time = 0;
							return true;
						} else {
							// Animation error
							this.log('Trying to set animation "' + curEntity.animation_id + '" for entity but animation does not have an FPS setting (animation_fps)!', 'error', animation);
							return false;
						}
					} else {
						// Animation error
						this.log('Trying to set animation "' + animationId + '" for entity but animation does not exist in engine!', 'error');
						return false;
					}
				} else {
					this.log('Trying to set animation "' + animationId + '" for entity but entity does not contain a $local property!', 'error', entity);
				}
			} else {
				this.log('Trying to set animation "' + animationId + '" for entity but entity does not contain an entity_id property!', 'error', entity);
			}
		} else {
			//this.log('Trying to set animation "' + animationId + '" for entity but entity is null!', 'error', entity);
		}
	},
	
	/** setAsset - Sets the asset to be used when rendering the entity. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"integer",
			desc:"Returns true if successful or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to use when changing the asset.",
			link:"entityData",
		}, {
			type:"string",
			name:"assetId",
			desc:"The id of the asset to apply to the entity.",
		}],
	} **/
	setAsset: function (entity, assetId) {
		if (entity && entity.$local) {
			// Check that the asset that this entity uses actually exists!
			if (this.engine.assets.byId[assetId]) {
				var previousAsset = false;
				
				if (entity.$local != null && entity.$local.$asset) {
					var map = entity.$local.$map;
					
					this.removeFromTileMap(entity);
					this.unBlockTiles(entity);
					if (map.map_use_dirty) { this.engine.dirtyRects.removeEntityFromCache(entity); }
					
					if (!this.engine.isServer) { this.markDirty(entity); }
					
					previousAsset = true;
				}
				
				entity.asset_id = assetId;
				entity.$local.$asset = this.engine.assets.byId[entity.asset_id];
				entity.$local.$assetImage = this.engine.assets.assetImage[entity.asset_id];
				entity.$local.$originalSize = entity.$local.$asset.$local.$size; // Store the w/h of the asset
				
				entity.$local.$entity_dirty = true;
				
				// Update the pre-calc sheet data - called even if the entity does not use sprite sheets
				entity.asset_sheet_frame = entity.asset_sheet_frame || 1;
				this.setSheetFrame(entity, entity.asset_sheet_frame);
				
				// Now call the getSize and getPosition methods which will update the data cached for this entity
				// because we set it as dirty above first which forces a re-calc of the cached data
				//this.getSize(entity);
				//this.getPosition(entity);
				
				if (previousAsset) {
					this.addToTileMap(entity);
					this.blockTiles(entity);
					if (map.map_use_dirty) { this.engine.dirtyRects.addEntityToCache(entity); }
					if (!this.engine.isServer) { this.markDirty(entity); }
				}
				
				return true;
			} else {
				this.log('setAsset: Cannot set entity asset because the asset specified does not exist: ' + assetId, 'warning', entity);
				return false;
			}
		} else {
			this.log('Cannot set asset for entity because it does not have a $local!', 'error', entity);
			return false;
		}
	},
	
	/** processAnimation - Updates all entities with an active animation to the next frame
	based upon the delta timestep. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"integer",
			name:"delta",
			desc:"The delta timestep to use when calculating entity animation frames.",
			link:"entityData",
		}],
	} **/
	processAnimation: function  (delta) {
		if (!isNaN(delta)) {
			var arr = this.byAnimate;
			var count = arr.length;
			
			while (count--) {
				this.engine.animations.animateByDelta(arr[count], delta);
			}
		} else {
			this.log('Animation delta is NaN!', 'error', delta);
		}
	},
	
	/** setSheetFrame - Sets the sprite sheet frame index to use when rendering the entity. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to apply the sheet frame update to.",
			link:"entityData",
		}, {
			type:"integer",
			name:"frameIndex",
			desc:"The index of the sprite-sheet frame to use.",
		}],
	} **/
	setSheetFrame: function (entity, frameIndex) {
		entity.$local.$size = entity.$local.$size || [];
		if (frameIndex) { entity.asset_sheet_frame = frameIndex; }
		
		// Retrieve the array of assets for this entity
		var asset = entity.$local.$asset;
		var assetImage = asset.$local.$image;
		var assetScale = asset.asset_scale;
		var yPos = 0;
		var xPos = 0;
		
		if (assetImage != null) {
			// Calculate the source X and Y of the entity
			if (entity.asset_sheet_frame && asset.asset_sheet_enabled) {
				yPos = (Math.ceil(entity.asset_sheet_frame / asset.asset_sheet_width) - 1);
				xPos = ((entity.asset_sheet_frame - (asset.asset_sheet_width * yPos)) - 1);
				entity.$local.$size[0] = asset.$local.$size[0] * xPos; // Source image starting x
				entity.$local.$size[1] = asset.$local.$size[1] * yPos; // Source image starting y
				entity.$local.$size[4] = asset.asset_anchor_points[entity.asset_sheet_frame - 1]; // Asset anchor point
				if (isNaN(entity.$local.$size[0])) { throw('Error with calculation'); }
			} else {
				entity.$local.$size[0] = 0; // Source image starting x
				entity.$local.$size[1] = 0; // Source image starting y
				entity.$local.$size[4] = asset.asset_anchor_points[0]; // Asset anchor point
			}
		}
	},
	
	/** cullOutOfBoundsEntities - Finds and removes any entities that do not reside inside a
	viewport viewing area. This method also accepts an entity parameter which will instruct
	the method to only check the entity passed for out-of-bounds. {
		category:"method",
		engine_ver:"0.1.3",
		return: {
			type:"integer",
			desc:"Returns the number of entities removed.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"If specified, will limit the bounds check to only this entity.",
			link:"entityData",
			flags:"optional",
		}],
	} **/
	cullOutOfBoundsEntities: function (entity) {
		// TO-DO - Still valid in 1.0.0?
		var removeArray = [];
		var removeCount =  0;
		
		if (!entity) {
			// No entity passed, find all out-of-bounds entities
			var entityArray = this.byIndex;
			var entityCount = entityArray.length;
			
			while (entityCount--) {
				var entity = entityArray[entityCount];
				removeArray[entity.entity_id] = this.isOutOfBounds(entity);
			}
			
			// Now loop through the remove array and remove any entity that is marked as true
			for (var i in removeArray) {
				if (removeArray[i]) {
					this.remove(i);
					removeCount++;
				}
			}
			
			this.log('Removed ' + removeCount + ' entities for out of bounds.');
		} else {
			// Entity passed, check only this one for out-of-bounds
			if (this.isOutOfBounds(entity)) {
				this.remove(entity.entity_id);
				removeCount++;
				console.log('Removed single entity for out of bounds.');
			}
		}
		
		return removeCount;
	},
	
	/** isOutOfBounds - Returns true if the entity is not inside the bounds of any viewport looking
	at the map it exists on, as long as the layer it is on has auto-culling enabled. {
		category:"method",
		engine_ver:"0.1.3",
		return: {
			type:"bool",
			desc:"Returns true if the passed entity is outside the bounds of any active viewport.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to check bounds against.",
			link:"entityData",
		}],
	} **/
	isOutOfBounds: function (entity) {
		// TO-DO - Still valid in 1.0.0?
		return;
		// Start off with the view to remove this entity unless it is proven to need to stay
		var removeEntity = true;
		
		// Grab the map and viewports
		var map = entity.$local.$map;
		if (map != null) {
			if (map.map_layers != null && map.map_layers[entity.entity_layer] != null) {
				// Check if the layer this entity exists on has auto-culling enabled
				var layerAutoMode = map.map_layers[entity.entity_layer].layer_auto_mode;
				if (layerAutoMode == LAYER_AUTO_CULL || layerAutoMode == LAYER_AUTO_CULL + LAYER_AUTO_REQUEST) {
					
					var viewportList = this.viewportsByMapId[map.map_id];
					
					// Check if there are any viewports for this map
					if (viewportList) {
						var viewportCount = viewportList.length;
						
						// Loop through all the viewports looking at the map that this entity exits on
						while (viewportCount--) {
							// Get all the data needed to calculate the entity position within this viewport
							var viewport = viewportList[viewportCount];
							//var assetSize = entity.$local.$asset.$local.$size;
							var entSize = this.getSize(entity);
							var entPos = this.getPosition(entity);
							
							var renderMode = map.map_render_mode;
							
							var fp = [entPos[renderMode][0] + viewport.$viewportAdjustX, entPos[renderMode][1] + viewport.$viewportAdjustY, entSize[2], entSize[3]];
							
							// Check the entity position to see if it is outside of the viewport's bounds
							if ((fp[0] > viewport.panLayer.width || fp[1] > viewport.panLayer.height) || ((fp[0] + fp[2]) < 0 || (fp[1] + fp[3]) < 0)) {
								// The entity is outside the viewport
							} else {
								// The entity needs to stay so mark it as such as exit the viewport loop
								removeEntity = false;
								break;
							}
						}
					} else {
						// Because no viewports are setup yet, lets allow the entity to be created
						// TO-DO - Is this correct logic? Probably not!! Find and fix why an entity would ever
						// be created BEFORE a viewport is set up!
						removeEntity = false;
					}
					
				} else {
					// The map layer the entity exists on does not have auto-culling enabled so don't cull
					removeEntity = false;
				}
				
				return removeEntity;
				
			} else {
				// Map layers is null
				return false;
			}
		} else {
			// The map is null!
			return false;
		}
	},
	
	/** listInBounds - Returns an array of entities that are inside the bounds of the
	given viewport and camera duet. {
		category:"method",
		engine_ver:"0.2.1",
		return: {
			type:"array",
			desc:"Returns an array of entities inside viewport bounds.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport to check bounds against.",
			link:"viewportData",
		}, {
			type:"object",
			name:"camera",
			desc:"The camera to check bounds against.",
			link:"cameraData",
		}],
	} **/
	listInBounds: function (viewport, camera) {
		// TO-DO - Still valid in 1.0.0?
		return;
		
		var entityList = [];
		
		var entList = this.engine.entities.byIndex;
		var count = entList.length;
		
		var map = this.mapsById[viewport.map_id];
		//console.log('VP Dims: ', viewport.panLayer.width, viewport.panLayer.height);
		
		while (count--) {
			var entity = entList[count];
			
			var entSize = this.getSize(entity);
			var entPos = this.getPosition(entity);
			
			var renderMode = map.map_render_mode; 
			
			var fp = [entPos[renderMode][0] + viewport.$viewportAdjustX, entPos[renderMode][1] + viewport.$viewportAdjustY, entSize[2], entSize[3]];
			//console.log('Entity ' + entity.entity_id + ' is at ' + fp[0] + ' x ' + fp[1]);
			
			// Check the entity position to see if it is outside of the viewport's bounds
			if ((fp[0] > viewport.panLayer.width || fp[1] > viewport.panLayer.height) || ((fp[0] + fp[2]) < 0 || (fp[1] + fp[3]) < 0)) {
				// The entity is outside the viewport
			} else {
				// The entity is inside the viewport so add it to the entity list
				entityList.push(entity);
			}
		}
		
		return entityList;
	},
	
	/** blockTiles - Marks this entity's tiles as blocked so that no other entity can occupy them
	based upon the map_block property value. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity whose tile co-ordinates will be used to block tiles on the map.",
			link:"entityData",
		}],
	} **/
	blockTiles: function (entity) {
		if (entity.map_block == MAP_BLOCK_NOCHECK || entity.map_block == MAP_BLOCK_CHECK) {
			if (entity.entity_tile_x != null && entity.entity_tile_y != null) {
				var maps = this.engine.maps;
				
				// Does the entity occupy more than one tile?
				if (entity.map_tile_width > 1 || entity.map_tile_height > 1) {
					for (var x = 0; x < entity.map_tile_width; x++) {
						for (var y = 0; y < entity.map_tile_height; y++) {
							maps.markTile(entity.map_id, entity.entity_tile_x + x, entity.entity_tile_y + y, entity.entity_tile_z, entity, 'igeBlock');
						}
					}
				} else {
					// Mark a single tile
					maps.markTile(entity.map_id, entity.entity_tile_x, entity.entity_tile_y, entity.entity_tile_z, entity, 'igeBlock');
				}
				
			}
		}
	},
	
	/** unBlockTiles - Marks this entity's tiles as un-blocked so that other entity's can occupy them. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity whose tile co-ordinates will be used to block tiles on the map.",
			link:"entityData",
		}],
	} **/
	unBlockTiles: function (entity) {
		if (entity.map_block == MAP_BLOCK_NOCHECK || entity.map_block == MAP_BLOCK_CHECK) {
			if (entity.entity_tile_x != null && entity.entity_tile_y != null) {
				var maps = this.engine.maps;
				
				// Does the entity occupy more than one tile?
				if (entity.map_tile_width > 1 || entity.map_tile_height > 1) {
					for (var x = 0; x < entity.map_tile_width; x++) {
						for (var y = 0; y < entity.map_tile_height; y++) {
							maps.unMarkTile(entity.map_id, entity.entity_tile_x + x, entity.entity_tile_y + y, entity.entity_tile_z, 'igeBlock');
						}
					}
				} else {
					// Mark a single tile
					maps.unMarkTile(entity.map_id, entity.entity_tile_x, entity.entity_tile_y, entity.entity_tile_z, 'igeBlock');
				}
				
			}
		}
	},
	
	/** isEntityTileBlocked - Checks if a tile is currently blocked by an entity. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"object",
			desc:"Returns the entity that is currently blocking the specified tile area, or false if no blocking exists.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity whose tile co-ordinates will be used to check if a tile is blocked.",
			link:"entityData",
		}, {
			type:"object",
			name:"tileX",
			desc:"If specified, will override the entity's x tile co-ordinate (entity_tile_x) with this value when evaluating the tile map for a potential block.",
			flags:"optional",
		}, {
			type:"object",
			name:"tileY",
			desc:"If specified, will override the entity's y tile co-ordinate (entity_tile_y) with this value when evaluating the tile map for a potential block.",
			flags:"optional",
		}, {
			type:"object",
			name:"tileZ",
			desc:"If specified, will override the entity's z tile co-ordinate (entity_tile_z) with this value when evaluating the tile map for a potential block.",
			flags:"optional",
		}],
	} **/
	isEntityTileBlocked: function (entity, tileX, tileY, tileZ) {
		if ((entity.entity_tile_x != null && entity.entity_tile_y != null && entity.entity_tile_z != null) || 
		    (tileX != null && tileY != null && tileZ != null)) {
			var maps = this.engine.maps;
			
			var finalTileX = null;
			var finalTileY = null;
			var finalTileZ = null;
						
			if (tileX != null && tileY != null && tileZ != null) {
				finalTileX = tileX;
				finalTileY = tileY;
				finalTileZ = tileZ;
			} else {
				finalTileX = entity.entity_tile_x;
				finalTileY = entity.entity_tile_y;
				finalTileZ = entity.entity_tile_z;				
			}
			
			// Does the entity occupy more than one tile?
			if (entity.map_tile_width > 1 || entity.map_tile_height > 1) {
				for (var x = 0; x < entity.map_tile_width; x++) {
					for (var y = 0; y < entity.map_tile_height; y++) {
						var block = maps.getTileMark(entity.map_id, finalTileX + x, finalTileY + y, finalTileZ, 'igeBlock');
						if (block && (block.map_block == MAP_BLOCK_NOCHECK || block.map_block == MAP_BLOCK_CHECK)) { 
							// Check that the block is not itself
							if (block != entity) {
								// Tile is blocked so return the blocking entity
								return block;
							}
						}
					}
				}
			} else {
				// Mark a single tile
				var block = maps.getTileMark(entity.map_id, finalTileX, finalTileY, finalTileZ, 'igeBlock');
				if (block && (block.map_block == MAP_BLOCK_NOCHECK || block.map_block == MAP_BLOCK_CHECK)) { 
					// Check that the block is not itself
					if (block != entity) {
						// Tile is blocked so return the blocking entity
						return block;
					}
				}
			}
		}
		
		return false;
	},
	
	/** saveEntityDataAsJson - Saves map entity data as a JSON data file. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to read entity data from.",
		}, {
			type:"string",
			name:"fileName",
			desc:"The path and name of the file to save the data to.",
		}],
	} **/
	saveEntityDataAsJson: function (mapId, fileName) {
		// TO-DO - This method is beta code, please complete!
		var data = this.engine.stripLocalDeep(this.byMapId[mapId]);
		
		// Scan through the objects, for each one with a template, check if the properties of the
		// object match those of the template and if so, remove the properties that match since
		// they are already defined in the template!
		for (var di in data) {
			var obj = data[di];
			// Delete entity_tile_x and y since actual_x and y are also stored and will work anyway
			delete obj['entity_tile_x'];
			delete obj['entity_tile_y'];
			// Remove entity_db_id since we don't need to store it
			delete obj['entity_db_id'];
			delete obj['entity_persist'];
			delete obj['entity_locale'];
			// We are extracting a single map's data so we already know the map_id
			delete obj['map_id'];
			// Check for a template_id
			if (obj.template_id) {
				var template = this.engine.templates.read(obj.template_id);
				for (var ti in template.template_contents) {
					if (template.template_contents[ti] == obj[ti]) {
						// The object's property value matches the template's so remove it from the object
						delete obj[ti];
					}
				}
			}
		}
		
		var objectJson = JSON.stringify(data);
		
		// Build term lookup data
		var propIndex = this.engine.buildTermIndexCompressed(data);
		
		// Replace each instance of a property name with it's new index
		for (var i in propIndex) {
			var regex = new RegExp('"' + propIndex[i] + '"', 'g');
			objectJson = objectJson.replace(regex, '"¬' + i + '"');
		}
		
		// Replace true and false with 1 and 0 to get compression of those values
		var regex = new RegExp(':true', 'g');
		objectJson = objectJson.replace(regex, ':1');
		
		var regex = new RegExp(':false', 'g');
		objectJson = objectJson.replace(regex, ':0');		
		
		if (data != null) {
			fs.writeFile(igeConfig.mapUrl(fileName + '.json'), BISON.encode(data), this.bind(function (err) {
				if (!err) {
					this.log('Entity data saved successfully to ' + igeConfig.mapUrl(fileName + '.json'));
				} else {
					this.log('ERROR Saving entity data to ' + igeConfig.mapUrl(fileName + '.json'), 'warning', err);
				}
			}));
			
			fs.writeFile(igeConfig.mapUrl(fileName + '_fields.json'), BISON.encode(propIndex), this.bind(function (err) {
				if (!err) {
					this.log('Entity data saved successfully to ' + igeConfig.mapUrl(fileName + '_fields.json'));
				} else {
					this.log('ERROR Saving entity data to ' + igeConfig.mapUrl(fileName + '_fields.json'), 'warning', err);
				}
			}));
		}
	},
	
	/** atScreenXY - Determines the entities under a screen pixel co-ordinate. Useful
	for getting an array of entities that the mouse is hovering over. {
		category:"method",
		engine_ver:"0.2.5",
		return: {
			type:"array",
			desc:"Returns an array of entities sorted by their depth, whose pixels are intersected by the specified x and y screen co-ordinates.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	atScreenXY: function (viewport, x, y) {
		// TO-DO - Still valid in 1.0.0?
		return;
		
		// Convert event mouse co-ordinates into canvas co-ordinates
		var elementOffset = $('#' + viewport.viewport_id).offset();
		var renderMode = viewport.$local.$map.map_render_mode;
		var x = x - elementOffset.left - viewport.panLayer.centerX;
		var y = y - elementOffset.top - viewport.panLayer.centerY;
		
		var hitArray = [];
		
		// Loop entities and detect if our mouse is inside the entity bounding box
		// Get all the entities
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			var entity = ents[count];
			var entSize = this.getSize(entity);
			var entPos = this.getPosition(entity);
			var fp = [entPos[renderMode][0] + viewport.$viewportAdjustX, entPos[renderMode][1] + viewport.$viewportAdjustY, entSize[2], entSize[3]];
			var depth = 0;
			
			// Check mouse co-ordinates and see if they are inside our entity bounding box
			if (fp[0] <= x && fp[1] <= y && fp[0] + fp[2] > x && fp[1] + fp[3] > y) {
				// Grab the asset's image
				var img = this.engine.assets.assetImage[entity.asset_id];
				var assetSize = entity.$local.$asset.$local.$size;
				
				// Create a temporary canvas to use for image pixel scanning
				var canvas = document.createElement('canvas');
				canvas.width = entSize[2];
				canvas.height = entSize[3];
				
				var ctx = canvas.getContext('2d');
				ctx.drawImage(img, 0, 0, entSize[2], entSize[3]);
				ctx.drawImage(img, entSize[0], entSize[1], assetSize[0], assetSize[1], 0, 0, entSize[2], entSize[3]);
				
				var pixel = ctx.getImageData(x - fp[0], y - fp[1], 1, 1);
				
				if (pixel.data[3] > 127) {
					// Get the depth of the entity
					//depth = this.engine.renderer.tileCordsToDepth(entity.entity_tile_x, entity.entity_tile_y, entity.entity_tile_z, entity.entity_tile_width, entity.entity_tile_height, 0);
					depth = entity._depth;
					
					// Add it to the hit array
					hitArray.push([entity, depth]);
				}
			}
		}
		
		if (hitArray.length > 1) {
			// Depth-sort the array
			hitArray.sort(function (a, b) { return b[1] - a[1]; });
		}
		return hitArray;
	},
	
	/** highlightAtScreenXY - Highlights all entities whose pixel data is drawn at
	the specified co-ordinates. Useful for pixel-perfect highlighting of entities. {
		category:"method",
		engine_ver:"0.2.5",
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	highlightAtScreenXY: function (viewport, x, y) {
		// TO-DO - Still valid in 1.0.0?
		return;
		
		// Convert event mouse co-ordinates into canvas co-ordinates
		var elementOffset = $('#' + viewport.viewport_id).offset();
		var renderMode = viewport.$local.$map.map_render_mode;
		var x = x - elementOffset.left - viewport.panLayer.centerX;
		var y = y - elementOffset.top - viewport.panLayer.centerY;
		
		// Loop entities and detect if our mouse is inside the entity bounding box
		// Get all the entities
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			var entity = ents[count];
			var entSize = this.getSize(entity);
			var entPos = this.getPosition(entity);
			var fp = [entPos[renderMode][0] + viewport.$viewportAdjustX, entPos[renderMode][1] + viewport.$viewportAdjustY, entSize[2], entSize[3]];
			var depth = 0;
			
			// Check mouse co-ordinates and see if they are inside our entity bounding box
			if (fp[0] <= x && fp[1] <= y && fp[0] + fp[2] > x && fp[1] + fp[3] > y) {
				// Grab the asset's image
				var img = this.engine.assets.assetImage[entity.asset_id];
				var assetSize = entity.$local.$asset.$local.$size;
				
				// Create a temporary canvas to use for image pixel scanning
				var canvas = document.createElement('canvas');
				canvas.width = entSize[2];
				canvas.height = entSize[3];
				
				var ctx = canvas.getContext('2d');
				ctx.drawImage(img, 0, 0, entSize[2], entSize[3]);
				ctx.drawImage(img, entSize[0], entSize[1], assetSize[0], assetSize[1], 0, 0, entSize[2], entSize[3]);
				
				var pixel = ctx.getImageData(x - fp[0], y - fp[1], 1, 1);
				
				if (pixel.data[3] > 127) {
					this.highlight(entity);
				} else {
					this.unHighlight(entity);
				}
			} else {
				this.unHighlight(entity);
			}
		}
	},
	
	/** atTileXY - Determines all entities currently occupying the specified tile 
	co-ordinates. {
		category:"method",
		engine_ver:"0.2.5",
		return: {
			type:"array",
			desc:"Returns an array of two-dimensional arrays contaning an entity and its depth, sorted by their depths, that occupy the specified tile co-ordinates.",
			index:"integer",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	atTileXY: function (viewport, x, y) {
		// TO-DO - Still valid in 1.0.0?
		var ents = this.byIndex;
		var count = ents.length;
		var hitArray = [];
		
		while (count--) {
			var entity = ents[count];
			var depth = 0;
			
			// Check mouse co-ordinates and see if they are inside our entity bounding box
			if (entity.entity_tile_x <= x && entity.entity_tile_y <= y && entity.entity_tile_x + (entity.map_tile_width) > x && entity.entity_tile_y + (entity.map_tile_height) > y) {
				// Get the depth of the entity
				//depth = this.engine.renderer.tileCordsToDepth(entity.entity_tile_x, entity.entity_tile_y, entity.entity_tile_z, entity.entity_tile_width, entity.entity_tile_height, 0);
				depth = entity._depth;
				
				// Add it to the hit array
				hitArray.push([entity, depth]);
			}
		}
		
		if (hitArray.length > 1) {
			// Depth-sort the array
			hitArray.sort(function (a, b) { return b[1] - a[1]; });
		}
		return hitArray;
	},
	
	/** highlightAtTileXY - Highlights all entities occupying the specified tile
	co-ordinates. {
		category:"method",
		engine_ver:"0.2.5",
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	highlightAtTileXY: function (viewport, x, y) {
		// TO-DO - Still valid in 1.0.0?
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			var entity = ents[count];
			
			// Check mouse co-ordinates and see if they are inside our entity bounding box
			if (entity.entity_tile_x <= x && entity.entity_tile_y <= y && entity.entity_tile_x + (entity.map_tile_width) > x && entity.entity_tile_y + (entity.map_tile_height) > y) {
				this.highlight(entity);
			} else {
				this.unHighlight(entity);
			}
		}
	},
	
	/** highlight - Sets the specified entity to be drawn with highlighting. {
		category:"method",
		engine_ver:"0.2.5",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to highlight.",
			link:"entityData",
		}],
	} **/
	highlight: function (entity) {
		if (!entity.entity_highlight) {
			entity.entity_highlight = true;
			this.markDirty(entity);
		}
	},
	
	/** highlightOne - Sets the specified entity to highlight and unhighlights
	all other entities. {
		category:"method",
		engine_ver:"0.2.5",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"An entity to highlight.",
			link:"entityData",
		}],
	} **/
	highlightOne: function (entity) {
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			var tmpEnt = ents[count];
			if (tmpEnt == entity) {
				this.highlight(entity);
			} else {
				this.unHighlight(tmpEnt);
			}
		}
	},
	
	/** unHighlight - Sets the specified entity to be drawn without highlighting. {
		category:"method",
		engine_ver:"0.2.5",
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The entity to un-highlight.",
			link:"entityData",
		}],
	} **/
	unHighlight: function (entity) {
		if (entity.entity_highlight) {
			entity.entity_highlight = false;
			this.markDirty(entity);
		}
	},
	
	/** unHighlightAll - Sets all entities to be drawn without highlighting. {
		category:"method",
		engine_ver:"0.2.5",
	} **/
	unHighlightAll: function () {
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			this.unHighlight(ents[count]);
		}
	},
	
	////////////////////////////////////////////////////////////////////////////////
	// 1.0.0 entity interpolation system
	////////////////////////////////////////////////////////////////////////////////
	/* OEXCLUDE */
	/* TEXCLUDE */
	processInterpolation: function (currentTime) {
		// Update the current time 
		this._currentTime = new Date().getTime();
		this._renderTime = this._currentTime - this.engine.network._renderLatency;
		
		// Interpolate entity positions
		this._interpolateEntities(this._renderTime);
	},
	
	_interpolateEntities: function (renderTime, maxLerp) {
		// TO-DO - This info has changed since the transform class was created,
		// update to the latest spec (_wx, _wy, _wz etc are different now)
		
		// Set the maxium lerp to 200 if none is present
		if (!maxLerp) { maxLerp = 200; }
		var maxLerpSq = maxLerp * maxLerp;
		
		// Loop each entity in the simulation
		for (var entityIndex = 0; entityIndex < this.byIndex.length; entityIndex++) {
			var entity = this.byIndex[entityIndex];
			var previousData = null, nextData = null;
			
			// Find the update closest to the render time
			// and assign the previous and next data points
			var gotTarget = false;
			var targetData = entity._targetData;
			var i = 1;
			
			while (targetData[i]) {
				if (targetData[i][0] >= renderTime) {
					// We have previous and next data points so store them
					previousData = targetData[i - 1];
					nextData = targetData[i];
					break;
				}
				i++;
			}
			
			// Check to make sure we have some data to use
			if (!nextData && !previousData) {
				// No in-time data was found, check for lagging data
				if (targetData.length > 2) {
					if (targetData[targetData.length - 1][0] < renderTime) {
						// Lagging data is available, use that
						previousData = targetData[targetData.length - 2];
						nextData = targetData[targetData.length - 1];
						targetData.shift();
						this.emit('entityInterpolationLag');
					}
				}
			} else {
				// Non-lagging data was found, clear the old lagging data
				targetData.splice(0, i - 1);
			}
			
			// If we have data to use
			if (nextData && previousData) {
				// Calculate the delta times
				var dataDelta = nextData[0] - previousData[0];
				var offsetDelta = renderTime - previousData[0];
				
				// Calculate the current time between the two data points
				var currentTime = offsetDelta / dataDelta;
				
				// Clamp the current time from 0 to 1
				if (currentTime < 0) { currentTime = 0.0; } else if (currentTime > 1) { currentTime = 1.0; }
				
				// Set variables up to store the previous and next positions and angles
				var previousPosition = {x:previousData[1]._transform[0], y:previousData[1]._transform[1]},
					nextPosition = {x:nextData[1]._transform[0], y:nextData[1]._transform[1]},
					previousAngle = previousData[1]._transform[6],
					nextAngle = nextData[1]._transform[6];
				
				// Calculate the squared distance between the previous point and next point
				var dist = this.distanceSquared(previousPosition.x, previousPosition.y, nextPosition.x, nextPosition.y);
				
				// Check that the distance is not higher than the maximum lerp and if higher,
				// set the current time to 1 to snap to the next position immediately
				if (dist > maxLerpSq) { currentTime = 1; }
				
				// Interpolate the entity position by multiplying the Delta times T, and adding the previous position
				var currentPosition = {};
				currentPosition.x = ( (nextPosition.x - previousPosition.x) * currentTime ) + previousPosition.x;
				currentPosition.y = ( (nextPosition.y - previousPosition.y) * currentTime ) + previousPosition.y;
				currentAngle = ( (nextAngle - previousAngle) * currentTime ) + previousAngle;
				
				// Now actually transform the entity
				// TO-DO - BUG this is using hard-coded pixel to metre value of 30...
				// need to read the set PTM value from box2d instead!!
				this.translate(entity, currentPosition.x, currentPosition.y);
				this.rotate(entity, currentAngle);
				
				// Record the last time we updated the entity so we can disregard any updates
				// that arrive and are before this timestamp (not applicable in TCP but will
				// apply if we ever get UDP in websockets)
				entity._lastUpdate = new Date().getTime();
			}
		}
	},
	
	distance: function (x1, y1, x2, y2) {
		var deltaX = x1 - x2;
		var deltaY = y1 - y1;
		
		return Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
	},
	
	distanceSquared: function (x1, y1, x2, y2) {
		var deltaX = x1 - x2;
		var deltaY = y1 - y1;
		
		return (deltaX * deltaX) + (deltaY * deltaY);
	},
	/* TEXCLUDE */
	/* OEXCLUDE */
	
	////////////////////////////////////////////////////////////////////////////////
	// 1.0.0 re-code of entity co-ordinate and movement system
	////////////////////////////////////////////////////////////////////////////////
	
	/** _beforeTranslate - Called by the IgeTransform class this class extends and is
	executed before the IgeTransform.translate() method with the same arguments
	so that you can do any pre-processing or cancel the transform by returning true
	from this method. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_beforeTranslate: function (pItem, coOrds, relative, tileBased) {
		// Check if the entity has blocking
		if (tileBased) {
			if (pItem.entity_tile_x != null && pItem.entity_tile_x != null && pItem.entity_tile_x != null) {
				//this.removeFromTileMap(pItem);
				this.unBlockTiles(pItem);
			}
		}
		
		// Assign the direction of the entity
		var direction = [];
		direction[0] = pItem._transform[0] - coOrds[6];
		direction[1] = pItem._transform[1] - coOrds[7];
		direction[2] = pItem._transform[2] - coOrds[8];
		
		// Calculate the direction of movement
		var newDirection = this.directionFromMove(
			pItem._transform[0],
			pItem._transform[1],
			pItem._transform[2],
			coOrds[6],
			coOrds[7],
			coOrds[8],
			pItem.$local.$map,
			pItem.entity_layer
		);
		
		// Check if the direction of the entity has changed
		if (pItem.entity_direction != newDirection) {
			// The direction has changed so emit an event
			pItem.entity_direction = newDirection;
			this.emit('directionChange', pItem);
		}
		
		return false;
	},
	
	/** _afterTranslate - Called by the IgeTransform class this class extends and is
	executed after the IgeTransform.translate() method with the same arguments
	so that you can do any post-processing. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_afterTranslate: function (pItem, x, y, z, relative, tileBased) {
		// Check if we have a valid item object
		if (pItem && pItem.$local && pItem.$local.$map) {
			// Grab the map this entity exists on
			var map = pItem.$local.$map;
			
			// Grab the entity transform data
			var tf = pItem._transform;
			var mapTs = map.map_tilesize;
			
			// Store the old bounding rect
			var oldRect = pItem._bounds;
			
			// Calculate a new bounding rect for this item
			this.bounds(pItem, true);
			
			// Check if we're running on a client
			if (!this.engine.isServer) {
				if (map.map_use_dirty2) {
					// Send the current and new rects to the dirty
					// rectangle system storeRect method
					this.engine.dirtyRects.storeRect(
						pItem.$local.$map,
						pItem.entity_layer,
						pItem._bounds,
						oldRect
					);
				}
			}
			
			// Update the entity depth
			delete pItem._depth;
			this.depth(pItem);
			
			// Update the entity tile data
			pItem.entity_tile_x = Math.floor(tf[0] / mapTs);
			pItem.entity_tile_y = Math.floor(tf[1] / mapTs);
			pItem.entity_tile_z = Math.floor(tf[2] / mapTs);
			
			// Block the tiles this entity is using
			if (tileBased) {
				this.blockTiles(pItem);
			}
		} else {
			this.log('Translate against no $local or $local.$map error! This should never happen, check the stack to trace the issue!', 'warning', pItem);
		}
	},
	
	/** _afterRotate - Called by the IgeTransform class this class extends and is
	executed after the IgeTransform.rotate() method with the same arguments
	so that you can do any post-processing. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_afterRotate: function (pItem, x, y, z, relative) {
		// Check if we're running on a client and dirty rectangle rendering is enabled
		if (pItem && pItem.$local && pItem.$local.$map) {
			// Grab the map this entity exists on
			var map = pItem.$local.$map;
			
			if (!this.engine.isServer && map.map_use_dirty2) {
				// Store the old bounding rect
				var oldRect = pItem._bounds;
				
				// Calculate a new bounding rect for this item
				this.bounds(pItem, true);
				
				// Send the current and new rects to the storeRect method
				this.engine.dirtyRects.storeRect(
					pItem.$local.$map,
					pItem.entity_layer,
					pItem._bounds,
					oldRect
				);
			}
		}
	},
	
	/** _afterScale - Called by the IgeTransform class this class extends and is
	executed after the IgeTransform.scale() method with the same arguments
	so that you can do any post-processing. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_afterScale: function (pItem, x, y, z, relative) {
		// Check if we're running on a client and dirty rectangle rendering is enabled
		if (pItem && pItem.$local && pItem.$local.$map) {
			// Grab the map this entity exists on
			var map = pItem.$local.$map;
			
			// Grab the entity transform data
			var tf = pItem._transform;
			var mapTs = map.map_tilesize;
			
			if (!this.engine.isServer) {
				// Store the old bounding rect
				var oldRect = pItem._bounds;
				
				// Calculate a new bounding rect for this item
				this.bounds(pItem, true);
				
				if (map.map_use_dirty2) {
					// Send the current and new rects to the storeRect method
					this.engine.dirtyRects.storeRect(
						pItem.$local.$map,
						pItem.entity_layer,
						pItem._bounds,
						oldRect
					);
				}
			}
			
			pItem.entity_tile_width = Math.floor((pItem.$local.$originalSize[0] * tf[6]) / mapTs);
			pItem.entity_tile_height = Math.floor((pItem.$local.$originalSize[1] * tf[7]) / mapTs);
		}
	},
	
	/** _afterOrigin - Called by the IgeTransform class this class extends and is
	executed after the IgeTransform.origin() method with the same arguments
	so that you can do any post-processing. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_afterOrigin: function (pItem, x, y, z, relative) {
		// Check if we're running on a client and dirty rectangle rendering is enabled
		if (pItem && pItem.$local && pItem.$local.$map) {
			// Grab the map this entity exists on
			var map = pItem.$local.$map;
			
			if (!this.engine.isServer) {
				// Store the old bounding rect
				var oldRect = pItem._bounds;
				
				// Calculate a new bounding rect for this item
				this.bounds(pItem, true);
				
				if (map.map_use_dirty2) {
					// Send the current and new rects to the storeRect method
					this.engine.dirtyRects.storeRect(
						pItem.$local.$map,
						pItem.entity_layer,
						pItem._bounds,
						oldRect
					);
				}
			}
		}
	},
	
	/** _afterOpacity - Called by the IgeTransform class this class extends and is
	executed after the IgeTransform.opacity() method with the same arguments
	so that you can do any post-processing. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_afterOpacity: function (pItem, x, y, z, relative) {
		// Check if we're running on a client and dirty rectangle rendering is enabled
		if (pItem && pItem.$local && pItem.$local.$map) {
			// Grab the map this entity exists on
			var map = pItem.$local.$map;
			
			if (!this.engine.isServer) {
				if (map.map_use_dirty2) {
					// Send the current and new rects to the storeRect method
					this.engine.dirtyRects.storeRect(
						pItem.$local.$map,
						pItem.entity_layer,
						pItem._bounds,
						pItem._bounds
					);
				}
			}
		}
	},
	
	/** atScreenXY2 - Determines the entities under a screen pixel co-ordinate. Useful
	for getting an array of entities that the mouse is hovering over. {
		category:"method",
		engine_ver:"0.2.5",
		return: {
			type:"array",
			desc:"Returns an array of entities sorted by their depth, whose pixels are intersected by the specified x and y screen co-ordinates.",
		},
		arguments: [{
			type:"object",
			name:"viewport",
			desc:"The viewport that the x and y co-ordinates are taken from.",
			link:"viewportData",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate.",
		}],
	} **/
	atScreenXY2: function (viewport, x, y, typeLimit) {
		// Get the world co-ordinates of the mouse event
		var point = this.ige.viewports.screenToWorld(viewport, x, y);
		var hitArray = [];
		
		// Loop entities and detect if our mouse is inside the entity bounding box
		// Get all the entities
		var ents = this.byIndex;
		var count = ents.length;
		
		while (count--) {
			var entity = ents[count];
			var renderMode = entity.$asset.asset_render_mode;
			
			// Select the correct point co-ordinate type for the layer
			// this entity exists on (either a 2d or iso layer at time
			// of writing in version 1.0.0b)
			x = point[renderMode][0];
			y = point[renderMode][1];
			
			if (typeof(typeLimit != 'undefined')) {
				if (entity.entity_type != typeLimit) {
					continue;
				}
			}
			
			var entityBounds = this.bounds(entity);
			var depth = 0;
						
			// Check mouse co-ordinates and see if they are inside our entity bounding box
			if (entityBounds[0] <= x &&
				entityBounds[1] <= y &&
				entityBounds[0] + entityBounds[2] > x &&
				entityBounds[1] + entityBounds[3] > y) {
				/*
				// Grab the asset's image
				var img = this.engine.assets.assetImage[entity.asset_id];
				var assetSize = entity.$local.$asset.$local.$size;
				
				// Create a temporary canvas to use for image pixel scanning
				var canvas = document.createElement('canvas');
				canvas.width = entSize[2];
				canvas.height = entSize[3];
				
				var ctx = canvas.getContext('2d');
				ctx.drawImage(img, 0, 0, entSize[2], entSize[3]);
				ctx.drawImage(img, entSize[0], entSize[1], assetSize[0], assetSize[1], 0, 0, entSize[2], entSize[3]);
				
				var pixel = ctx.getImageData(x - entityBounds[0], y - entityBounds[1], 1, 1);
				
				if (pixel.data[3] > 127) {
					// Get the depth of the entity
					depth = this.engine.renderer.tileCordsToDepth(entity.entity_tile_x, entity.entity_tile_y, entity.entity_tile_z, entity.entity_tile_width, entity.entity_tile_height, 0);
					
					// Add it to the hit array
					hitArray.push([entity, depth]);
				}
				*/
				hitArray.push([entity, depth]);
			}
		}
		
		if (hitArray.length > 1) {
			// Depth-sort the array
			hitArray.sort(function (a, b) { return b[1] - a[1]; });
		}
		return hitArray;
	},
	
	mount: function (entity) {
		if (entity.mount_to) {
			var targetEntity = this.read(entity.mount_to);
			if (targetEntity) {
				// Setup the defaults inside the new mounted entity
				entity.$local = {};
				this.setAsset(entity, entity.asset_id);
				this.applyTransform(entity);
				
				this.log('Mounting new entity to ' + entity.mount_to + ' at ' + entity.mount_at);
				targetEntity.$local.$mounts = targetEntity.$local.$mounts ||  [];
				targetEntity.$local.$mounts.push(entity);
			}
		}
	},
	
	enable: function (entity) {
		entity.entity_disabled = false;
	},
	
	disable: function (entity) {
		entity.entity_disabled = true;
	},
	
});