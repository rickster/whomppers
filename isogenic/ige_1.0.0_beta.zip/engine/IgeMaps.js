/** IgeMaps - The map management class. {
	category:"class",
	examples:[{
		name:"Create a New Map",
		desc:"Creates a new map with a tile size of 40 pixels and four layers.",
		code:"<pre>
			this.ige.maps.create({
				map_id:'testMap1',
				map_tilesize:40,
				map_use_dirty:false,
				map_dirty_grid:false,
				map_debug_dirty:false,
				map_debug_entities:false,
				map_dirty_width:150,
				map_dirty_height:150,
				map_render:true,
				map_layers:[
					{
						layer_auto_mode:LAYER_AUTO_NONE,
						layer_type:LAYER_TYPE_HTML,
						layer_entity_types: LAYER_BACKGROUNDS,
						layer_render_mode: RENDER_MODE_2D,
					},
					{
						layer_auto_mode:LAYER_AUTO_NONE,
						layer_type:LAYER_TYPE_AUTO,
						layer_entity_types: LAYER_TILES,
						layer_render_mode: RENDER_MODE_ISOMETRIC,
					},
					{
						layer_auto_mode:LAYER_AUTO_NONE,
						layer_type:LAYER_TYPE_AUTO,
						layer_entity_types: LAYER_SPRITES,
						layer_render_mode: RENDER_MODE_ISOMETRIC,
					},
					{
						layer_auto_mode:LAYER_AUTO_NONE,
						layer_type:LAYER_TYPE_AUTO,
						layer_entity_types: LAYER_UI,
						layer_render_mode: RENDER_MODE_2D,
					},
				],
				map_persist:PERSIST_DISABLED,
			});
		</pre>",
	}],
} **/

/** beforeCreate - Fired before a map is created. {
	category: "event",
} **/
/** afterCreate - Fired after a map is created. {
	category: "event",
} **/
IgeMaps = new IgeClass({
	
	Extends: [IgeCollection, IgeItem, IgeEvents],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** entities - A reference to this.engine.entities for fast access. {
		category:"property",
		type:"object",
		instanceOf:"IgeEntities",
	} **/
	entities: null,
	
	/** byIndex - An array with an integer index that allows you to access every
	item created using the create method in the order it was created. {
		category:"property",
		type:"array",
		index:"integer",
	} **/
	byIndex: null,
	
	/** byId - An array with a string index that allows you to access every item
	created using the create method by its id. {
		category:"property",
		type:"array",
		index:"string",
	} **/
	byId: null,
	
	/** tileMap - An array with a string index that allows you to access arbitrary
	marks on the tile map by their x, y and type (tileMap[map_id][x][y][type]). {
		category:"property",
		type:"array",
		index:"string",
	} **/
	tileMap: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeMaps';
		this.engine = engine;
		this.collectionId = 'map';
		this.entities = this.engine.entities.byMapId;
		
		this.byIndex = [];
		this.byId = [];
		this.tileMap = [];
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this._networkInit();
		}			
	},
	
	/** _networkInit - Called by the init method if a networking class instance is in place.
	Does network-related calls that should only execute if a network is present. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_networkInit: function () {
		// Network CRUD Commands
		this.engine.network.registerCommand('mapsCreate', this.bind(this.receiveCreate));
		this.engine.network.registerCommand('mapsUpdate', this.bind(this.receiveUpdate));
		this.engine.network.registerCommand('mapsRemove', this.bind(this.receiveRemove));
		
		// Register standard property names to the network manifest see the API manual for more details
		this.engine.network.addToManifest([
			'map_id',
		]);
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends when creating a new item. Here you can define
	any object properties that are default across all items of this class. If this method returns false the create action
	will be cancelled. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureIdExists(pItem);
		this.ensureLocalExists(pItem);
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends when creating a new item. Checks the
	integrity of an item before it is allowed to be created. Here you can define custom checks to ensure an item being
	created conforms to the standard your class requires. If this method returns false the create action will be cancelled. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		if (this.byId[pItem[this.collectionId + '_id']]) {
			this.log('Attempted to create a ' + this.collectionId + ' that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		return true;
	},
	
	/** _create - Create a new map. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"object",
			desc:"Returns the newly created map or false on failure.",
		},
		arguments: [{
			type:"object",
			name:"map",
			desc:"The map object to be created.",
			link:"mapData",
		}, {
			type:"method",
			name:"callback",
			desc:"The method to call when the map has been created successfully.",
		}],
	} **/
	_create: function (pItem) {
		pItem.$local.$tileWidth = pItem.map_tilesize;
		switch(pItem.map_render_mode) {
			case MAP_RENDER_MODE_2D:
				// 2D tile ratio is 1:1
				pItem.$local.$tileHeight = pItem.$local.$tileWidth;
			break;
			case MAP_RENDER_MODE_ISOMETRIC:
				// 2D tile ratio is 2:1
				pItem.$local.$tileHeight = pItem.$local.$tileWidth / 2;
			break;
		}
		
		// If we're a client, do some stuff here
		if (!this.engine.isServer) {
			// Based upon the current browser, set the layer type (canvas, html, webgl) if the layer is set to auto
			var mapLayers = pItem.map_layers;
			
			if (mapLayers) {
				for (var layerIndex = 0; layerIndex < mapLayers.length; layerIndex++) {
					var layer = mapLayers[layerIndex];
					
					// Check if the layer is set to auto-detect the best output type
					if (layer.layer_type == LAYER_TYPE_AUTO) {
						// Default to canvas output
						layer.layer_type = LAYER_TYPE_CANVAS;
					}
				}
				
				// Check and set the map's debug layer
				if (typeof(pItem.map_debug_layer) == 'undefined') {
					// Set the debug layer to default to the last defined map layer
					pItem.map_debug_layer = mapLayers.length - 1;
				}
			} else {
				this.log('Unable to create map because the map object does not contain a map_layers array!', 'error', pItem);
				return false;
			}
		}
		
		pItem.map_tilesize2 = pItem.map_tilesize / 2;
		pItem.map_tilesize4 = pItem.map_tilesize / 4;
		
		// If the map is set to use dirty rectangles, set them up!
		if (pItem.map_use_dirty) {
			if (pItem.map_dirty_width && pItem.map_dirty_height) {
				this.engine.dirtyRects.create(pItem, pItem.map_dirty_width, pItem.map_dirty_height);
			} else {
				this.log('Cannot setup map dirty rectangle system because either no width or no height was specified.', 'error', pItem);
			}
		}
		
		// Push the map to the collection
		this.byIndex.push(pItem);
		this.byId[pItem.map_id] = pItem;
		
		// Check for a callback function embedded in the item
		if (typeof(pItem.$local.create_callback) == 'function') {
			pItem.$local.create_callback.apply(this, [pItem]);
			delete pItem.$local.create_callback;
		}		
		
		this.emit('afterCreate', pItem);			
		
		return pItem;
	},
	
	/** _update - Updates the class collection item with the matching id specified in the updData
	parameter with all properties of the pData parameter. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (pItem, pData) {
		// Grab the current item object
		var pItem = this.read(pItem);

		// Update the current object with the new object's properties
		for (var i in pData) {
			pItem[i] = pData[i];
		}
		
		if (typeof(pItem.$local.update_callback) == 'function') {
			pItem.$local.update_callback(pItem);
			pItem.$local.update_callback = null;
		}
		
		this.emit('afterUpdate', pItem);
						
		return pItem;
	},
	
	/** _remove - Private method that removes the item identified by the passed
	id from the engine. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"curScreen",
			desc:"The item to be removed.",
			link:"screenData",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (pItem && pItem != null) {
			// Check if the pItem has a callback method and if so, save a reference to it, then fire after removal of the pItem
			var cbMethod = null;
			if (typeof pItem.$local.$callback == 'function') {
				cbMethod = pItem.$local.$callback;
			}
			
			// Remove it from all the arrays
			var arr1 = this.byIndex;
			
			// Remove the item from all the lookup arrays
			delete this.byId[pItem[this.collectionId + '_id']];
			var arr1Index = arr1.indexOf(pItem);
			arr1.splice(arr1Index, 1);
			
			if (typeof cbMethod == 'function') {
				cbMethod.apply(this);
			}
			
			return true;
		} else {
			return false;
		}
	},
	
	/** blockTile - Sets a tile as blocked so that entities cannot be placed there. {
		category:"method",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to set the block on.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to block.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to block.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to block.",
		}],
	} **/
	blockTile: function (mapId, x, y, z) {
		this.markTile(mapId, x, y, z, true, 'igeBlock');
	},
	
	/** unBlockTile - Removes a tile blocking flag so that entities can be placed there. {
		category:"method",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to clear the block on.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to un-block.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to un-block.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to un-block.",
		}],
	} **/
	unBlockTile: function (mapId, x, y, z) {
		this.markTile(mapId, x, y, z, false, 'igeBlock');
	},
	
	/** isTileBlocked - Check if a tile has been blocked. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns the blocking item if the tile is blocked, false if not.",
		},
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to check the block on.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to check.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to check.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to check.",
		}, {
			type:"integer",
			name:"tileWidth",
			desc:"The tile width to check against. Defaults to 1 if not specified.",
		}, {
			type:"integer",
			name:"tileHeight",
			desc:"The tile height to check against. Defaults to 1 if not specified.",
		}],
	} **/
	isTileBlocked: function (mapId, tileX, tileY, tileZ, tileWidth, tileHeight) {
		tileZ = tileZ || 0; // Set a default for z value
		
		if (tileWidth > 1 || tileHeight > 1) {
			for (var x = 0; x < tileWidth; x++) {
				for (var y = 0; y < tileHeight; y++) {
					var block = this.getTileMark(mapId, tileX + x, tileY + y, tileZ, 'igeBlock');
					if (block && (block.map_block == MAP_BLOCK_NOCHECK || block.map_block == MAP_BLOCK_CHECK)) { 
						// Tile is blocked so return the blocking entity
						return block;
					}
				}
			}
		} else {
			// Check a single tile
			var block = this.getTileMark(mapId, tileX, tileY, tileZ, 'igeBlock');
			if (block && (block.map_block == MAP_BLOCK_NOCHECK || block.map_block == MAP_BLOCK_CHECK)) { 
				// Tile is blocked so return the blocking entity
				return block;
			}
		}
		
		return false;
	},
	
	/** markTile - Marks a tile with the passed data. {
		category:"method",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to mark the tile on.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to mark.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to mark.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to mark.",
		}, {
			type:"multi",
			name:"mark",
			desc:"The data to mark the tile with. This can be any valid JavaScript data type except types that evaluate to false.",
		}, {
			type:"string",
			name:"type",
			desc:"A string denoting the type of mark to store. 'igeBlock' is used for tile blocking, you may use any other value.",
		}],
	} **/
	markTile: function (mapId, x, y, z, mark, type) {
		if (!type) { type = 0; } // Set a default type to avoid crashing
		this.tileMap[mapId] = this.tileMap[mapId] || [];
		this.tileMap[mapId][x] = this.tileMap[mapId][x] || [];
		this.tileMap[mapId][x][y] = this.tileMap[mapId][x][y] || [];
		this.tileMap[mapId][x][y][z] = this.tileMap[mapId][x][y][z] || [];
		this.tileMap[mapId][x][y][z][type] = mark;
	},
	
	/** unMarkTile - Remove all marking data from a tile. {
		category:"method",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to remove marking data from.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to remove marking data from.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to remove marking data from.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to remove marking data from.",
		}, {
			type:"string",
			name:"type",
			desc:"A string denoting the type of mark to un-mark. 'igeBlock' is used for tile blocking, you may use any other value.",
		}],
	} **/
	unMarkTile: function (mapId, x, y, z, type) {
		if (!type) { type = 0; } // Set a default type to avoid crashing
		if (this.tileMap[mapId] && this.tileMap[mapId][x] && this.tileMap[mapId][x][y] && this.tileMap[mapId][x][y][z] && this.tileMap[mapId][x][y][z][type]) {
			this.tileMap[mapId][x][y][z][type] = null;
		}
	},
	
	/** getTileMark - Get the marking data on a tile. {
		category:"method",
		return: {
			type:"multi",
			desc:"Returns the marking data applied to a tile, or null if the tile has no data.",
		},
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to return marking data from.",
		}, {
			type:"integer",
			name:"x",
			desc:"The x co-ordinate of the tile to return marking data from.",
		}, {
			type:"integer",
			name:"y",
			desc:"The y co-ordinate of the tile to return marking data from.",
		}, {
			type:"integer",
			name:"z",
			desc:"The z co-ordinate of the tile to return marking data from.",
		}, {
			type:"string",
			name:"type",
			desc:"A string denoting the type of mark to lookup. 'igeBlock' is used for tile blocking, you may use any other value.",
		}],
	} **/	
	getTileMark: function (mapId, x, y, z, type) {
		if (!type) { type = 0; } // Set a default type to avoid crashing
		if (this.tileMap[mapId] && this.tileMap[mapId][x] && this.tileMap[mapId][x][y] && this.tileMap[mapId][x][y][z]) {
			return this.tileMap[mapId][x][y][z][type];
		} else {
			return null;
		}
	},
	
	/** makeMapDirty - Marks the map and any viewports looking at
	it as dirty and in need of a complete re-draw in the renderer. {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to run the operation on.",
		}],
	} **/
	makeMapDirty: function (mapId) {
		var map = this.read(mapId);
		
		if (map) {
			var viewports = this.engine.viewports.byMapId[map.map_id];
			if (viewports && viewports.length) {
				for (var i = 0; i < viewports.length; i++) {
					this.engine.viewports.makeViewportDirty(viewports[i]);
				}
			}
		}
	},
	
	/** toggleMapOption - Toggles an option on the map object. If an
	option is currently false it will be set to true and vice-versa {
		category:"method",
		engine_ver:"1.0.0",
		arguments: [{
			type:"string",
			name:"mapId",
			desc:"The id of the map to run the operation on.",
		}],
	} **/
	toggleMapOption: function (mapId, option) {
		var map = this.read(mapId);
		
		if (map) {
			// Toggle the map option
			if (option == 'map_use_dirty' && !map.map_use_dirty && typeof(map.$local.$dirtyRects) == 'undefined') {
				this.log('Cannot enabled dirty rectangle-based rendering because the game was not started with it enabled!', 'warning');
				return false;
			}
			
			this.toggleOption(option, map);
			
			// Set the map to dirty
			this.makeMapDirty(map);
		}
	}
	
});