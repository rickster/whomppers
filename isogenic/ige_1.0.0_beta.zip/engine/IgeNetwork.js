/** IgeNetwork - The network management class. {
	category:"class",
	providers:[
		"IgeNetworkProvider_Offline",
		"IgeNetworkProvider_SocketIO",
		"IgeNetworkProvider_Pusher"
	],
	examples:[{
		name:"Register a New Network Command",
		desc:"Before you can send a command message over the network you must register it. Network command registration must only happen from inside the networkCommands() methods in the game/engine source.",
		code:"<pre>
			this.ige.network.registerCommand('someCommand');
		</pre>",
	}, {
		name:"Send a Network Message to all Clients",
		desc:"Sends a network command over the network to call connected clients.",
		code:"<pre>
			this.ige.network.send('someCommand', {someData:'hello'});
		</pre>",
	}],
} **/

/** serverStarted - Fired after the network system has started up server-side. {
	category: "event",
} **/
IgeNetwork = new IgeClass({
	Extends: [IgeEvents, IgeNetwork_Packet],
	
	/** engine - A reference object to the main engine instance. {
		category:"property",
		engine_ver:"0.1.0",
		type:"object",
		instanceOf:"IgeEngine",
	} **/
	engine: null,
	
	/** bison - An instance of the BiSON.js library (lib_bison.js). {
		category:"property",
		engine_ver:"0.2.0",
		type:"object",
	} **/
	bison: null,
	
	/** io - An object holding connection provider libraries such as socket.io and pusher. {
		category:"property",
		type:"object",
	} **/
	io: null,
	
	/** socket - The provider connection instance. {
		category:"property",
		type:"object",
		
	} **/
	socket: null,
	
	/** _commandList - An enum of network commands, each command is set by using the 'registerCommand' method. {
		category:"property",
		engine_ver:"0.1.0",
		type:"object",
		instanceOf:"IgeEnum",
	} **/	
	_commandList: null,
	
	/** _requests - An array of request ids for tracking and responding to async requests (internal use). {
		category:"property",
		engine_ver:"0.1.0",
		type:"array",
	} **/
	_requests: null,
	
	/** _sequenceId - An integer counter for use when generating sequence ids (internal use). {
		category:"property",
		engine_ver:"0.1.0",
		type:"integer",
	} **/
	_sequenceId: null,
	
	/** _serveClients - Determines if connecting clients are allowed to continue with
	conection or are just dropped. (internal use). {
		category:"property",
		engine_ver:"0.2.0",
		type:"bool",
	} **/	
	_serveClients: null,
	
	/** netProps - An enum containing data about which item properties of a class should
	propagate to connected clients. {
		engine_ver:"0.2.0",
		category:"property",
		type:"array",
		index:"multi",
		instanceOf:"IgeEnum",
	} **/
	netProps: null,
	
	/** _netClassByPropId - An array containing data about network property ids and the classes
	they map to (internal use). {
		engine_ver:"0.2.0",
		category:"property",
		type:"array",
		index:"integer",
	} **/
	_netClassByPropId: null,
	
	/** _netPropByPropId - An array containing data about network property ids and the properties
	they map to (internal use). {
		engine_ver:"0.2.0",
		category:"property",
		type:"array",
		index:"integer",
	} **/
	_netPropByPropId: null,
	
	/** init - The constructor for this class. {
		category:"method",
		return: {
			type:"object",
			desc:"Returns a new instance of this class",
		},
		argument: {
			type:"object",
			name:"engine",
			desc:"The active engine instance.",
			instanceOf:"IgeEngine",
		},
	} **/
	init: function (engine) {
		this._className = 'IgeNetwork';
		
		this.ige = engine;
		this.engine = engine; // Legacy engine object
		this.engine.network = this;
		this.netProps = new IgeEnum();
		
		/* CEXCLUDE */
		if (this.engine.isServer && typeof(BISON) != 'undefined') {
			this.bison = BISON;
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer && typeof(window.BISON) != 'undefined') {
			this.bison = window.BISON;
		}
		
		// Set internal variable init values
		this.io = this.io || [];
		this._commandList = new IgeEnum();
		this._manifest = new IgeEnum();
		this._requests = [];
		this._dataRecv = [];
		this._dataRecvAll = 0;
		this._dataSend = [];
		this._dataSendAll = 0;
		this._floatPrecision = 2; // The number of decimal places a float will be fixed to over the network
		
		// Register some global network commands
		this._commandList.add([
			'clientConnect',
			'clientReady',
			'clientDisconnect',
			'clientRequest',
			'serverResponse',
			'worldStreamUpdate'
		]);
		
		if (!this.engine.isServer) {
			// Register a listener against this class for stream delta messages
			this.on('worldStreamUpdate', this.bind(this._worldStreamUpdate));
		}
		
		this.netProps2 = {
			'_wa': null,
			'_wx': null,
			'_wy': null,
			'entity_id': null,
		};		
	},
	
	/** registerCommand - Register a client / server network command. {
		category:"method",
		engine_ver:"0.1.2",
		arguments: [{
			type:"object",
			name:"commandName",
			desc:"The name of the command to register.",
		}, {
			type:"method",
			name:"callback1",
			desc:"When only callback1 is specified, this is the callback method to fire when the network command is received by the engine on either client or server. When callback1 and callback2 are specified together, callback1 will be fired when this network command is received on the client and callback2 will be fired when received on the server.",
		}, {
			type:"method",
			name:"callback2",
			desc:"When callback1 and callback2 are specified together, callback1 will be fired when this network command is received on the client and callback2 will be fired when received on the server.",
			flags:"optional",
		}],
	} **/
	registerCommand: function (commandName, callback1, callback2) {
		// Check that the command does not already exist
		if (typeof this._commandList[commandName] == 'undefined') {
			this._commandList.add([commandName]);
			
			// Check what mode we're in (1 callback is standard, 2 means client/server)
			if (callback2 == null) {
				// Standard mode
				if (typeof callback1 == 'function') { this.on(commandName, callback1, this); }
			} else {
				// Client-server mode
				if (!this.engine.isServer) {
					// Callback 1 is client-side
					if (typeof callback1 == 'function') { this.on(commandName, callback1, this); }
				} else {
					// Callback 2 is server-side
					if (typeof callback2 == 'function') { this.on(commandName, callback2, this); }
				}
			}
		} else {
			this.log('An attempt to register network command "' + commandName + '" failed because a command by the same name has already been registered.', 'warning');
		}
	},
	
	/** start - On a client, will start client networking. On the server, will start the file server and then the game server. {
		category:"method",
		engine_ver:"0.1.0",
	} **/
	start: function () {
		/* CEXCLUDE */
		if (this.engine.isServer) {
			this.log('Starting server...');
			this.emit('serverStarting');
			
			//this.startFileServer(this.bind(function () {
				this._start(this.bind(function () {
					// Tell listeners that the entire server has started
					this.emit('serverStarted');
				}));
			//}));
		}
		/* CEXCLUDE */
		
		if (!this.engine.isServer) {
			this.log('Starting networking for the client...');
			this._start();
		}		
	},
	
	/** getNetIdFromProp - Returns the integer id of the class + property name string.
	Used to map class and property names to an integer id for use when communicating
	changes across the network with efficient packet data. {
		category:"method",
		engine_ver:"0.2.0",
		return: {
			type:"integer",
			desc:"Returns a unique integer value that represents the class and property provided.",
		},
		arguments: [{
			type:"string",
			name:"className",
			desc:"The name of the class that the item properties belong to. This is usually the value stored in this._className.",
		}, {
			type:"array",
			name:"propName",
			desc:"The property name to return an id for.",
			index:"integer",
		}],
	} **/	
	getNetIdFromProp: function (className, propName) {
		return this.netProps[className + '_' + propName];
	},
	
	/** getNetPropFromId - Returns the string name of the network property id given. Used to
	map network property ids to a string. {
		category:"method",
		engine_ver:"0.2.0",
		return: {
			type:"array",
			desc:"Returns an array containing two string items in this format - [0] = class name [1] = property name.",
		},
		arguments: [{
			type:"string",
			name:"className",
			desc:"The name of the class that the item properties belong to. This is usually the value stored in this._className.",
		}, {
			type:"array",
			name:"propName",
			desc:"The property name to return an id for.",
			index:"integer",
		}],
	} **/	
	getNetPropFromId: function (netPropId) {
		return [this._netClassByPropId[netPropId], this._netPropByPropId[netPropId]];
	},
	
	/** registerNetProps - Registers properties of a class item that are to be monitored and propagated
	across the network when they change. The propArray argument must be an array regardless of if you
	are registering one property or multiple properties. {
		category:"method",
		engine_ver:"0.2.0",
		arguments: [{
			type:"string",
			name:"className",
			desc:"The name of the class that the item properties belong to. This is usually the value stored in this._className.",
		}, {
			type:"array",
			name:"propArray",
			desc:"An array of property names to register as networked properties.",
			index:"integer",
		}],
	} **/
	registerNetProps: function (className, propArray) {
		// Append the class name to the property array items
		for (var i in propArray) {
			propArray[i] = className + '_' + propArray[i];
		}
		
		// Add the properties to the netProps enum
		this.netProps.add(propArray);
		
		// Register the class name that the properties belong to for reverse lookup
		this._netClassByPropId = this._netClassByPropId || [];
		this._netPropByPropId = this._netPropByPropId || [];
		for (var i in propArray) {
			var netPropId = this.getNetIdFromProp(className, propArray);
			this._netClassByPropId[netPropId] = className;
			this._netPropByPropId[netPropId] = propArray[i];
		}
	},
	
	/** allowConnections - Sets the internal flag that determines if files and client connections
	are served or not. If passed true this will turn serving on, passing false will turn it off. {
		category:"method",
		engine_ver:"0.2.0",
		arguments: [{
			type:"bool",
			name:"setting",
			desc:"True or false to determine if the server will accept client and file request connections.",
		}],
	} **/
	allowConnections: function (setting) {
		this._serveClients = setting;
	},
	
	/** setProvider - Sets the provider who's properties and methods will
	be absorbed by this class. {
		category:"method",
		return:{
			type:"bool",
			desc:"Returns true on success and false on failure.",
		},
		arguments:[{
			name:"provider",
			type:"string",
			desc:"The name of the provider to use for networking.",
			valueOf: {
				'offline': {
					type:"string",
					desc:"Disable multiplayer / networking.",
				},
				'socketio': {
					type:"string",
					desc:"Use the socket.io network library provider.",
				},
				'pusher': {
					type:"string",
					desc:"Use the pusher (www.pusher.com) network library provider.",
				},
			},
		}],
	} **/
	setProvider: function (provider) {
		this.log('Selecting new provider "' + provider + '"...');
		if (this.networkProvider) {
			// A network provider is already in place
			this.log('An existing provider is already in place, removing: ' + this.networkProvider);
		}
		
		if (typeof(this.io[provider]) == 'object' && typeof(this.io[provider].classMethod) == 'function') {
			this.log('Provider found, absorbing provider...');
			this.absorbClass(this.io[provider].classMethod.prototype);
			if (this.networkProvider) {
				this.log('Provider "' + this.networkProvider + '" absorbed successfully!');
				return true;
			} else {
				this.log('Error absorbing provider class properties!', 'error');
				return false;
			}
		} else {
			this.log('Cannot select provider "' + provider + '" because it does not exist.', 'error');
			return false;
		}
	},
	
	// Sets use manifest flag to true or false
	useManifest: function (flag) {
		this.log('Use manifest lookup to compress network packets: ' + flag);
		this._manifestEnabled = flag;
	},
	
	addToManifest: function (name) {
		if (typeof(name) == 'string') {
			if (name.length > 0) {
				// The add method of IgeEnum expects an array even for one value so give it one
				this._manifest.add([name]);
			}
		} else {
			// Add the array of names to the IgeEnum manifest
			this._manifest.add(name);
		}
	},
	
	showManifestTargets: function (threshold) {
		var finalTargetList = [];
		if (!threshold) { threshold = 2; }
		for (var i in this._nonCompressed) {
			if (this._nonCompressed[i] >= threshold) {
				finalTargetList.push(i);
			}
		}
		return finalTargetList;
	},
	
	useStats: function (flag) {
		this.log('Record network transfer stats: ' + flag);
		this._statsEnabled = flag;
		
		if (flag) {
			for (var i = 0; i < 60; i++) {
				this._dataRecv[i] = 0;
				this._dataSend[i] = 0;
			}
		}
	},
	
	disableNetworking: function () {
		// Since the user doesn't want networking simply emit the provider ready and up
		// events without actually loading the provider. This will bypass all networking
		// code but allow systems that rely on provider events to still function correctly
		this.emit('networkProviderReady');
		this.emit('networkProviderUp');
	},
	
	/** setStreamInterval - Sets the interval by which updates to the game world are packaged
	and transmitted to connected clients. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"ms",
			type:"integer",
			desc:"The number of miliseconds between stream messages.",
		}],
	} **/
	setStreamInterval: function (ms) {
		this.log('Setting delta stream interval to ' + ms + 'ms');
		this._streamInterval = ms;
	},
	
	/** setStreamRenderLatency - Sets the amount of miliseconds in the past that the renderer will
	show updates from the stream. This allows us to interpolate from a previous position to
	the next position in the stream update. Updates come in and are already in the past when
	they are received so we need to set this latency value to something greater than the highest
	level of acceptable network latency. Usually this is a value between 100 and 200ms. If your
	game requires much tighter latency you will have to reduce the number of players / network
	updates / data size in order to compensate. A value of 100 in this call is the standard
	that most FPS games accept as normal render latency and should be OK for your game. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"ms",
			type:"integer",
			desc:"The number of miliseconds in the past that stream updates will be applied to world items.",
		}],
	} **/
	setStreamRenderLatency: function (latency) {
		this._renderLatency = latency;
	},
	
	/** startStream - Starts the stream of world updates to connected clients. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	startStream: function () {
		this.log('Starting delta stream...');
		this._streamTimer = setInterval(this.bind(this._updateNetwork), this._streamInterval);
	},
	
	/** stopStream - Stops the stream of world updates to connected clients. {
		category:"method",
		engine_ver:"1.0.0",
	} **/	
	stopStream: function () {
		this.log('Stopping delta stream...');
		clearInterval(this._streamTimer);
	},
	
	/** _updateNetwork - Loops world items and calls network update methods to send
	updates about the world across the network. {
		category:"method",
		engine_ver:"1.0.0",
	} **/
	_updateNetwork: function () {
		// Loop the entities and send updates
		var entityArray = this.engine.entities.byIndex;
		var count = entityArray.length;
		var updateData = '';
		
		while (count--) {
			var pItem = entityArray[count];
			if (pItem.entity_net_mode == NET_MODE_FREE_MOTION) {
				//if (updateData.length) { updateData += '|'; }
				var tempData = this._compileStreamUpdate(pItem);
				if (typeof(tempData) != 'undefined') {
					updateData += tempData + '|';
				}
			}
		}
		
		if (updateData.length) {
			updateData = String(new Date().getTime()) + updateData;
			this.send('worldStreamUpdate', updateData, null, null, true);
		}
	},
	
	/** _compileStreamUpdate - Packages items into JSON and compares their current state
	with the previous state. If the states are different the state is sent over the
	network to update connected clients with new data. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item whose data will be used when sending data.",
		}],
	} **/
	_compileStreamUpdate: function (pItem) {
		var newDataJson = '';
		
		// Copy the relevant data from the entity
		//var newData = this.copyDeep(pItem, this.netProps2);
		if (typeof (pItem.entity_id) != 'undefined' &&
			typeof (pItem._transform) != 'undefined') {
			
			var newData = pItem.entity_id + ',' + 
				// translate
				pItem._transform[0].toFixed(this._floatPrecision) + ',' + // x
				pItem._transform[1].toFixed(this._floatPrecision) + ',' + // y
				//pItem._transform[2].toFixed(this._floatPrecision) + ',' + // z
				// scale
				pItem._transform[3].toFixed(this._floatPrecision) + ',' + // x
				pItem._transform[4].toFixed(this._floatPrecision) + ',' + // y
				//pItem._transform[5].toFixed(this._floatPrecision) + ',' + // z
				// rotate
				pItem._transform[6].toFixed(this._floatPrecision) + ',' + // x
				//pItem._transform[7].toFixed(this._floatPrecision) + ',' + // y
				//pItem._transform[8].toFixed(this._floatPrecision) + ',' + // z
				// origin
				pItem._transform[9].toFixed(this._floatPrecision) + ',' + // x
				pItem._transform[10].toFixed(this._floatPrecision) + ',' + // y
				//pItem._transform[11].toFixed(this._floatPrecision) + ',' + // z
				// opacity
				pItem._transform[12].toFixed(this._floatPrecision); // + ',' + // x
				//pItem._transform[13].toFixed(this._floatPrecision) + ',' + // x
				//pItem._transform[14].toFixed(this._floatPrecision); // x
			
			newDataJson = newData;
			
			// Check if the current entity data is different from the previous
			if (pItem._lastUpdJson != newDataJson) {
				// Entity data is different so send an update
				pItem._sentLastUpdate = false;
				pItem._lastUpdJson = newDataJson;
				
				return newDataJson;
			} else {
				// The data is not different, check if we've sent the last update packet
				// This packet sends the same data as the last update had which lets the
				// renderer know that the entity position is now static
				if (!pItem._sentLastUpdate) {
					// We haven't sent the last update packet so send it
					pItem._sentLastUpdate = true;
					return newDataJson;
				}
			}
		} else {
			return '';
		}
	},
	
	/** _worldStreamUpdate - Called when a new world stream update has been
	received by the engine. These updates carry changes to the world's entity
	transform data and are used by the entity interpolation system to alter
	the current transform of an entity to the target based upon the current
	render time. {
		category:"method",
		engine_ver:"1.0.0",
		arguments:[{
			name:"pItem",
			type:"object",
			desc:"The item whose data will be used when sending data.",
		}],
	} **/
	_worldStreamUpdate: function (data) {
		// Read the packet data into variables
		var clientTime = new Date().getTime();
		var time = parseInt(data.substr(0, 13)); // Timestamps are currently 13 chars long - will this change?
		data = data.slice(13);
		
		var entityMsgArray = data.split('|');
		var count = entityMsgArray.length;
		var dataItem = null, finalDataObject = {};
		
		while (count--) {
			finalDataObject = {};
			dataItem = entityMsgArray[count].split(',');
			var entity = this.engine.entities.byId[dataItem[0]];
			if (entity) {
				// Only add the update to the queue if it was sent after
				// the latest update time
				if (!entity._latestUpdate) { entity._latestUpdate = 0; }
				if (typeof(entity._targetData) == 'undefined') { entity._targetData = []; }
				if (entity._latestUpdate < time) {
					finalDataObject._transform = [];
					// translate
					finalDataObject._transform[0] = parseFloat(dataItem[1]);
					finalDataObject._transform[1] = parseFloat(dataItem[2]);
					// scale
					finalDataObject._transform[3] = parseFloat(dataItem[3]);
					finalDataObject._transform[4] = parseFloat(dataItem[4]);
					// rotate
					finalDataObject._transform[6] = parseFloat(dataItem[5]);
					// origin
					finalDataObject._transform[9] = parseFloat(dataItem[6]);
					finalDataObject._transform[10] = parseFloat(dataItem[7]);
					// opacity
					finalDataObject._transform[12] = parseFloat(dataItem[8]);
					
					// We add this.engine.time.serverTimeDiff to the packet's time to convert
					// from the server's clock time to the clients
					entity._targetData.push([time + this.engine.time.totalServerToClientClockLatency, finalDataObject]);
					entity._nextTarget = new Date().getTime() + this._streamInterval;
				}
			}
		}
	},
	
	// copies data from objects, using the netProps array and returns an array
	// with only those properties in it, whose values are copied from the original
	// object
	copyDeep: function (obj, netProps) {
		var newObj = {};
		if (!netProps) { netProps = obj; }
		
		for (var i in netProps) {
			var prop = obj[i];
			
			switch (typeof(prop)) {
				case 'object':
					newObj[i] = this.copyDeep(prop);
				break;
				case 'function':
				break;
				default:
					newObj[i] = prop;
				break;
			}
		}
		return newObj;
	},
	
	setNetFloatPrecision: function (val) {
		this._floatPrecision = val;
	},
	
});