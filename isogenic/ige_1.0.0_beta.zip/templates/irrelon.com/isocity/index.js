// Your game code goes that runs on both client AND server goes inside this class
Game = new IgeClass({
	ige: null,
	client: null,
	server: null,
	version: '0.0.1',
	
	init: function (engine, client, server) {
		this._className = 'Game';
		this.ige = engine;
		this.client = client;
		this.server = server;
	},
	
	///////////////////////////////////////////////////////////////////////////////////////////
	// START OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	networkInit: function () {
		this.log('networkInit');
		
		this.ige.network.useBison(false);
		this.ige.network.useManifest(true);
		this.ige.network.setProvider('socketio');
		this.ige.network.debug = false;
		
		switch (this.ige.network.networkProvider) {
			case 'offline':
				this.ige.network.providerInit();
			break;
			
			case 'socketio':
				if (this.ige.isServer) {
					this.ige.network.providerInit();
					this.ige.network.start();
				}
				if (!this.ige.isServer) { // If the engine is running as a client...
					this.ige.network.setOptions({
						gameServer:'http://isocity-io1.gamehost.isogenicengine.com:80', // Set the game server url
						//gameServer:'http://dev-io1.isocity.co.uk:80', // Set the game server url
						reconnect: false, // Tell the client not to reconnect automatically
					});
					this.ige.network.useStats(true); // Tell the networking system to keep stats data for debug
					this.ige.network.providerInit(); // Initialise the network provider
				}
			break;
			
			case 'pusher':
				if (this.ige.isServer) {
					this.ige.network.setOptions({
						key: '',
						secret: '',
						app_id: 0,
						debug: false,
					});
					this.ige.network.providerInit();
					this.ige.network.start();
				}
				
				if (!this.ige.isServer) {
					this.ige.network.setOptions({
						key: '',
						host:'ws.darling.pusher.com',
						port:'80',
						sslPort:'443',
					});
					this.ige.network.useStats(true);
					this.ige.network.providerInit();
				}
			break;
		}
		
		// Add a load of manifest data to speed up networking
		this.ige.network.addToManifest([
			'bakery1',
			'bakery1Iso',
			'bank1',
			'bank1Iso',
			'burgerShop1',
			'burgerShop1Iso',
			'butcherShop1',
			'butcherShop1Iso',
			'cdStore1',
			'cdStore1Iso',
			'casino1',
			'casino1Iso',
			'clothesStore1',
			'clothesStore1Iso',
			'clothesStore2',
			'clothesStore2Iso',
			'coffeeShop1',
			'coffeeShop1Iso',
			'factory1',
			'factory1Iso',
			'hospital1',
			'hospital1Iso',
			'house1',
			'house1Iso',
			'house2',
			'house2Iso',
			'newsAgent1',
			'newsAgent1Iso',
			'office1',
			'office1Iso',
			'pizza1',
			'pizza1Iso',
			'restaurant1',
			'restaurant1Iso',
			'shoeStore1',
			'shoeStore1Iso',
			'stadium1',
			'stadium1Iso',
			'tower2',
			'tower2Iso',
			'travelAgent1',
			'travelAgent1Iso',
			'grassBackground',
			'road',
			'roadSheet',
			'womanWalk',
			'woman_sheet2',
			'tilePavement',
			'dirtSheet',
			'mapView',
			'testMap1',
		]);
	},
	
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.engineHooks();
		}
		/* CEXCLUDE */
		if (!this.ige.isServer) {
			this.client.engineHooks();
		}
	},
	
	// This is called when the engine wants you to register all your network commands
	networkCommands: function () {
		////////////////////////////////////////////////
		// Create some game specific network commands //
		////////////////////////////////////////////////
		this.ige.network.registerCommand('hardRefreshGame');
		this.ige.network.registerCommand('requestLogin');
		this.ige.network.registerCommand('clientLoggedIn');
		this.ige.network.registerCommand('entityCount');
		this.ige.network.registerCommand('allDone');
		this.ige.network.registerCommand('placeItemFailed');
		this.ige.network.registerCommand('moveItemFailed');
		this.ige.network.registerCommand('deleteItemFailed');
		this.ige.network.registerCommand('assetsLoaded');
			
		this.ige.network.registerCommand('gameData');
		this.ige.network.registerCommand('reconnect');
		this.ige.network.registerCommand('placeItem');
		this.ige.network.registerCommand('moveItem');
		this.ige.network.registerCommand('deleteItem');
	},
	
	// This is called when the engine wants you to load all your modules
	modules: function () {
		new IgeFacebook(this.ige);
	},
	
	// This is called when the engine wants you to hook module events
	moduleHooks: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.moduleHooks();
		}
		/* CEXCLUDE */
	},
	
	// This is called when the engine wants you to load all your data
	data: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.data();
		}
		/* CEXCLUDE */
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.ready();
		}
		/* CEXCLUDE */
		
		if (!this.ige.isServer) {
			this.client.ready();
		}
	},
	///////////////////////////////////////////////////////////////////////////////////////////
	// END OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	
	_hardRefreshGame: function () {
		this.client._hardRefreshGame.apply(this.client, arguments);
	},
	
	_requestLogin: function () {
		this.client._requestLogin.apply(this.client, arguments);
	},
	
	_clientLoggedIn: function () {
		this.client._clientLoggedIn.apply(this.client, arguments);
	},
	
	_entityCount: function () {
		this.client._entityCount.apply(this.client, arguments);
	},
	
	allDone: function () {
		this.client.allDone.apply(this.client, arguments);
	},
	
	_placeItemFailed: function () {
		this.client._placeItemFailed.apply(this.client, arguments);
	},
	
	_moveItemFailed: function () {
		this.client._moveItemFailed.apply(this.client, arguments);
	},
	
	_deleteItemFailed: function () {
		this.client._deleteItemFailed.apply(this.client, arguments);
	},
	
	_assetsFinishedStream: function () {
		this.client._assetsFinishedStream.apply(this.client, arguments);
	},
	
	// Server
	_gameData: function () {
		this.server._gameData.apply(this.server, arguments);
	},
	
	_clientReconnect: function () {
		this.server._clientReconnect.apply(this.server, arguments);
	},
	
	_clientAssetsLoaded: function () {
		this.server._clientAssetsLoaded.apply(this.server, arguments);
	},
	
	_placeItem: function () {
		this.server._placeItem.apply(this.server, arguments);
	},
	
	_moveItem: function () {
		this.server._moveItem.apply(this.server, arguments);
	},
	
	_deleteItem: function () {
		this.server._deleteItem.apply(this.server, arguments);
	},
	
});