/* CEXCLUDE */
// Your server-specific code goes in this class
GameServer = new IgeClass({
	ige: null,
	
	init: function (engine) {
		this._className = 'GameServer';
		this.ige = engine;
		
		// Check if we have a network
		if (this.ige._IgeNetwork) {
			// Call the networkInit method of this class
			this.networkInit();
		}
	},
	
	networkInit: function () {
		return true;
	},
	
	///////////////////////////////////////////////////////////////////////////////////////////
	// START OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	engineHooks: function () {
		// Network events
		this.ige.network.on('clientConnect', this.bind(this.clientConnect));
		this.ige.network.on('clientDisconnect', this.bind(this.clientDisconnect));
		
		this.ige.network.on('assetsLoaded', this.bind(this._clientAssetsLoaded));
		this.ige.network.on('gameData', this.bind(this._gameData));
		this.ige.network.on('reconnect', this.bind(this._clientReconnect));
		this.ige.network.on('placeItem', this.bind(this._placeItem));
		this.ige.network.on('moveItem', this.bind(this._moveItem));
		this.ige.network.on('deleteItem', this.bind(this._deleteItem));
	},
	
	moduleHooks: function () {
		this.ige.facebook.on('loggedIn', this.bind(this._clientLogin));
	},
	
	modules: function () {
		// Ask the engine to load the modules we want to use
		//this.ige.includeModule('IgeFacebook');
		//this.ige.includeModule('IgeSound');
	},
	
	// This is called when the engine wants you to load all your data
	data: function () {
		this.ige.loadData({
			'templates':{},
			'screens':{},
			'animations':{},
			'assets':{},
			'users':{},
			'entities':{}
		});
		
		this.setupWorldData();
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		// Setup out world in script
		this.setupWorld();
		
		//this.ige.entities.saveEntityDataAsJson('testMap1', '/client/testMap1');
		
		// Set the server to allow client connections
		this.ige.network.allowConnections(true);
	},
	
	///////////////////////////////////////////////////////////////////////////////////////////
	// END OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	
	// Called when the clientConnect event is fired by the network class
	clientConnect: function (sessionId) {
		this.log('-----------------------------------------------------');
		this.log('Client Connected with session: ' + sessionId);
		this.log('-----------------------------------------------------');
		
		// Create client object storage
		this.igeStore = this.igeStore || [];
		this.igeStore[sessionId] = this.igeStore[sessionId] || {};
	},
	
	_clientReconnect: function () {
		this.log('A client is trying to reconnect from a lost connection');
		
		// Send the client a message telling them to do a complete refresh
		this.ige.network.send('hardRefreshGame');
	},
	
	_gameData: function (data, sessionId) {
		this.log('Client requesting game data...');
		if (!this.igeStore[sessionId]._clientAssetsLoaded) {
			// Send the client all the game data that all clients require
			// when all the client's assets have loaded the _clientAssetsLoaded
			// will be called
			this.log('Sending all game data to client...');
			this.ige.templates.netSendAll(sessionId);
			
			if (this.ige.assets.byIndex.length) {
				this.ige.assets.netSendAll(sessionId);
				this.ige.network.send('assetsLoaded', null, sessionId);
			} else {
				this.ige.network.send('assetsLoaded', null, sessionId);
				this._clientAssetsLoaded({}, sessionId);
			}
		} else {
			this.log('Client ' + sessionId + ' is requesting game data but has already been sent it, telling client to refresh browser.');
			this.ige.network.send('hardRefreshGame');
		}
	},
	
	_clientAssetsLoaded: function (data, sessionId) {
		// Mark this client as having received the startup objects
		// which will stop subsequent "assetsLoaded" events from sending
		// all this data again
		this.igeStore[sessionId]._clientAssetsLoaded = true;
		
		this.log('Sending camera data...');
		this.ige.cameras.netSendAll(sessionId);
		this.ige.animations.netSendAll(sessionId);
		this.ige.screens.netSendAll(sessionId);
		this.ige.maps.netSendAll(sessionId);
		this.ige.viewports.netSendAll(sessionId);
		
		// Ask the client to display the login screen
		this.log('Asking client to display login screen');
		this.ige.network.send('requestLogin', null, sessionId);
	},
	
	_clientLogin: function (data, sessionId) {
		this.log('Client Facebook login success');
		
		var details = data.details;
		
		var userData = {
			user_id: details.id,
			user_first_name: details.first_name,
			user_last_name: details.last_name,
			user_profile_link: details.link,
			user_username: details.username,
			user_birthday: details.birthday,
			user_gender: details.gender,
			user_email: details.email,
			user_timezone: details.timezone,
			user_geo_locale: details.locale,
			user_first_name: details.first_name,
			user_locale: LOCALE_SERVER_ONLY + LOCALE_DB,
			user_persist: true,
			user_logged_in: true,
			session_id: sessionId
		};
		
		var tempUser = this.ige.users.read(userData);
		
		if (!tempUser) {
			// This is a new user so give them some cash!
			userData.cashBalance = 5000;
			
			this.ige.users.create(userData, this.bind(function (user) {
				if (user) {
					this.log('User created successfully', 'log', user);
					this.ige.network.send('clientLoggedIn', null, sessionId);
					this.clientLoggedIn(sessionId);
				} else {
					this.log('User didnt create', 'error', user);
				}
			}));
		} else {
			// The user already exists, update the user's session and logon status
			this.log('User for this Facebook login already exists in the database... updating entry...');
			
			this.ige.users.update(tempUser.user_id, {session_id:sessionId, user_logged_in: true}, this.bind(function (data) {
				this.ige.network.send('clientLoggedIn', null, sessionId);
				this.clientLoggedIn(sessionId);
			}));
		}
	},
	
	// Client logged in
	clientLoggedIn: function (sessionId) {
		// Send all the required game data to the client engine
		this.ige.backgrounds.netSendAll(sessionId);
		
		this.ige.network.send('entityCount', this.ige.entities.byIndex.length, sessionId);
		this.ige.entities.netSendAll(sessionId);
		
		// Switch to the loading screen
		this.ige.screens.setCurrent('mapView', sessionId);
		
		// Tell the client to start engine
		this.ige.startClient(sessionId);
		
		// Tell all clients to add this client
		this.ige.network.send('clientConnect', null, sessionId);
		
		// Tell the client it is ready to run!
		this.ige.network.send('allDone', null, sessionId);
	},
	
	// What to do when a client disconnects
	clientDisconnect: function (sessionId) {
		// Tell all clients to remove this client and it's associated non-persistent stuff
		this.ige.network.send('clientDisconnect', sessionId);
		
		// Remove all the stuff from the server engine data
		this.ige.entities.removeBySearch({session_id:sessionId});
		
		// Remove any non-persistent entities for the disconnecting client
		this.ige.database.remove('entity', {entity_persist:PERSIST_DISABLED, session_id:sessionId});
		
		// Remove client from users
		var tempUser = this.ige.users.readBySessionId(sessionId);
		if (tempUser && tempUser.user_id) {
			this.ige.users.update(tempUser, {user_logged_in: false}, this.bind(function (data) {
				this.log('User successfully logged out and DB updated: ' + tempUser.user_id);
			}));
		}
	},
	
	/* _placeItem - Client has sent a request to place an item. */
	_placeItem: function (data, sessionId) {
		/* Psuedo-code of method
		1: Retrieve the cost for this placement
		2: Check if the player has enough money to make this placement
		3: If yes
			1: Deduct the money from the player's cash
			2: Create the placement entity
		4: If no
			1: Send network message back to client rejecting the placement
		*/
		var user = this.ige.users.readBySessionId(sessionId);
		
		if (user && user.user_id) {
			var placeX = data[0];
			var placeY = data[1];
			var templateId = data[2];
			var sheetId = data[3];
			
			// Apply the template to a dummy object to get basic properties
			var dummyEntity = {};
			this.ige.templates.applyTemplate(dummyEntity, templateId);
			
			// Check that the placement is not blocked
			if (!this.ige.maps.isTileBlocked('testMap1', placeX, placeY, 0, dummyEntity.map_tile_width, dummyEntity.map_tile_height)) {
				// Retrieve the cost for this placement
				var cost = 10;
				
				// Check if the player has enough money to make this placement
				var money = user.cashBalance || 0;
				
				if (money >= cost) {
					// Deduct the money from the player's cash
					money -= cost;
					user.cashBalance = money;
					
					// Update the database with the new money value
					this.ige.users.update(user, {cashBalance: money});
					
					// Create the entity
					this.ige.entities.create({
						template_id: templateId,
						entity_transform: {
							translate: [placeX, placeY, 0, false, true],
						},
						entity_locale: LOCALE_EVERYWHERE + LOCALE_DB,
						entity_persist: PERSIST_ENABLED,
						asset_sheet_frame: sheetId,
						map_id: 'testMap1',
						user_id: user.user_id,
						propagate_trace: false,
						entity_net_mode: NET_MODE_FREE_MOTION,
					}, this.bind(function (entity) {
						if (entity) {
							//this.log('New placed item created');
						} else {
							this.log('Placed item failed to create');
						}
					}));
				} else {
					// The user doesn't have enough money to build this item!
					this.log('Not enough cash!');
					user.cashBalance = 5000;
					this.ige.users.update(user, {cashBalance: user.cashBalance});
				}
			} else {
				// Invalid placement, blocked by existing entity
				this.log('Invalid placement!');
			}
		} else {
			this.log('Cannot place item because user is invalid for session ' + sessionId, 'warning', user);
		}
	},
	
	/* _moveItem - Client has sent a request to move an item. */
	_moveItem: function (data, sessionId) {
		var user = this.ige.users.readBySessionId(sessionId);
		//console.log('Move action requested from ' + sessionId, data);
		if (user && user.user_id) {
			var itemId = data[0];
			var placeX = data[1];
			var placeY = data[2];
			
			var entity = this.ige.entities.read(itemId);
			
			// Check that we found an entity and that the entity is owned by the user
			if (entity && entity.entity_id && entity.user_id == user.user_id) {
				if (!this.ige.entities.isEntityTileBlocked(entity, placeX, placeY, 0)) {
					// Move the entity
					//console.log('Moving entity', entity, placeX, placeY);
					entity.entity_net_mode = NET_MODE_FREE_MOTION;

					this.ige.entities.translate(entity, placeX, placeY, 0, false, true);
					delete entity.propagate_trace;
					
					// Update the entity in the database
					this.ige.entities.update(entity);
				} else {
					// Send a move failure command to the client
					console.log('Cannot move entity, target position occupied!', entity, user);
				}
			} else {
				// Send a move failure command to the client
				console.log('Cannot move entity!', entity, user);
			}
		} else {
			// User is not logged in to the game
			console.log('Attempt to move entity from non-logged in user', user, data, sessionId);
		}
	},
	
	/* _deleteItem - Client has sent a request to delete an item. */
	_deleteItem: function (data, sessionId) {
		var user = this.ige.users.readBySessionId(sessionId);
		
		if (user && user.user_id) {
			var itemId = data[0];
			
			var entity = this.ige.entities.read(itemId);
			
			// Check that we found an entity and that the entity is owned by the user
			if (entity && entity.entity_id && entity.user_id == user.user_id) {
				// Delete the entity
				this.ige.entities.remove(entity);
			} else {
				// Send a delete failure command to the client
				//this.log('Delete failed!');
			}			
		} else {
			this.log('Attempted to delete object not owned by this player', 'info', [data, entity, user]);
		}
	},
	
	setupWorldData: function () {
		this.ige.assets.create({
			"asset_id" : "roadSheet",
			"asset_image_url" : "./assets/tiles/roadSheet.png",
			"asset_sheet_enabled" : true,
			"asset_anchor_points" : [ [50, 12 ] ],
			"asset_sheet_width" : 9,
			"asset_sheet_height" : 1,
			"asset_render_mode" : ASSET_RENDER_MODE_ISOMETRIC,
			"asset_locale" : LOCALE_EVERYWHERE,
			"asset_persist" : PERSIST_DISABLED
		});
		
		this.ige.assets.create({
			"asset_id" : "dirtSheet",
			"asset_image_url" : "./assets/tiles/dirtSheet.png",
			"asset_sheet_enabled" : true,
			"asset_anchor_points" : [ [ 50, 25 ] ],
			"asset_sheet_width" : 4,
			"asset_sheet_height" : 1,
			"asset_render_mode" : ASSET_RENDER_MODE_ISOMETRIC,
			"asset_locale" : LOCALE_EVERYWHERE,
			"asset_persist" : PERSIST_DISABLED
		});			

		this.ige.assets.create({
			"asset_id" : "woman_sheet2",
			"asset_image_url" : "./assets/people/woman_sheet2_small.png",
			"asset_sheet_enabled" : true,
			"asset_sheet_width" : 9,
			"asset_sheet_height" : 8,
			"asset_anchor_points" : [ [ 24, 80 ] ],
			"asset_render_mode" : ASSET_RENDER_MODE_ISOMETRIC,
			"asset_locale" : LOCALE_EVERYWHERE,
			"asset_persist" : PERSIST_DISABLED,
			"asset_scale" : 0.3
		});
		
		/*
		this.ige.assets.create({
			asset_id : "grassBackground",
			asset_image_url : "./assets/backgrounds/grassLarge.png",
			asset_sheet_enabled : false,
			asset_anchor_points : [ 
			[ 600, 15 ] ],
			asset_render_mode : ASSET_RENDER_MODE_2D,
			asset_locale: LOCALE_EVERYWHERE,
			asset_persist : PERSIST_DISABLED
		});
		*/
		
		this.ige.assets.create({
			asset_id : "grassRepeat",
			asset_image_url : "./assets/backgrounds/grassRepeat.png",
			asset_sheet_enabled : false,
			asset_anchor_points : [ [ 600, 15 ] ],
			asset_render_mode : ASSET_RENDER_MODE_2D,
			asset_locale: LOCALE_EVERYWHERE,
			asset_persist : PERSIST_DISABLED
		});
		
		/*
		this.ige.templates.create({
			template_id: 'grassBackground',
			template_contents: {
				entity_type:ENTITY_TYPE_BACKGROUND,
				entity_layer:0,
				entity_transform: {
					scaleTarget: [20, 20, 0, true], // scale to target size
				},
				map_block: MAP_NOBLOCK_NOCHECK,
				asset_id: 'grassBackground',
				map_id: 'testMap1',
			},
		});
		*/
		
		this.ige.templates.create({
			template_id: 'tilePavement',
			template_contents: {
				entity_type:ENTITY_TYPE_TILE,
				entity_layer:1,
				entity_transform: {
					scaleTarget: [1, null, null, true], // scale to target size
				},
				map_block: MAP_BLOCK_CHECK,
				map_tile_width: 1,
				map_tile_height: 1,
				asset_id: 'dirtSheet',
				path_class: ['walk'],
			},
		});
		
		// Create all the data that isn't in the DB at the moment - useful for testing
		this.ige.templates.create({
			template_id: 'road',
			template_contents: {
				entity_type:ENTITY_TYPE_TILE,
				entity_layer:1,
				entity_transform: {
					scaleTarget: [2, null, null, true], // scale to target size
					origin:[0.5, 0.25, 0.5],
				},
				map_block: MAP_BLOCK_CHECK,
				map_tile_width: 2,
				map_tile_height: 2,
				asset_id: 'roadSheet',
				path_class: ['drive'],
				map_id: 'testMap1',
			},
		});			

		// Create a new animation
		this.ige.animations.create({
			animation_id: 'womanWalkS',
			animation_frame_from: 1,
			animation_frame_to: 9,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkSW',
			animation_frame_from: 10,
			animation_frame_to: 18,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkW',
			animation_frame_from: 19,
			animation_frame_to: 27,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkNW',
			animation_frame_from: 28,
			animation_frame_to: 36,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkN',
			animation_frame_from: 37,
			animation_frame_to: 45,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkNE',
			animation_frame_from: 46,
			animation_frame_to: 54,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkE',
			animation_frame_from: 55,
			animation_frame_to: 63,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.animations.create({
			animation_id: 'womanWalkSE',
			animation_frame_from: 64,
			animation_frame_to: 72,
			animation_fps: 9,
			animation_loop: true,
		});
		
		this.ige.templates.create({
			template_id: 'womanWalk',
			template_contents: {
				// Entity stuff
				entity_type:ENTITY_TYPE_SPRITE,
				entity_layer:2,
				entity_transform: {
					scale: [0.35, 0.35, 1, false, false], // scale
					origin: [0.5, 0.9, 0.5, false],
				},
				// Animation stuff
				animation_id: 'womanWalkSE',
				animation_dirty: true,
				// Asset stuff
				asset_sheet_frame:1,
				asset_id: 'woman_sheet2',
				// Map stuff
				map_id: 'testMap1',
			},
		});
		
		// Create splash screen
		this.ige.screens.create({
			screen_id:'splash',
			screen_background_color:'#000',
			screen_html: './html/mainMenu.html',
			screen_persist:PERSIST_DISABLED,
		});
		
		// Create map screen
		this.ige.screens.create({
			screen_id:'mapView',
			screen_background_color:'#000',
			screen_html: '',
			screen_parent_id: 'mainView',
			screen_persist:PERSIST_DISABLED,
		});
		
		// Create map
		this.ige.maps.create({
			map_id:'testMap1',
			map_tilesize:40,
			map_use_dirty:false,
			map_dirty_grid:false,
			map_debug_dirty:false,
			map_debug_entities:false,
			map_dirty_width:150,
			map_dirty_height:150,
			map_render:true,
			map_layers:[
				{
					layer_auto_mode:LAYER_AUTO_NONE,
					layer_type:LAYER_TYPE_HTML,
					layer_entity_types: LAYER_BACKGROUNDS,
					layer_render_mode: RENDER_MODE_2D,
				},
				{
					layer_auto_mode:LAYER_AUTO_NONE, //LAYER_AUTO_CULL + LAYER_AUTO_REQUEST,
					layer_type:LAYER_TYPE_AUTO,
					layer_entity_types: LAYER_TILES,
					layer_render_mode: RENDER_MODE_ISOMETRIC,
					//layer_draw_grid: true,
				},
				{
					layer_auto_mode:LAYER_AUTO_NONE, //LAYER_AUTO_CULL + LAYER_AUTO_REQUEST,
					layer_type:LAYER_TYPE_AUTO,
					layer_entity_types: LAYER_SPRITES,
					layer_render_mode: RENDER_MODE_ISOMETRIC,
				},
				{
					layer_auto_mode:LAYER_AUTO_NONE,
					layer_type:LAYER_TYPE_AUTO,
					layer_entity_types: LAYER_UI,
					layer_render_mode: RENDER_MODE_2D,
				},
			],
			map_persist:PERSIST_DISABLED,
		});
		
		// Create camera
		this.ige.cameras.create({
			camera_id:'mainCam',
			camera_x: 0,
			camera_y: 0,
			camera_z: 0,
			camera_zClipping:{
				near: 0,
				far: 1,
			},
			camera_persist: PERSIST_DISABLED,
		});
		
		// Create viewport
		this.ige.viewports.create({
			viewport_id: 'mainVp',
			viewport_clipping: true,
			/*viewport_background_color:'#005aff',*/
			viewport_anchor_point: [0, 0],
			viewport_autoSize: true,
			viewport_container: { width: 800, height: 600 },
			viewport_locale: LOCALE_EVERYWHERE + LOCALE_DB,
			viewport_persist: PERSIST_DISABLED,
			panLayer:{
				id: 'panLayer',
				padding: 1.0,
				zStart: 0,
			},
			screen_id: 'mapView',
			map_id: 'testMap1',
			camera_id: 'mainCam',
		});
		
		// Create camera
		this.ige.cameras.create({
			camera_id:'cam2',
			camera_x: 0,
			camera_y: 0,
			camera_z: 0,
			camera_zClipping:{
				near: 0,
				far: 1,
			},
			camera_persist: PERSIST_DISABLED,
		});
		
		// Create viewport
		this.ige.viewports.create({
			viewport_id: 'miniVp',
			viewport_tile_ratio: 0.5,
			viewport_clipping: true,
			/*viewport_background_color:'#005aff',*/
			viewport_anchor_point: [0, 0],
			viewport_autoSize: false,
			viewport_container: { width: 400, height: 200 },
			viewport_locale: LOCALE_EVERYWHERE + LOCALE_DB,
			viewport_persist: PERSIST_DISABLED,
			viewport_hide:true,
			panLayer:{
				id: 'panLayer',
				padding: 0,
			},
			screen_id: 'mapView',
			map_id: 'testMap1',
			camera_id: 'cam2',
			css_zindex: 10,
		});
		
		this.createAssetAndTemplate('bakery1', 'iso', [0.5, 0.4], 4, 4, 0.79);
		this.createAssetAndTemplate('bank1', 'iso', [0.49, 0.49], 4, 4, 0.73);
		this.createAssetAndTemplate('burgerShop1', 'iso', [0.45, 0.39], 4, 4, 0.82);
		this.createAssetAndTemplate('butcherShop1', 'iso', [0.50, 0.33], 4, 4, 0.83);
		this.createAssetAndTemplate('cdStore1', 'iso', [0.5, 0.35], 4, 4, 0.82);
		this.createAssetAndTemplate('casino1', 'iso', [0.48, 0.53], 4, 4, 0.86);
		this.createAssetAndTemplate('clothesStore1', 'iso', [0.55, 0.35], 4, 5, 1);
		this.createAssetAndTemplate('clothesStore2', 'iso', [0.53, 0.50], 4, 4, 0.78);
		this.createAssetAndTemplate('coffeeShop1', 'iso', [0.47, 0.4], 4, 4, 0.75);
		this.createAssetAndTemplate('factory1', 'iso', [0.5, 0.339], 6, 6, 1);
		this.createAssetAndTemplate('hospital1', 'iso', [0.5, 0.37], 4, 4, 1);
		this.createAssetAndTemplate('house1', 'iso', [0.43, 0.38], 4, 3, 1);
		this.createAssetAndTemplate('house2', 'iso', [0.5, 0.3], 5, 5, 0.83);
		this.createAssetAndTemplate('newsAgent1', 'iso', [0.7, 0.459], 4, 8, 0.85);
		this.createAssetAndTemplate('office1', 'iso', [0.45, 0.37], 5, 4, 1);
		this.createAssetAndTemplate('pizza1', 'iso', [0.49, 0.38], 4, 4, 0.96);
		this.createAssetAndTemplate('restaurant1', 'iso', [0.55, 0.4], 4, 5, 1);
		this.createAssetAndTemplate('shoeStore1', 'iso', [0.5, 0.53], 4, 4, 0.98);
		this.createAssetAndTemplate('tower2', 'iso', [0.575, 0.627], 3, 4, 1);
		this.createAssetAndTemplate('travelAgent1', 'iso', [0.5, 0.37], 4, 4, 0.97);
	},
	
	setupWorld: function () {
		var gIndex = 0;
		this.ige.backgrounds.create({
			asset_id: 'grassRepeat',
			map_id: 'testMap1',
			background_id: 'g' + gIndex,
			//background_target: 'vpLayer0',
			background_repeat: 'repeat',
			background_offset_x: -400,
			background_offset_y: -10,
			background_cam_speed_x: 1,
			background_cam_speed_y: 1,
			background_layer: LAYER_BACKGROUNDS,
			background_locale: LOCALE_EVERYWHERE,
		});
		
		this.log('+++++++++++++++++++ All data loaded and ready - Engine online +++++++++++++++++++');
	},
	
	createAssetAndTemplate: function (assetId, mode, origin, tileWidth, tileHeight, scale) {
		if (!scale) { scale = 1; }
		switch (mode) {
			case 'iso':
				var fileName = assetId;
				var assetId = assetId + 'Iso';
				var renderMode = ASSET_RENDER_MODE_ISOMETRIC;
			break;
			
			case '2d':
				var fileName = assetId;
				var assetId = assetId + '2d';
				var renderMode = ASSET_RENDER_MODE_2D;
			break;
		}
		
		this.ige.assets.create({
			asset_id: assetId,
			asset_image_url: './assets/buildings/' + fileName + '.png',
			asset_sheet_enabled: false,
			asset_anchor_points: [[0,0]],
			asset_render_mode: renderMode,
			asset_locale: LOCALE_EVERYWHERE,
			asset_persist: PERSIST_DISABLED,
		});
		
		this.ige.templates.create({
			template_id: fileName,
			template_contents: {
				entity_type: ENTITY_TYPE_OBJECT,
				entity_layer: 2,
				entity_transform: {
					scaleTarget: [((tileWidth + tileHeight) / 2 * scale), null, null, true], // scale to target size
					origin: [origin[0], origin[1], 0.5, false],
				},
				map_block: MAP_BLOCK_CHECK,
				map_tile_width: tileWidth,
				map_tile_height: tileHeight,
				asset_id: assetId,
			},
		});
	},
	
});
/* CEXCLUDE */