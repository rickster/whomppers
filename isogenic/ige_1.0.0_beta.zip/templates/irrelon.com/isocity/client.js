// Your client-specific code goes in this class
GameClient = new IgeClass({
	ige: null,
	
	GAME_MM_SELECT: 1,
	GAME_MM_MOVE: 2,
	GAME_MM_DELETE: 3,
	GAME_MM_PLACE: 4,
	GAME_MM_EDIT: 5,
	
	mousePanMode: 0,
	
	init: function (engine) {
		this._className = 'GameClient';
		this.ige = engine;
		
		// Define some UI tool-tip text
		this._tipState = true;
		
		this.tips = [];
		this.tips[0] = [];
		this.tips[0][0] = 'Select Tool';
		this.tips[0][1] = 'Used to select objects';
		
		this.tips[1] = [];
		this.tips[1][0] = 'Move Tool';
		this.tips[1][1] = 'Click an object that you own, then click where you want to move it';
		
		this.tips[2] = [];
		this.tips[2][0] = 'Delete Tool';
		this.tips[2][1] = 'Click an object that you own to delete it';
		
		this.tips[3] = [];
		this.tips[3][0] = 'Pavement Menu';
		this.tips[3][1] = 'Tiles for your little sim people to walk from one place to another';
		
		this.tips[4] = [];
		this.tips[4][0] = 'Road Menu';
		this.tips[4][1] = 'Tiles for road-based transport';
		
		this.tips[5] = [];
		this.tips[5][0] = 'Buildings Menu';
		this.tips[5][1] = 'Houses, offices, shops and stores for your little sim people';
	},
	
	///////////////////////////////////////////////////////////////////////////////////////////
	// START OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	engineHooks: function () {
		// Network events
		this.ige.network.on('serverConnect', this.bind(this.serverConnect));
		this.ige.network.on('serverDisconnect', this.bind(this.serverDisconnect));
		
		this.ige.network.on('hardRefreshGame', this.bind(this._hardRefreshGame));
		this.ige.network.on('requestLogin', this.bind(this._requestLogin));
		this.ige.network.on('clientLoggedIn', this.bind(this._clientLoggedIn));
		this.ige.network.on('entityCount', this.bind(this._entityCount));
		this.ige.network.on('allDone', this.bind(this.allDone));
		this.ige.network.on('placeItemFailed', this.bind(this._placeItemFailed, true));
		this.ige.network.on('moveItemFailed', this.bind(this._moveItemFailed, true));
		this.ige.network.on('deleteItemFailed', this.bind(this._deleteItemFailed, true));
		this.ige.network.on('assetsLoaded', this.bind(this._assetsFinishedStream));
		
		this.ige.viewports.on('mousedown', this.bind(this.viewportMouseDown));
		this.ige.viewports.on('mousemove', this.bind(this.viewportMouseMove));
		this.ige.viewports.on('mouseup', this.bind(this.viewportMouseUp));
		this.ige.viewports.on('mousewheel', this.bind(this.viewportMouseWheel));
		
		this.ige.entities.on('directionChange', this.bind(this.directionChange));
		this.ige.paths.on('pathComplete', this.bind(this.pathComplete));
	},
	
	ready: function () {
		this.log('Game script ready to run');
		this.ige.network.start();
	},
	///////////////////////////////////////////////////////////////////////////////////////////
	// END OF REQUIRED METHODS
	///////////////////////////////////////////////////////////////////////////////////////////
	serverConnect: function () {
		// We have connected to the server successfully!
		this.log('Connected to server successfully!');
		
		// Are we re-connecting or connecting first-time?
		if (!this._didFullConnect) {
			// We haven't connected before
			this.log('Requesting server game data...');
			this.ige.network.send('gameData');
		} else {
			// We are reconnecting
			this.log('Requesting server reconnection advice...');
			this.ige.network.send('reconnect');
		}
	},
	
	serverDisconnect: function () {
		// The server disconnected!
	},
	
	_hardRefreshGame: function () {
		if (!this._doingHardRefresh) {
			this.log('Hard Refresh');
			this._doingHardRefresh = true;
			alert('The game lost its connection to the interwebs! We\'re gonna try and get it back...\n\nClick OK to refresh now!');
			window.location.reload(true);
		}
	},
	
	_entityCount: function (data) {
		// Server has told us how many entities it will send over initially
		// so we can display a progress bar
		this._loadingProgressMax = data;
		this._loadingProgressInterval = setInterval(this.bind(this.updateProgressBar), 200);
	},
	
	updateProgressBar: function () {
		var ratio = this._loadingProgressMax / this.ige.entities.byIndex.length;
		var width = 250 / ratio;
		$('#loadingProgressBar').css('width', width + 'px');
		
		if (ratio <= 1) { clearInterval(this._loadingProgressInterval); }
	},
	
	updateWalkTiles: function () {
		var tiles = false;
		
		if (this.ige.entities.byMapIdAndLayer['testMap1']) {
			tiles = this.ige.entities.byMapIdAndLayer['testMap1'][LAYER_TILES];
		}
		
		if (tiles) {
			// Get an array of tiles that match the "walk" class
			this.walkTiles = [];
			for (var i = 0; i < tiles.length; i++) {
				var tile = tiles[i];
				if (tile.path_class != null) {
					if (tile.path_class.indexOf('walk') > -1) {
						// Tile has walk class
						this.walkTiles.push(tile);
					}
				}
			}
		}
	},
	
	_assetsFinishedStream: function () {
		this.log('-----------------------------------------------------');
		this.log('Asset stream stage 1, waiting for image data...');
		this.log('-----------------------------------------------------');
		this.__allAssetsListener = this.ige.assets.on('allAssetsLoaded', this.bind(this.assetsLoaded));
		
		if (this.ige.assets.imagesLoading < 1) { this.assetsLoaded(); }
	},
	
	assetsLoaded: function () {
		this.ige.assets.off('allAssetsLoaded', this.__allAssetsListener);

		// All the assets have finished loading so tell the server
		this.log('-----------------------------------------------------');
		this.log('All assets have finished loading, entering stage 2...');
		this.log('-----------------------------------------------------');
		this.ige.network.send('assetsLoaded');
	},
	
	_requestLogin: function () {
		// Ask the Facebook module to start up and listen for user events
		this.ige.facebook.start($('body'), '243292065722908', false);
		this.ige.facebook.on('loggedOut', this.bind(this._clientLoggedOut));
		this.ige.facebook.on('userUnknown', this.bind(this._clientUnknown));
	},
	
	_clientLoggedIn: function () {
		// Facebook says the user has logged in
		$('#loadingMain').show();
		$('#mainMenu').hide();
		this.ige.facebook.insert('profilePic', '#uiFbControls', 'fbProfilePic');
	},
	
	_clientLoggedOut: function () {
		// Facebook says the user has logged out so
		// now we need to show the player the login screen
		this.log('Facebook says we are logged out, displaying the login screen...');
		this._displayFacebookLogin();
	},
	
	_clientUnknown: function () {
		// Facebook says the user is unknown to our game so
		// now we need to show the player the login screen
		this.log('Facebook says we are unknown, displaying the login screen...');
		this._displayFacebookLogin();
	},
	
	_displayFacebookLogin: function () {
		$('#mainMenu_faceBookLogin').html('');
		this.ige.facebook.insertLoginButton('#mainMenu_faceBookLogin', null, 'email,user_birthday,status_update,publish_stream,user_hometown,user_location');
		
		$('#loadingMain').hide();
		$('#mainMenu').show();
	},
	
	allDone: function () {
		// Set the client's flag to true so if we reconnect we do not request
		// all the game data again
		this._didFullConnect = true;
		
		/*
		$('#loadingMain').fadeTo(1000, 0, function () {
			$('#loadingMain').css('display', 'none');
			clearInterval(window.loadingTextInterval);
		});
		*/
		clearInterval(window.loadingTextInterval);
		$('#loadingMain').hide();
		
		$('#ui').show();
		$('#mainView').show();
		
		/*
		if (this.ige.sound != null && this.ige.sound.state()) {
			this.ige.sound.create({
				sound_id: 'backgroundMusic1',
				sound_url: './assets/audio/back1.mp3',
				sound_volume: 10,
				sound_auto_load: true,
				sound_auto_play: true,
				sound_buffer: 5,
				sound_multi_play: false,
				sound_type: SOUND_TYPE_TRACK,
			}, {
				scope: this,
				onLoaded: function (sound) {
					this.log('Sound module says sound is now completely loaded with id: ' + sound.sound_id);
					//this.ige.sound.play(sound);
				}
			});
		} else {
			this.log('Cannot play sound, sound module is not loaded', 'info', this.ige.sound);
		}
		*/
		
		// Get all tiles on the tile layer
		var tiles = false;
		
		if (this.ige.entities.byMapIdAndLayer['testMap1']) {
			tiles = this.ige.entities.byMapIdAndLayer['testMap1'][LAYER_TILES];
		}
		
		if (tiles) {
			// Get an array of tiles that match the "walk" class
			this.walkTiles = [];
			for (var i = 0; i < tiles.length; i++) {
				var tile = tiles[i];
				if (tile.path_class != null) {
					if (tile.path_class.indexOf('walk') > -1) {
						// Tile has walk class
						this.walkTiles.push(tile);
					}
				}
			}
			
			// Create some random citizens
			for (var pi = 0; pi < 10; pi++) {
				// Pick a random tile and get it's x and y
				var randomTileIndex = Math.floor((Math.random() * this.walkTiles.length));
				var randomTile = this.walkTiles[randomTileIndex];
				//console.log('Creating new woman');
				this.ige.entities.create({
					template_id: 'womanWalk',
					entity_transform:{
						translate:[randomTile._transform[0], randomTile._transform[1], randomTile._transform[2], false, false],
					},
					entity_locale: LOCALE_EVERYWHERE,
				}, this.bind(function (entity) {
					//console.log('Woman created with ID', entity.entity_id);
					
					if (pi == 0) {
						this.ige.cameras.trackTarget('cam2', entity.entity_id);
					}
					
					if (pi == 1) {
						//this.ige.cameras.trackTarget('cam3', entity.entity_id);
					}
					
					var map = entity.$local.$map;
					this.ige.paths.stopPath(entity, 0);
					this.ige.paths.create(entity);
					
					var startPoint = [entity.entity_tile_x, entity.entity_tile_y];
					//var startPoint = [33, 24];
					
					var randomTileIndex = Math.floor((Math.random() * this.walkTiles.length));
					var randomTile = this.walkTiles[randomTileIndex];
					var endPoint = [randomTile.entity_tile_x, randomTile.entity_tile_y];
					
					var pathPoints = this.ige.paths.localGeneratePath(map, {entityType:1, startPoint:startPoint, endPoint:endPoint, pathClasses:'walk', allowSquare:true, allowDiagonal:false});
					
					//if (pathPoints.length) {
						for (var i = 0; i < pathPoints.length; i++) {
							this.ige.paths.addPathPoint(entity, pathPoints[i][0], pathPoints[i][1], 30);
						}
						
						// Start path processing with autoStop enabled
						this.ige.paths.startPath(entity, PATH_TYPE_ENTITY, new Date().getTime(), true);
					//}
				}));
			}
		}
		
		//setTimeout(this.bind(this.ige.viewports.makeViewportDirty(this.ige.viewports.byIndex[0])), 500);
		
		setInterval(this.bind(this.updateWalkTiles), 1000);
	},
	
	shareOnWall: function () {
		this.ige.facebook.newWallPost({
				name: 'IsoCity - By Irrelon Software',
				link: 'http://bit.ly/qeFyJW',
				picture: 'https://fbcdn-photos-a.akamaihd.net/photos-ak-snc1/v43/87/191864000870979/app_1_191864000870979_96.gif',
				caption: 'A multiplayer city-builder, currently in demo mode.',
				description: 'IsoCity is a new multiplayer city-builder game! It\'s written in JavaScript and uses the Isogenic Game Engine. It\'s still just a demo at the moment so why not check out the beginnings of something awesome?',
				privacy: 'EVERYONE',
				actions: [{name:'Open', link:'http://bit.ly/qeFyJW'}],
			},
			true
		);
	},
	
	toggleMiniVp: function () {
		if ($('#miniVp').css('display') == 'block') {
			this.ige.viewports.byId['miniVp'].viewport_hide = true;
			$('#miniVp').hide();
		} else {
			this.ige.viewports.byId['miniVp'].viewport_hide = false;
			$('#miniVp').show();
		}
	},
	
	toggleViewportClipping: function () {
		if (this.ige.viewports.byIndex[0].viewport_clipping) {
			this.ige.viewports.byIndex[0].viewport_clipping = false;
			this.ige.viewports.makeViewportDirty(this.ige.viewports.byIndex[0]);
			this.log('Viewport clipping disabled');
		} else {
			this.ige.viewports.byIndex[0].viewport_clipping = true;
			this.ige.viewports.makeViewportDirty(this.ige.viewports.byIndex[0]);
			this.log('Viewport clipping enabled');
		}
	},
	
	viewportMouseDown: function (event, touch) {
		event.preventDefault ? event.preventDefault() : event.returnValue = false;
		
		var elementOffset = $('#' + event.viewport.viewport_id).offset();
		var clientX = event.pageX;
		var clientY = event.pageY;
		
		if (event.button == 0) {
			if (!this.mousePanMode) {
				this.mousePanMode = 1;
				this.mousePanStartPosition = [clientX, clientY];
			}
		}
		
	},
	
	viewportMouseMove: function (event) {
		var viewport = event.viewport;
		var elementOffset = $('#' + viewport.viewport_id).offset();
		
		var clientX = event.pageX;
		var clientY = event.pageY;
		
		this.currentPanPort = event.viewport;
		var worldCords = this.ige.viewports.screenToWorld(viewport, clientX, clientY, false);
		var tileCords = this.ige.viewports.screenToWorld(viewport, clientX, clientY, true);
		
		if (document.getElementById('igeCordDiv') != null) {
			$('#igeCordDiv').html(worldCords[0] + ' : ' + worldCords[1] + ' : ' + tileCords[0] + ' : ' + tileCords[1]);
		}
		
		if (event.button == 0) {
			switch (this.mousePanMode) {
				case 1:
					// Check if the mouse has moved enough to consider it a panning event
					if (Math.abs(this.mousePanStartPosition[0] - clientX) > 4 || Math.abs(this.mousePanStartPosition[1] - clientY) > 4) {
						// The user pressed the mouse-down in SELECT mode then moved the mouse,
						// so now we want to transition into a pan operation
						this.currentPanPort = event.viewport;
						this.ige.viewports.panStart(event.viewport, clientX, clientY);
						
						this.mousePanMode = 2;
						return;
					}
				break;
				
				case 2:
					this.ige.viewports.panTo(this.currentPanPort, clientX, clientY);
					return;
				break;
			}
		}
		
		// Check if we are currently placing an entity and if so, move it to the current tile
		if (this.currentCursor != null && this.currentCursorEntity != null) {
			if (!this.ige.entities.isEntityTileBlocked(this.currentCursorEntity, tileCords[1][0], tileCords[1][1], 0)) {
				this.ige.entities.translate(this.currentCursorEntity, tileCords[1][0], tileCords[1][1], 0, false, true);
			}
		}
		
		switch (this.mouseMode) {
			case this.GAME_MM_SELECT:
				this.ige.entities.highlightAtTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
			break;
			
			case this.GAME_MM_EDIT:
				if (this.mouseModeEditEntity == null) {
					// Pick up the entity
					var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
					var gotOne = false;
					
					// Loop the array and check for non-sprite entities
					for (var i in entityArray) {
						var entity = entityArray[i][0];
						if (entity.entity_type != ENTITY_TYPE_SPRITE) {
							this.ige.entities.highlightOne(entity);
							gotOne = true;
							break;
						}
					}
					
					if (!gotOne) {
						this.ige.entities.unHighlightAll();
					}
				} else {
					// We already have an entity so alter it's anchor point
					var entity = this.mouseModeEditEntity;
					
					var diffX = this.mouseModeEditStartX - clientX;
					var diffY = this.mouseModeEditStartY - clientY;
					
					this.ige.entities.origin(entity, this.mouseModeEditEntityAnchor[0] + (diffX / 100), this.mouseModeEditEntityAnchor[1] + (diffY / 100), 1);
					
					//this.ige.entities.markDirtyByAssetId(this.mouseModeEditEntity.asset_id);
				}
			break;
			
			case this.GAME_MM_MOVE:
				if (this.mouseModeMoveEntity == null) {
					// Pick up the entity
					var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
					var gotOne = false;
					
					// Loop the array and check for non-sprite entities
					for (var i in entityArray) {
						var entity = entityArray[i][0];
						if (entity.entity_type != ENTITY_TYPE_SPRITE) {
							// Check if we own this item
							if (entity.user_id == this.ige.facebook._user.user_id) {
								this.ige.entities.highlightOne(entity);
								gotOne = true;
								break;
							}
						}
					}
					
					if (!gotOne) {
						this.ige.entities.unHighlightAll();
					}
				} else {
					// We already have an entity so move it
					if (!this.ige.entities.isEntityTileBlocked(this.mouseModeMoveEntity, tileCords[1][0], tileCords[1][1], 0)) {
						this.ige.entities.translate(this.mouseModeMoveEntity, tileCords[1][0], tileCords[1][1], 0, false, true);
					}
				}
			break;
			
			case this.GAME_MM_DELETE:
				// Pick up the entity
				var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
				var gotOne = false;
				
				// Loop the array and check for ownership
				for (var i in entityArray) {
					var entity = entityArray[i][0];
					if (entity.entity_type != ENTITY_TYPE_SPRITE) {
						// Check if we own this item
						if (entity.user_id == this.ige.facebook._user.user_id) {
							this.ige.entities.highlightOne(entity);
							gotOne = true;
							break;
						}
					}
				}
				
				if (!gotOne) {
					this.ige.entities.unHighlightAll();
				}
			break;
		}
		
	},
	
	viewportMouseUp: function (event, touch) {
		var viewport = event.viewport;
		var elementOffset = $('#' + event.viewport.viewport_id).offset();
		var clientX = event.pageX;
		var clientY = event.pageY;
		
		var tileCords = this.ige.viewports.screenToWorld(viewport, clientX, clientY, true);
		//var tileCords = this.ige.renderer.screenToMap[event.map.map_layers[2].layer_render_mode](clientX - elementOffset.left, clientY - elementOffset.top, event.viewport);
		
		if (event.button == 0) {
			
			if (this.mousePanMode == 2) {
				this.ige.viewports.panEnd(this.currentPanPort, clientX, clientY);
				this.mousePanMode = 0;
				return;
			} else {
				// User has clicked on the map so end pre-pan mode
				//this.ige.cameras.lookBy(event.viewport.$local.$camera, clientX + event.viewport.panLayer.centerX, clientY + event.viewport.panLayer.centerY);
				this.mousePanMode = 0;
			}
			
			switch (this.mouseMode) {
				case this.GAME_MM_SELECT:
					this.ige.entities.highlightAtTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
				break;
				
				case this.GAME_MM_EDIT:
					if (this.mouseModeEditEntity == null) {
						// Pick up the entity
						var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
						
						// Loop the array and check for non-sprite entities
						for (var i in entityArray) {
							var entity = entityArray[i][0];
							if (entity.entity_type != ENTITY_TYPE_SPRITE) {
								// Pick up the entity
								this.mouseModeEditEntity = entity;
								this.mouseModeEditEntityAnchor = this.ige.entities.origin(entity);
								this.mouseModeEditEntityScale = this.ige.entities.scale(entity);
								
								this.mouseModeEditStartX = clientX;
								this.mouseModeEditStartY = clientY;
								
								this.ige.entities.unHighlight(this.mouseModeEditEntity);
								this.mouseModeEditEntity.entity_base_draw = [0, '#ff0000'];
								break;
							}
						}				
					} else {
						// We already have an entity so place it back down
						var entity = this.mouseModeEditEntity;
						//this.ige.entities.markDirtyByAssetId(this.mouseModeEditEntity.asset_id);
						
						// Output the new anchor and scale data to the console
						console.log('Origin:', this.ige.entities.origin(entity));
						console.log('Scale:', this.ige.entities.scale(entity));
						
						// Clear the selection variables
						delete this.mouseModeEditEntity.entity_base_draw;
						this.mouseModeEditEntity = null;
					}
				break;				
				
				case this.GAME_MM_MOVE:
					if (this.mouseModeMoveEntity == null) {
						// Pick up the entity
						var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
						
						// Loop the array and check for non-sprite entities
						for (var i in entityArray) {
							var entity = entityArray[i][0];
							if (entity.entity_type != ENTITY_TYPE_SPRITE) {
								// Check if we own this item
								if (entity.user_id == this.ige.facebook._user.user_id) {
									// Pick up the entity
									this.mouseModeMoveEntity = entity;
									this.mouseModeMoveEntityBlocking = entity.map_block;
									if (entity.map_block == MAP_BLOCK_NOCHECK || entity.map_block == MAP_BLOCK_CHECK) {
										this.ige.entities.unBlockTiles(entity);
										entity.map_block = MAP_NOBLOCK_CHECK;
									}
									
									//this.mouseModeMoveEntity.entity_base_draw = [1, '#0098e4'];
									this.ige.entities.highlight(this.mouseModeMoveEntity);
									
									break;
								}
							}
						}						
					} else {
						// We already have an entity so place it back down
						var entity = this.mouseModeMoveEntity;
						
						// Check if we own this item
						if (entity.user_id == this.ige.facebook._user.user_id) {
							if (!this.ige.entities.isEntityTileBlocked(this.mouseModeMoveEntity, tileCords[1][0], tileCords[1][1], 0)) {
								this.ige.entities.translate(entity, tileCords[1][0], tileCords[1][1], 0, false, true);
								
								// Send the move request over the network
								this.ige.network.send('moveItem', [entity.entity_id, entity.entity_tile_x, entity.entity_tile_y]);
								
								// Sort out entity tile blocking
								entity.map_block = this.mouseModeMoveEntityBlocking;
								if (entity.map_block == MAP_BLOCK_NOCHECK || entity.map_block == MAP_BLOCK_CHECK) {
									this.ige.entities.blockTiles(entity);
								}
							}
						}
						
						//delete entity.entity_base_draw;
						this.ige.entities.unHighlight(entity);
						
						// Clear the selection variables
						this.mouseModeMoveEntity = null;
						this.mouseModeMoveEntityBlocking = null;
					}
				break;
				
				case this.GAME_MM_DELETE:
					// Delete the entity
					var entityArray = this.ige.entities.atTileXY(event.viewport, tileCords[1][0], tileCords[1][1]);
					
					// Loop the array and check for non-sprite entities
					for (var i in entityArray) {
						var entity = entityArray[i][0];
						if (entity.entity_type != ENTITY_TYPE_SPRITE) {
							// Check if we own this item
							if (entity.user_id == this.ige.facebook._user.user_id) {
								// Send the delete request over the network
								this.ige.network.send('deleteItem', [entity.entity_id]);
								
								// Remove the entity
								this.ige.entities.remove(entity);
							}
						}
					}
				break;
				
				case this.GAME_MM_PLACE:
					if (this.currentCursor && this.currentCursorEntity) {
						this.ige.entities.translate(this.currentCursorEntity, tileCords[1][0], tileCords[1][1], 0, false, true);
						if (this.ige.network) {
							this.log('Placing item at ' + tileCords[1][0] + ', ' + tileCords[1][1]);
							this.ige.network.send('placeItem', [tileCords[1][0], tileCords[1][1], this.currentCursor[0], this.currentCursor[1]]);
						} else {
							this._placeItem([tileCords[1][0], tileCords[1][0], this.currentCursor[0], this.currentCursor[1]]);
						}
						var ccType = this.currentCursor[0];
						var ccSheet = this.currentCursor[1];
						
						this.selectCursor(ccType, ccSheet);
					}
				break;
			}

		}
	},
	
	viewportMouseWheel: function (event, touch) {
		switch (this.mouseMode) {
			case this.GAME_MM_EDIT:
				if (this.mouseModeEditEntity != null) {
					if (event.wheelDelta < 0) {
						this.ige.entities.scale(this.mouseModeEditEntity, -0.01, -0.01, 0, true);
					}
					
					if (event.wheelDelta > 0) {
						this.ige.entities.scale(this.mouseModeEditEntity, 0.01, 0.01, 0, true);
					}
					
					//this.ige.entities.markDirtyByAssetId(this.mouseModeEditEntity.asset_id);
				}
			break;
		}
	},
	
	selectMouseMode: function (mode) {
		// Turn off the current mode cleanly first
		switch (this.mouseMode) {
			case this.GAME_MM_SELECT:
				this.selectCursor(null);
				$('#uiMenuButton_select').css('box-shadow', '');
			break;
			
			case this.GAME_MM_EDIT:
				$('#uiMenuButton_select').css('box-shadow', '');
			break;
			
			case this.GAME_MM_MOVE:
				this.selectCursor(null);
				$('#uiMenuButton_move').css('box-shadow', '');
			break;
			
			case this.GAME_MM_DELETE:
				this.selectCursor(null);
				$('#uiMenuButton_delete').css('box-shadow', '');
			break;
			
			case this.GAME_MM_PLACE:
				// We are in place mode so kill the cursor if there is one
				this.selectCursor(null);
			break;
		}
		
		// Assign the new mode
		this.mouseMode = mode;
		
		// Run any mode code now we have a new mode
		switch (this.mouseMode) {
			case this.GAME_MM_SELECT:
				this.log('Selecting cursor mode SELECT');
				$('#uiMenuButton_select').css('box-shadow', '0px 0px 15px 0px #fff');
			break;
			
			case this.GAME_MM_EDIT:
				this.log('Selecting cursor mode EDIT');
				$('#uiMenuButton_select').css('box-shadow', '0px 0px 15px 0px #ff0000');
			break;
			
			case this.GAME_MM_MOVE:
				this.log('Selecting cursor mode MOVE');
				$('#uiMenuButton_move').css('box-shadow', '0px 0px 15px 0px #fff');
			break;
			
			case this.GAME_MM_DELETE:
				this.log('Selecting cursor mode DELETE');
				$('#uiMenuButton_delete').css('box-shadow', '0px 0px 15px 0px #fff');
			break;
		}
	},
	
	selectCursor: function (cursorName, sheetId) {
		// Check that the temp cursor location is not being used
		/*
		var blockingEntity = this.ige.maps.getTileMark('testMap1', -40, -40);
		if (blockingEntity) {
			this.log('Removing temp blocking entity');
			this.ige.entities.remove(blockingEntity);
		}
		*/
		if (this.currentCursorEntity != null) {
			// We have a current entity that has been the temp entity for the previous cursor so remove it
			//this.log('Deselecting cursor');
			var tempCursor = this.currentCursorEntity;
			this.currentCursorEntity = null;
			this.currentCursor = null;
			this.ige.entities.remove(tempCursor);
			this.selectCursor(cursorName, sheetId);
		} else {
			// The cursor needs to change and we need to create a temporary entity that will follow the cursor
			if (this.currentCursorEntity == null && this.currentCursor == null) {
				if (cursorName != null) {
					// Set the mouse-mode
					this.selectMouseMode(this.GAME_MM_PLACE);
					this.log('Selecting new cursor', cursorName, sheetId);
					
					// Create a temporary entity that will represent the one the
					// user wants to create. We make this an object even if the type
					// is usually a tile because we want more than one to exist on the 
					// same tile and tiles don't allow stacking like objects do
					this.ige.entities.create({
						template_id: cursorName,
						entity_transform: {
							translate: [0, 0, 0, false, true], // position
							debug:true, // draw bounds and debug info
						},
						entity_type: ENTITY_TYPE_OBJECT,
						entity_locale: LOCALE_SINGLE_CLIENT,
						map_block: MAP_NOBLOCK_NOCHECK,
						map_id: 'testMap1',
						asset_sheet_frame: sheetId,
						temp: true,
					}, this.bind(function (entity) {
						if (entity) {
							// Set this entity to non-blocking as it is temporary
							entity.map_block = MAP_NOBLOCK_CHECK;
							this.currentCursorEntity = entity;
							this.log('Created cursor with ID:', entity.entity_id);
						} else {
							this.log('Error creating entity');
						}
					}));
					
					this.currentCursor = [cursorName, sheetId];
					
				} else {
					this.currentCursor = null;
				}
			} else {
				if (this.currentCursorEntity != null) {
					var tempCursor = this.currentCursorEntity;
					this.currentCursorEntity = null;
					this.currentCursor = null;
					this.ige.entities.remove(tempCursor);
				}
				this.currentCursor = null;
				this.log('Cannot select new cursor whilst old one is still in existance.');
			}
		}
	},
	
	toggleMenu: function (menuId, groupId) {
		// Ensure all the groups toggles are off but don't alter the one specified by menuId
		this.closeAll(groupId, menuId);
		
		if (menuId) {
			if (!$('#uiMenu_' + menuId).data('igeState')) {
				this.openMenu('#uiMenu_' + menuId);
				this._tipState = false;
				this.hideTip();
			} else {
				this.closeMenu('#uiMenu_' + menuId);
				this._tipState = true;
			}
		}
	},
	
	openMenu: function (id) {
		$(id).data('igeState', 1);
		$(id).show();
		/*$(id).animate({"opacity": '1'}, 100);*/
	},
	
	closeMenu: function (id) {
		$(id).data('igeState', 0);
		$(id).hide();
		/*
		$(id).animate({"opacity": '0'}, {
			duration:100,
			complete:function () {
				$(this).hide();
			}
		});
		*/
	},
	
	closeAll: function (groupId, menuId) {
		var groupArray = $('.' + groupId);
		for (var i = 0; i < groupArray.length; i++) {
			if (menuId) {
				if (groupArray[i].id != 'uiMenu_' + menuId) {
					this.closeMenu('#' + groupArray[i].id);
				}
			} else {
				this.closeMenu('#' + groupArray[i].id);
			}
		}
		this._tipState = true;
	},
	
	showTip: function (element, tipIndex) {
		if (this._tipState) {
			$('#uiGameTip').html('<span class="tipTitle">' + this.tips[tipIndex][0] + '</span><span class="tipText">' + this.tips[tipIndex][1] + '</span>');
			$('#uiGameTip').show();
		}
	},
	
	hideTip: function () {
		$('#uiGameTip').hide();
	},
	
	pathComplete: function (obj) {
		//console.log('Path completed');
		var map = obj.$local.$map;
		
		if (obj.path.points.length) {
			var endTile = obj.path.points[obj.path.points.length - 1].tile;
		} else {
			endTile = [];
		}
		
		var startPoint = [obj.entity_tile_x, obj.entity_tile_y];
		
		var randomTileIndex = Math.floor((Math.random() * this.walkTiles.length));
		var randomTile = this.walkTiles[randomTileIndex];
		
		endPoint = [randomTile.entity_tile_x, randomTile.entity_tile_y];
		
		this.ige.paths.create(obj);
		var pathPoints = this.ige.paths.localGeneratePath(map, {entityType:1, startPoint:startPoint, endPoint:endPoint, pathClasses:'walk', allowSquare:true, allowDiagonal:false});
		//console.log('New path:', pathPoints);
		
		if (pathPoints) {
			for (var i = 0; i < pathPoints.length; i++) {
				this.ige.paths.addPathPoint(obj, pathPoints[i][0], pathPoints[i][1], 30);
			}
		}
		
		// Start path processing with autoStop enabled
		this.ige.paths.startPath(obj, PATH_TYPE_ENTITY, new Date().getTime(), true);
	},
	
	directionChange: function (entity) {
		switch (entity.template_id) {
			
			case 'womanWalk':
				// Entity is a person sprite
				switch (entity.entity_direction) {
					case DIRECTION_N:
						this.ige.entities.setAnimation(entity, 'womanWalkN');
					break;
					
					case DIRECTION_E:
						this.ige.entities.setAnimation(entity, 'womanWalkE');
					break;
					
					case DIRECTION_NE:
						this.ige.entities.setAnimation(entity, 'womanWalkNE');
					break;					
					
					case DIRECTION_S:
						this.ige.entities.setAnimation(entity, 'womanWalkS');
					break;
					
					case DIRECTION_SE:
						this.ige.entities.setAnimation(entity, 'womanWalkSE');
					break;
					
					case DIRECTION_W:
						this.ige.entities.setAnimation(entity, 'womanWalkW');
					break;		
					
					case DIRECTION_NW:
						this.ige.entities.setAnimation(entity, 'womanWalkNW');
					break;						
					
					case DIRECTION_SW:
						this.ige.entities.setAnimation(entity, 'womanWalkSW');
					break;		
				}
			break;
			
		}
	},
	
});