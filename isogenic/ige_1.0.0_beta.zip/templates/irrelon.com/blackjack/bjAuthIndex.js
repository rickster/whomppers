BjAuth = new IgeClass({
	Extends: IgeEvents,
	
	init: function (engine) {
		this.ige = engine;
		
		// Register ourself in the engine object
		this.ige.bjAuth = this;
	},
});