BjGamesClient = new IgeClass({
	Extends: IgeEvents,
	
	init: function (engine) {
		this._className = 'BjGamesClient';
		this.ige = engine;
		this.engine = engine;
		
		// Register ourselves as an engine property
		this.engine.bjGamesClient = this;
		
		// Set the chip values
		this.chipValues = [
			1,
			5,
			10,
			25,
			50,
			100,
			500,
			1000,
			5000,
			20000
		];
		
		// Set the chip positions for each seat
		this.chipPositions = [
			[432, -65],
			[210, 0],
			[0, 20],
			[-210, 0],
			[-432, -65]
		];
		
		this.seatPositions = [
			[482, 76, -25.0],
			[246, 152, -12.5],
			[0, 170, 0.0],
			[-246, 152, 12.5],
			[-482, 76, 25.0],
			[0, -170, 0.0],
		];
		
		this.currentChipId = [];
		this.currentBet = [];
		this.currentSeatId = [];
		
		this.showAnimation = true;
		
		this.log('Init complete');
	},
	
	ready: function () {
		// Hook button events from the UI class
		this.ige.entities.on('ui_up', this.bind(this.buttonClick));
	},
	
	buttonClick: function (entity) {
		switch (entity.button_class) {
			case 'hitButton':
				var roomId = entity.room_id;
				var seatId = entity.seat_id;
				
				this.askServerTo_hit(roomId);
			break;
			
			case 'standButton':
				var roomId = entity.room_id;
				var seatId = entity.seat_id;
				
				this.askServerTo_stand(roomId);
			break;
		}
	},
	
	// Server has told us we've changed game states
	serverToldUsWe_changedGameState: function (data) {
		var roomId = data[0];
		var state = data[1];
		
		this.log('Server told us game has changed state in room: ' + roomId + ' to ' + state);
		
		switch (state) {
			case this.ige.bjGames.states.resetting:
				// The game is being reset
				this.log('Server game state changed to resetting so resetting our game object');
				var room = this.engine.bjRooms.read(roomId);
				
				// Remove all card entities
				var entArr = this.engine.entities.byIndex;
				var entCount = entArr.length;
				
				while (entCount--) {
					var ent = entArr[entCount];
					
					// Check if the entity is a card
					if (ent.template_id == 'cardEntity') {
						// Check if the entity belongs to the room we are resetting
						if (ent.map_id == 'map_' + room.room_id) {
							// Remove it!
							this.engine.entities.remove(ent);
						}
					}
				}
			break;
			
			case this.ige.bjGames.states.dealer:
				// The game is in the final stage where the dealer plays his hand
				// so clear the action control buttons
				this.ige.entities.hide('hitButton_' + roomId);
				this.ige.entities.hide('standButton_' + roomId);
				
				// Clear the dealer face-down card since it is a dummy place-holder entity
				this.ige.entities.remove('dealerHoldCardBack_' + roomId);
				
				// Clear the seat indicator
				this.engine.bjRoomsClient.clearSeatIndicators(roomId);
			break;
		}
	},
	
	// The server told us the cards this round has produced
	serverToldUsWe_areReceivingDealComplete: function (data) {
		var roomId = data[0];
		var room = this.engine.bjRooms.read(roomId);
		
		// Create the dealer face-down card
		this.createCard(roomId, 5, 1, {suit:'FaceDown', num:0});
	},
	
	updateCardCounter: function (roomId, seatIndex) {
		var room = this.engine.bjRooms.read(roomId);
		cardsBySeat = room.cards[seatIndex];
		
		var ccEnt = this.ige.entities.byId['uiCardValue_' + roomId + '_' + seatIndex];
		
		if (cardsBySeat && cardsBySeat.length) {
			// Check for blackjack
			if ((cardsBySeat[0] && cardsBySeat[1]) &&
				(cardsBySeat[0].num == 1 || cardsBySeat[1].num == 1) &&
				(cardsBySeat[0].num >= 10 || cardsBySeat[1].num >= 10)) {
				// Player has blackjack
				ccEnt._valueLabel = 'BJ';
				ccEnt._valueLabel2 = 'BJ';
				
				// Set the background color of the card value box
				ccEnt._valueLabelBackColor = '#003cff';
				
				this.ige.entities.show(ccEnt);
			} else {
				for (var cardIndex = 0; cardIndex < cardsBySeat.length; cardIndex++) {
					var card = cardsBySeat[cardIndex];
					
					// Update the card value counter
					if (ccEnt) {
						if (cardIndex == 0) {
							ccEnt._valueLabel = parseInt(this.ige.bjGames.cardValues[card.num]);
							if (card.num == 1) {
								ccEnt._valueLabel2 = 11;
							} else {
								ccEnt._valueLabel2 = ccEnt._valueLabel;
							}
						} else {
							ccEnt._valueLabel += parseInt(this.ige.bjGames.cardValues[card.num]);
							if (card.num == 1) {
								ccEnt._valueLabel2 += 11;
							} else {
								ccEnt._valueLabel2 += parseInt(this.ige.bjGames.cardValues[card.num]);
							}
						}
						
						// If the second counter is over 21 then reduce the counters
						// so that only counter 1 is showing
						if (ccEnt._valueLabel2 > 21) {
							ccEnt._valueLabel2 = ccEnt._valueLabel;
						}
						
						// Set the background color of the card value box
						if (ccEnt._valueLabel > 21 && ccEnt._valueLabel2 > 21) {
							ccEnt._valueLabelBackColor = '#ff0000';
						} else {
							ccEnt._valueLabelBackColor = '#00ff00';
						}
						
						this.ige.entities.show(ccEnt);
					}
				}
			}
		}
	},
	
	// The server sent data about a new card on the table
	createCard: function (roomId, seatId, cardIndex, card) {
		var room = this.engine.bjRooms.read(roomId);
		
		// Check if the seat is not the dealer at seatId 5
		if (seatId != 5) {
			// Create the card on the table
			var cardX = -15 + (-(seatId - 2) * 240) + (cardIndex * 30);
			var cardY = 170 - (Math.abs((seatId - 2) * (25 * Math.abs(seatId - 2))));
			
			var rotAdd = 0;
			if (cardIndex == 0) { rotAdd = -5; }
			if (cardIndex == 1) { rotAdd = 5; }
			var cardRotation = ((seatId - 2) * 13) + rotAdd;
			
			this.engine.entities.create({
				template_id: 'cardEntity',
				entity_transform: {
					translate: [cardX, cardY, 0, false, false], // position
					scale: [room._cardScale, room._cardScale, 1.0], // scale
					rotate: [cardRotation, 0.0, 0.0], // rotation
					opacity: [1.0, 1.0, 1.0], // opacity
					origin: [0.5, 0.5], // origin point (anchor)
					debug:false, // draw bounds and debug info
				},
				asset_sheet_frame: (card.num) + (13 * card.suit),
				map_id:'map_' + roomId,
			});
		} else {
			// The seat is the dealers
			if (card.num > 0) {
				// Place a dealer card
				// Create the card on the table
				var cardX = -15 + (cardIndex * 30);
				var cardY = -170;
				
				var rotAdd = 0;
				if (cardIndex == 0) { rotAdd = -5; }
				if (cardIndex == 1) { rotAdd = 5; }
				var cardRotation = rotAdd;
				
				this.engine.entities.create({
					template_id: 'cardEntity',
					entity_transform: {
						translate: [cardX, cardY, 0, false, false], // position
						scale: [room._cardScale, room._cardScale, 1.0], // scale
						rotate: [cardRotation, 0.0, 0.0], // rotation
						opacity: [1.0, 1.0, 1.0], // opacity
						origin: [0.5, 0.5], // origin point (anchor)
						debug:false, // draw bounds and debug info
					},
					asset_sheet_frame: (card.num) + (13 * card.suit),
					map_id:'map_' + roomId,
				});
			} else {
				// This is the face-down card, so just create a face-down entity
				var cardX = -15 + (cardIndex * 30);
				var cardY = -170;
				
				var rotAdd = 0;
				if (cardIndex == 0) { rotAdd = -5; }
				if (cardIndex == 1) { rotAdd = 5; }
				var cardRotation = rotAdd;
				
				this.engine.entities.create({
					template_id: 'cardBackEntity',
					entity_id: 'dealerHoldCardBack_' + roomId,
					entity_transform: {
						translate: [cardX, cardY, 0, false, false], // position
						scale: [room._cardScale, room._cardScale, 1.0], // scale
						rotate: [cardRotation, 0.0, 0.0], // rotation
						opacity: [1.0, 1.0, 1.0], // opacity
						origin: [0.5, 0.5], // origin point (anchor)
						debug:false, // draw bounds and debug info
					},
					map_id:'map_' + roomId,
				});
			}
		}
		
		this.log('Server sent us a card!');
	},
	
	serverToldUsWe_shouldDecideBet: function (data) {
		var roomId = data[0];
		var seatId = data[1];
		var playerSessionId = data[2];
		this.currentSeatId[roomId] = seatId;
		
		this.ige.bjRoomsClient.indicateSeat(roomId, seatId);
		
		// Check if we are being told to bet
		if (this.ige.network.sessionId == playerSessionId) {
			// We are being told to bet
			// so display betting controls
			this.ige.bjRoomsClient.showBetControl(roomId);
		} else {
			// Someone else is being told to bet
			
		}
	},
	
	askServerTo_bet: function (roomId) {
		if (this.currentBet[roomId] > 0) {
			this.log('Asking server to bet ' + this.currentBet[roomId]);
			this.ige.network.send('bet', [roomId, this.currentSeatId[roomId], this.currentBet[roomId]]);
		}
	},
	
	selectBettingChip: function (roomId, chipId) {
		//this.log('Setting currently selected chip id in room ' + roomId + ' to ' + chipId);
		this.currentChipId[roomId] = chipId;
		$('.chip').removeClass('selected');
		$('.chip' + chipId).addClass('selected');
		
		return false;
	},
	
	increaseBet: function (roomId) {
		//this.log('Increasing bet in room ' + roomId + ' by ' + this.chipValues[this.currentChipId[roomId]]);
		this.currentBet[roomId] += this.chipValues[this.currentChipId[roomId]];
		this.updateBet(roomId);
		
		return false;
	},
	
	decreaseBet: function (roomId) {
		//this.log('Decreasing bet in room ' + roomId);
		this.currentBet[roomId] -= this.chipValues[this.currentChipId[roomId]];
		if (this.currentBet[roomId] < 0) { this.currentBet[roomId] = 0; }
		this.updateBet(roomId);
		
		return false;
	},
	
	updateBet: function (roomId) {
		var finalBet = this.currentBet[roomId];
		if (!finalBet) { finalBet = '0'; } // Convert zero to string
		$('#playScreen_' + roomId + ' #betControls .betControl .currentBet').html(finalBet);
	},
	
	completeBet: function (roomId) {
		if (this.currentBet[roomId] > 0) {
			this.ige.bjRoomsClient.hideBetControl(roomId);
			this.askServerTo_bet(roomId);
			
			return false;
		}
	},
	
	serverToldUsWe_bet: function (data) {
		// The server told us that a bet was placed so display some chips for it
		// and the actual bet value on the table
		var roomId = data[0];
		var seatId = data[1];
		var betValue = data[2];
		
		var room = this.engine.bjRooms.read(roomId);
		
		// Work out how many of each chip is required to make up the bet value
		var tempBet = betValue;
		var tempChips = [];
		for (var i = this.chipValues.length - 1; i >= 0; i--) {
			var chipValue = this.chipValues[i];
			var divided = Math.floor(tempBet / chipValue);
			
			if (divided >= 1) {
				tempChips[i] = divided;
				tempBet -= divided * this.chipValues[i];
			}
			
			if (tempBet == 0) { break; }
		}
		
		// Set the chip position based upon the seat
		var x = this.chipPositions[seatId][0], y = this.chipPositions[seatId][1];
		
		// Generate some slightly random positions and place some chip entities
		for (var i in tempChips) {
			for (var entI = 0; entI < tempChips[i]; entI++) {
				var chipRotation = Math.floor(Math.random() * 360);
				var chipX = (Math.floor(Math.random() * 80) - 40) + x;
				var chipY = (Math.floor(Math.random() * 40) - 20) + y;
				
				this.createNewChipEntity(roomId, seatId, chipX, chipY, chipRotation, this.chipValues[i], i);
			}
		}
		
		// Display the chip value label
		this.updateChipValueLabel(roomId, seatId, betValue);
		this.showChipValueLabel(roomId, seatId);
	},
	
	createNewChipEntity: function (roomId, seatId, chipX, chipY, chipRotation, chipValue, chipSheetFrame) {
		var room = this.engine.bjRooms.read(roomId);
		
		this.engine.entities.create({
			template_id: 'chipEntity',
			entity_transform: {
				translate: [chipX, chipY, 0, false, false], // position
				scale: [0.5, 0.5, 1.0], // scale
				rotate: [chipRotation, 0.0, 0.0], // rotation
				opacity: [1.0, 1.0, 1.0], // opacity
				origin: [0.5, 0.5], // origin point (anchor)
				debug:false, // draw bounds and debug info
			},
			asset_sheet_frame: parseInt(chipSheetFrame) + 1,
			map_id:'map_' + roomId,
			_chipValue: chipValue
		}, this.bind(function (newEntity) {
			// Store the new entity so that we can manipulate the chips later
			room.$local.$chipEntities = room.$local.$chipEntities || [];
			room.$local.$chipEntities[seatId] = room.$local.$chipEntities[seatId] || [];
			room.$local.$chipEntities[seatId].push(newEntity);
		}));
	},
	
	updateChipValueLabel: function (roomId, seatId, newValue) {
		var chipLabelEntity = this.engine.entities.byId['uiChipValue_' + roomId + '_' + seatId];
		chipLabelEntity._valueLabel = newValue;
	},
	
	showChipValueLabel: function (roomId, seatId) {
		this.engine.entities.show('uiChipValue_' + roomId + '_' + seatId);
	},
	
	serverToldUsWe_shouldDecideAction: function (data) {
		var roomId = data[0];
		var seatId = data[1];
		var playerSessionId = data[2];
		this.currentSeatId[roomId] = seatId;
		
		// Show users who is being waited on
		this.ige.bjRoomsClient.indicateSeat(roomId, seatId);
		
		// Check if we are being told to bet
		if (this.ige.network.sessionId == playerSessionId) {
			// We have been asked to take action so display action controls to the player
			this.ige.entities.show('hitButton_' + roomId);
			this.ige.entities.show('standButton_' + roomId);
		} else {
			// Someone else is being told to take action
			this.ige.entities.hide('hitButton_' + roomId);
			this.ige.entities.hide('standButton_' + roomId);
		}
	},
	
	askServerTo_hit: function (roomId) {
		this.log('Asking server to hit');
		this.ige.network.send('hit', [roomId, this.currentSeatId[roomId]]);
	},
	
	askServerTo_stand: function (roomId) {
		this.log('Asking server to stand');
		this.ige.network.send('stand', [roomId, this.currentSeatId[roomId]]);
	},
	
	serverToldUsWe_areReceivingNewCard: function (data) {
		var roomId = data[0];
		var seatId = data[1];
		var card = data[2];
		
		var room = this.engine.bjRooms.read(roomId);
		
		if (room) {
			// Store the new card in the room's seat card array
			room.cards[seatId] = room.cards[seatId] || [];
			room.cards[seatId].push(card);
			var cardIndex = room.cards[seatId].length - 1;
			
			// Create the new card on screen
			this.ige.bjRoomsClient.indicateSeat(roomId, seatId);
			this.createCard(roomId, seatId, cardIndex, card);
			
			// Update the card counter
			this.updateCardCounter(roomId, seatId);
		} else {
			this.log('Cannot locate room from roomId', 'warning', [data, roomId]);
		}
	},
	
	serverToldUsWe_areReceivingHandResolve: function (data) {
		var roomId = data[0];
		var seatId = data[1];
		var handState = data[2];
		var handStateText = '';
		
		var animStart = 0;
		var currentTime = new Date().getTime();
		var room = this.engine.bjRooms.read(roomId);
		var chipEntities = room.$local.$chipEntities[seatId];
		var chipCount = chipEntities.length;
		
		// Indicate the seat we are resolving
		this.ige.bjRoomsClient.indicateSeat(roomId, seatId);
		
		switch (handState) {
			case 0:
				handStateText = 'Lose';
				
				// Clear all the chips from this seat's position towards
				// the dealer
				if (this.showAnimation) {
					// Animation is on so tween the chip removal
					while (chipCount--) {
						var chipEnt = chipEntities[chipCount];
						// Tween X, Y and Opacity
						this.ige.entities.tweenStart(
							chipEnt,
							{
								translateX: this.seatPositions[5][0],
								translateY: this.seatPositions[5][1],
								opacityX: 0,
							},
							1000,
							{
								easing: 'inQuad',
								startTime: currentTime + animStart
							}
						);
						
						animStart += 100;
					}
				} else {
					// Animation is off, just remove the chips
					while (chipCount--) {
						this.ige.entities.remove(chipEntities[chipCount]);
					}
				}
			break;
			case 1:
				handStateText = 'Win';
				
				// Clear all the chips from this seat's position towards
				// the player
				if (this.showAnimation) {
					// Animation is on so tween the chip removal
					while (chipCount--) {
						var chipEnt = chipEntities[chipCount];
						// Tween X, Y and Opacity
						this.ige.entities.tweenStart(
							chipEnt,
							{
								translateX: this.seatPositions[seatId][0],
								translateY: this.seatPositions[seatId][1],
								opacityX: 0,
							},
							1000,
							{
								easing: 'inQuad',
								startTime: currentTime + animStart
							}
						);
						
						animStart += 100;
					}
				} else {
					// Animation is off, just remove the chips
					while (chipCount--) {
						this.ige.entities.remove(chipEntities[chipCount]);
					}
				}
			break;
			case 2:
				handStateText = 'Push';
			break;
		}
		
		this.log('Server says that the hand at seat ' + seatId + ' was a ' + handStateText);
	},
	
});