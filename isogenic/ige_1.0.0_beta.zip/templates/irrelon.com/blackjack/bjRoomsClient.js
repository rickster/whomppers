BjRoomsClient = new IgeClass({
	ige: null, // Holds a reference to the engine instance
	
	init: function (engine) {
		this._className = 'BjRoomsClient';
		this.ige = engine;
		
		// Register ourself in the engine object
		this.ige.bjRoomsClient = this;
	},
	
	ready: function () {
		// We want to listen for CRUD events so we can do the CRUD to
		// the respective DOM elements of the room being CRUDed
		this.ige.bjRooms.on('afterCreate', this.bind(this.afterCreate));
		this.ige.bjRooms.on('afterUpdate', this.bind(this.afterUpdate));
		this.ige.bjRooms.on('beforeRemove', this.bind(this.beforeRemove));
		
		// Hook the viewport resize event to auto-scale cards to visible size
		// for mobile devices so we can see the cards on small screens
		this.ige.viewports.on('afterResize', this.bind(this.resized));
		
		// Hook button events from the UI class
		this.ige.entities.on('ui_up', this.bind(this.buttonClick));
	},
	
	resized: function () {
		if (window.innerHeight < 400 || window.innerWidth < 400) {
			// The screen size is pretty small, let's
			// increase the card size
			this._cardScale = 3.0;
		} else {
			this._cardScale = 1.0;
		}
	},
		
	afterCreate: function (pItem) {
		// Create the DOM element for this room
		$('<div id="' + pItem.room_id + '" class="roomItem"></div>').appendTo('#roomList');
		$('<div class="name">' + pItem.room_name + '</div>').appendTo('#' + pItem.room_id + '.roomItem');
		$('<div class="sitting">Players: ' + pItem.room_sitting_count + '</div>').appendTo('#' + pItem.room_id + '.roomItem');
		$('<div class="users">Watching: ' + pItem.room_user_count + '</div>').appendTo('#' + pItem.room_id + '.roomItem');
		
		$('.roomItem').click(function (e) {
			e.preventDefault();
			e.stopPropagation();			
			$('#roomList').hide();
			$('#joining').show();
			
			window.ige.bjRooms.log('Joining room: ' + this.id);
			window.ige.bjRoomsClient.askServerTo_joinRoom(this.id);
		});
		
		this.log('New room created: ' + pItem.room_id);
	},
	
	afterUpdate: function (pItem) {
		// Update the room details
		$('#' + pItem.room_id + ' .name').html(pItem.room_name);
		$('#' + pItem.room_id + ' .sitting').html('Players: ' + pItem.room_sitting_count);
		$('#' + pItem.room_id + ' .users').html('Watching: ' + pItem.room_user_count);
	},
	
	beforeRemove: function (pItem) {
		$('#' + pItem.room_id).remove();
		this.log('Room removed: ' + pItem.room_id);
	},
	
	buttonClick: function (entity) {
		switch (entity.button_class) {
			case 'sitButton':
				var roomId = entity.room_id;
				var seatId = entity.seat_id;
				
				this.ige.bjRooms.log('Sitting down at position ' + seatId + ' in room ' + roomId);
				this.ige.bjRoomsClient.askServerTo_sitDown(
					roomId,
					seatId
				);
			break;
			
			case 'leaveRoomButton':
				var roomId = entity.room_id;
				
				this.ige.bjRooms.log('Leaving room: ' + roomId);
				this.ige.bjRoomsClient.askServerTo_leaveRoom(roomId);
			break;
		}
	},
	
	askServerTo_joinRoom: function (roomId) {
		this.ige.network.send('joinRoom', {room_id:roomId});
	},
	
	serverToldUsWe_joinedRoom: function (data, sessionId) {
		this.log('Server has told us to join room: ' + data.room_id);
		var room = this.ige.bjRooms.read(data.room_id);
		this.ige.bjGamesClient.currentBet[data.room_id] = 0;
		this.ige.bjGamesClient.currentChipId[data.room_id] = 0;
		
		// Create the room engine items like the screen, map, viewport etc
		var playScreenId = 'playScreen_' + data.room_id;
		this.ige.screens.create({
			room_id: data.room_id,
			screen_id: playScreenId, // The screen's ID - this must be unique
			screen_background_color: '#1f3036', // The background colour (HTML background-color property)
			screen_html: './html/playScreen.html', // The html file to load as the screens HTML content
			screen_parent_id: 'mainView', // The id of the DOM element to append the screen element to
			screen_persist: PERSIST_DISABLED, // The screen's persist setting
			screen_locale: LOCALE_EVERYWHERE, // Only exists on the server unless explicitly sent to a client
		}, this.bind(function (newScreen) {
			if (newScreen.screen_id == playScreenId) {
				// Assign the room id as data to the screen element
				$('#' + playScreenId).data('room_id', data.room_id);
				$('#' + playScreenId + ' .chip').
				click(function (e) {
					var roomId = $(e.target).data('room_id');
					if (e.preventDefault) {
						e.preventDefault();
					} else {
						e.returnValue = false;
					}
					e.stopPropagation();
					window.ige.bjGamesClient.selectBettingChip(roomId, e.target.id);
				}).
				data('room_id', data.room_id);
				
				$('<div class="actionButton minus">-</div>').
				data('room_id', data.room_id).
				click(function (e) {
					var roomId = $(e.target).data('room_id');
					if (e.preventDefault) {
						e.preventDefault();
					} else {
						e.returnValue = false;
					}
					e.stopPropagation();
					window.ige.bjGamesClient.decreaseBet(roomId);
				}).
				appendTo('#' + playScreenId + ' .betControl');
				
				$('<div class="currentBet">0</div>').appendTo('#' + playScreenId + ' .betControl');
				
				$('<div class="actionButton plus">+</div>').
				data('room_id', data.room_id).
				click(function (e) {
					var roomId = $(e.target).data('room_id');
					if (e.preventDefault) {
						e.preventDefault();
					} else {
						e.returnValue = false;
					}
					e.stopPropagation();
					window.ige.bjGamesClient.increaseBet(roomId);
				}).
				appendTo('#' + playScreenId + ' .betControl');
				
				$('<div class="actionButton ok">OK</div>').
				data('room_id', data.room_id).
				click(function (e) {
					var roomId = $(e.target).data('room_id');
					if (e.preventDefault) {
						e.preventDefault();
					} else {
						e.returnValue = false;
					}
					e.stopPropagation();
					window.ige.bjGamesClient.completeBet(roomId);
				}).
				appendTo('#' + playScreenId + ' .betControl');
			}
		}));
		
		this.ige.maps.create({
			template_id: 'tableMap',
			map_id: 'map_' + data.room_id,
			map_locale: LOCALE_EVERYWHERE, // Only exists on the server unless explicitly sent to a client
			room_id: data.room_id,
		});
		
		// Create camera
		this.ige.cameras.create({
			template_id:'tableCamera',
			camera_id:'camera_' + data.room_id, // Camera ID - must be unique
			camera_transform: {
				translate: [0, 0, 0, false, true], // position
				//scaleTarget: [20, 14, 0, true], // scale to target size
				scale: [1.0, 1.0, 1.0], // scale
				rotate: [0.0, 0.0, 0.0], // rotation
				opacity: [1.0, 1.0, 1.0], // opacity
				origin: [0.5, 0.5], // origin point (anchor)
				debug:true, // draw bounds and debug info
			},
			camera_autoscale: true, // Autoscale this camera to the viewport it is looking at
			camera_width: 1200,
			camera_locale: LOCALE_EVERYWHERE, // Only exists on the server unless explicitly sent to a client
			//camera_height: 960,
			room_id:data.room_id,
		});
		
		// Create viewport
		this.ige.viewports.create({
			template_id:'tableViewport',
			viewport_id:'viewport_' + data.room_id, // Viewport ID - must be unique
			viewport_locale: LOCALE_EVERYWHERE, // Only exists on the server unless explicitly sent to a client
			map_id:'map_' + data.room_id,
			camera_id:'camera_' + data.room_id,
			screen_id: playScreenId, // The screen this viewport belongs to
			room_id:data.room_id,
		});
		
		this.ige.entities.create({
			template_id: 'tableEntity',
			entity_id: 'table_' + data.room_id, // Entity ID - must be unique
			entity_transform: {
				translate: [0, -2, 0, false, true], // position
				//scaleTarget: [20, 14, 0, true], // scale to target size
				scale: [1.0, 1.0, 1.0], // scale
				rotate: [0.0, 0.0, 0.0], // rotation
				opacity: [1.0, 1.0, 1.0], // opacity
				origin: [0.5, 0.5], // origin point (anchor)
				debug:false, // draw bounds and debug info
			},
			map_id:'map_' + data.room_id, // The map the entity exists on
			room_id:data.room_id,
		});
		
		var seatArrowPositions = [
			[400, 100, -90.0],
			[160, 160, -90.0],
			[-90, 180, -90.0],
			[-340, 140, -90.0],
			[-560, 50, -90.0],
			[-90, -170, -90.0],
		];
		
		var seatPositions = [
			[482, 76, -25.0],
			[246, 152, -12.5],
			[0, 170, 0.0],
			[-246, 152, 12.5],
			[-482, 76, 25.0],
			[0, -170, 0.0],
		];
		
		var chipPositions = [
			[432, -65],
			[210, 0],
			[0, 20],
			[-210, 0],
			[-432, -65]
		];
		
		for (var seatId = 0; seatId <= 5; seatId++) {
			// Create seat indicator entity for this seat
			this.ige.entities.create({
				template_id: 'arrowEntity',
				entity_id: 'seatArrow_' + data.room_id + '_' + seatId,
				entity_hide: true,
				entity_transform: {
					translate: [seatArrowPositions[seatId][0], seatArrowPositions[seatId][1], 0, false, false], // position
					scale: [1.0, 1.0, 1.0], // scale
					rotate: [seatArrowPositions[seatId][2], 0.0, 0.0], // rotation
					opacity: [1.0, 1.0, 1.0], // opacity
					origin: [0.5, 0.5], // origin point (anchor)
					debug:false, // draw bounds and debug info
				},
				map_id:'map_' + data.room_id, // The map the entity exists on
				room_id:data.room_id,
			});
			
			// Create the card value entity for this seat
			this.ige.entities.create({
				template_id: 'valueEntity',
				entity_id: 'uiCardValue_' + data.room_id + '_' + seatId,
				entity_hide: true,
				entity_transform: {
					translate: [seatPositions[seatId][0], seatPositions[seatId][1], 0, false, false], // position
					scale: [3.0, 3.0, 1.0], // scale
					rotate: [seatPositions[seatId][2], 0.0, 0.0], // rotation
					opacity: [1.0, 1.0, 1.0], // opacity
					origin: [0.5, 0.5], // origin point (anchor)
					debug:false, // draw bounds and debug info
				},
				map_id:'map_' + data.room_id, // The map the entity exists on
				room_id:data.room_id,
				_valueLabel:0,
			});
			
			if (seatId < 5) {
				// Create the chip value entity for this seat
				this.ige.entities.create({
					template_id: 'valueEntity',
					entity_id: 'uiChipValue_' + data.room_id + '_' + seatId,
					entity_hide: true,
					entity_transform: {
						translate: [chipPositions[seatId][0], chipPositions[seatId][1], 0, false, false], // position
						scale: [3.0, 3.0, 1.0], // scale
						rotate: [seatPositions[seatId][2], 0.0, 0.0], // rotation
						opacity: [1.0, 1.0, 1.0], // opacity
						origin: [0.5, 0.5], // origin point (anchor)
						debug:false, // draw bounds and debug info
					},
					map_id:'map_' + data.room_id, // The map the entity exists on
					room_id:data.room_id,
					_valueLabel:0,
					_valueLabelBackOpacity:0.5,
				});
				
				// Create the sit down button for this seat
				this.ige.entities.create({
					template_id: 'blueButton',
					entity_id: 'sitButton_' + data.room_id + '_' + seatId,
					entity_transform: {
						translate: [seatPositions[seatId][0], seatPositions[seatId][1], 0],
						scale: [0.7, 0.7, 0.7],
						rotate: [seatPositions[seatId][2], 0, 0],
						origin: [0.5, 0.5, 0.5],
						opacity: [1, 1, 1],
					},
					entity_text: {
						value: 'SIT HERE',
						color: '#ffffff',
						font: 'bold 30px Calibri',
						origin: [0.5, 0.5],
					},
					button_class: 'sitButton',
					room_id: data.room_id,
					seat_id: seatId,
					map_id: 'map_' + data.room_id,
				});
			}
		}
		
		// Create the hit and stand UI elements
		this.ige.entities.create({
			template_id: 'blueButton',
			entity_id: 'hitButton_' + data.room_id,
			entity_transform: {
				translate: [-95, 0, 0],
				scale: [0.7, 0.7, 0.7],
				rotate: [0, 0, 0],
				origin: [0.5, 0.5, 0.5],
				opacity: [1, 1, 1],
			},
			entity_text: {
				value: 'HIT',
				color: '#ffffff',
				font: 'bold 30px Calibri',
				origin: [0.5, 0.5],
			},
			button_class: 'hitButton',
			entity_hide: true,
			room_id: data.room_id,
			map_id: 'map_' + data.room_id,
		});
		
		this.ige.entities.create({
			template_id: 'redButton',
			entity_id: 'standButton_' + data.room_id,
			entity_transform: {
				translate: [95, 0, 0],
				scale: [0.7, 0.7, 0.7],
				rotate: [0, 0, 0],
				origin: [0.5, 0.5, 0.5],
				opacity: [1, 1, 1],
			},
			entity_text: {
				value: 'STAND',
				color: '#ffffff',
				font: 'bold 30px Calibri',
				origin: [0.5, 0.5],
			},
			button_class: 'standButton',
			entity_hide: true,
			room_id: data.room_id,
			map_id: 'map_' + data.room_id,
		});
		
		// Leave room button
		this.ige.entities.create({
			template_id: 'blueButton',
			entity_id: 'leaveRoomButton_' + data.room_id,
			entity_transform: {
				translate: [-520, -180, 0],
				scale: [0.7, 0.7, 0.7],
				rotate: [0, 0, 0],
				origin: [0.5, 0.5, 0.5],
				opacity: [1, 1, 1],
			},
			entity_text: {
				value: 'LEAVE ROOM',
				color: '#ffffff',
				font: 'bold 26px Calibri',
				origin: [0.5, 0.5],
			},
			button_class: 'leaveRoomButton',
			entity_hide: false,
			room_id: data.room_id,
			map_id: 'map_' + data.room_id,
		});
		
		this.ige.screens.setCurrent(playScreenId);
		
		// Undo the show/hide on the room screen
		$('#roomList').show();
		$('#joining').hide();
		
		this.log('Room setup complete');
	},
	
	askServerTo_leaveRoom: function (roomId) {
		this.ige.network.send('leaveRoom', {
			room_id: roomId
		});
	},
	
	serverToldUsWe_leftRoom: function (data, sessionId) {
		// The server has told us to leave the room
		// Clear up all room engine-based items
		var viewport = this.ige.viewports.byId['viewport_' + data.room_id];
		var camera = viewport.$local.$camera;
		var map = viewport.$local.$map;
		var entities = this.ige.entities.byMapId[map.map_id];
		var tempScreen = this.ige.screens.byId['playScreen_' + data.room_id];
		
		// Switch the screen back to the room list
		this.ige.screens.setCurrent('roomListScreen');
		
		// Remove all entities
		this.log('Removing room entities...');
		this.ige.entities.remove(entities);
		this.log('Removing room viewports...');
		this.ige.viewports.remove(viewport);
		this.log('Removing room cameras...');
		this.ige.cameras.remove(camera);
		this.log('Removing room maps...');
		this.ige.maps.remove(map);
		this.log('Removing room screens...');
		this.ige.screens.remove(tempScreen);
		
		this.log('Left room successfully');
	},
	
	askServerTo_sitDown: function (roomId, seatId) {
		this.ige.network.send('sitDown', {
			room_id: roomId,
			seat_id: seatId
		});
	},
	
	serverToldUsWe_satDown: function (data, sessionId) {
		var room = data[0];
		var seatId = data[1];
		var sessionId = data[2];
		var username = data[3];
		
		// Check if the user sitting down is us via the sessionId
		if (sessionId == this.ige.network.sessionId) {
			this.log('Server has told us we are sitting down in room ' + room.room_id + ' at seat id ' + seatId);
			
			// Hide the sit down button for this seat
			this.ige.entities.hide('sitButton_' + room.room_id + '_' + seatId);
			this.log('Sit down complete');
		} else {
			// The server is telling us a seat has been taken
			// Hide the sit down button for this seat
			this.ige.entities.hide('sitButton_' + room.room_id + '_' + seatId);
			this.log('Player "' + username + '" just sat down in room ' + room.room_id + ' at seat id ' + seatId);
		}
	},
	
	serverToldUsWe_stoodUp: function (data, sessionId) {
		var roomId = data[0];
		var seatId = data[1];
		var room = this.ige.bjRooms.read(roomId);
		
		this.log('Player standing up from room ' + room.room_id + ' at seat id ' + seatId);
		
		// Show the sit down button for this seat
		this.ige.entities.show('sitButton_' + room.room_id + '_' + seatId);
	},
	
	showBetControl: function (roomId) {
		$('#playScreen_' + roomId + ' #betControls').show();
	},
	
	hideBetControl: function (roomId) {
		$('#playScreen_' + roomId + ' #betControls').hide();
	},
	
	indicateSeat: function (roomId, seatId) {
		// Set all the indicator entities to hidden except
		// the seat we are operating on
		for (var i = 0; i <= 5; i++) {
			if (i != seatId) {
				this.ige.entities.hide(this.ige.entities.byId['seatArrow_' + roomId + '_' + i]);
			} else {
				this.ige.entities.show(this.ige.entities.byId['seatArrow_' + roomId + '_' + i]);
			}
		}
	},
	
	clearSeatIndicators: function (roomId) {
		for (var i = 0; i <= 5; i++) {
			this.ige.entities.hide(this.ige.entities.byId['seatArrow_' + roomId + '_' + i]);
		}
	},
});