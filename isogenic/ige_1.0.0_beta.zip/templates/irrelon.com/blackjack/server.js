/* CEXCLUDE */
// Your server-specific code goes in this class
GameServer = new IgeClass({
	ige: null, // Holds the engine instance
	
	init: function (engine) {
		this._className = 'GameServer';
		this.ige = engine;
		
		this._users = this._users || [];
		this._users.byUsername = this._users.byUsername || [];
		this._users.bySessionId = this._users.bySessionId || [];
	},
	
	///////////////////////////////
	// START OF REQUIRED METHODS //
	///////////////////////////////
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		this.ige.network.on('clientConnect', this.bind(this._clientConnect));
		this.ige.network.on('clientDisconnect', this.bind(this._clientDisconnect));
		this.ige.network.on('auth', this.bind(this._auth));
	},
	
	// This is called when the engine wants you to load all your modules
	modules: function () {},
	
	// This is called when the engine wants you to hook module events
	moduleHooks: function () {},
	
	// This is called when the engine wants you to load all your data
	data: function () {
		this.ige.loadData({
			'templates':{},
			'screens':{},
			'animations':{},
			'assets':{},
			'users':{},
			'entities':{}
		});
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		this.setupWorld(this.bind(function () { // Call our setupWorld() method and pass a callback
			this.ige.network.allowConnections(true);
			this.ige.start();
			
			this.log('Engine Started Successfully');
		}));
	},
	///////////////////////////////
	// END OF REQUIRED METHODS   //
	///////////////////////////////
	
	///////////////////////////////
	// START OF SERVER METHODS   //
	///////////////////////////////
	/** setupWorld - Creates all the world items that the engine will use
	to render our scene. {
		category:"method",
		arguments: [{
			name:"callback",
			type:"function",
			desc:"The callback method to execute when the setupWorld() method has completed.",
		}],
	} **/
	setupWorld: function (callback) {
		this.ige.assets.on('allAssetsLoaded', this.bind(function () {
			this.setupTemplates();
			this.setupScreens();
			this.setupMaps();
			this.setupCameras();
			this.setupViewports();
			this.setupBackgrounds();
			this.setupEntities();
			this.setupUi();
			this.setupRooms();
			
			callback();
		}), null, true);
		
		this.setupAssets();
	},
	
	/** setupAssets - Creates the assets our game will use. {
		category:"method",
	} **/
	setupAssets: function () {
		// Create our assets
		this.ige.assets.create({
			asset_id: 'button',
			asset_image_url: './assets/ui/buttons2.png',
			asset_sheet_width: 2,
			asset_sheet_height: 2,
			asset_sheet_enabled: true,
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'card',
			asset_image_url: './assets/sprites/cardSheet.png',
			asset_sheet_width: 13,
			asset_sheet_height: 4,
			asset_sheet_enabled: true,
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'chip',
			asset_image_url: './assets/sprites/chipsSheet.png',
			asset_sheet_width: 5,
			asset_sheet_height: 2,
			asset_sheet_enabled: true,
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'cardBack',
			asset_image_url: './assets/sprites/cardBack.png',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'table',
			asset_image_url: './assets/backgrounds/tableExtended.png',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'arrow',
			asset_image_url: './assets/sprites/indicatorArrow.png',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'valueLabel',
			asset_self_render: true,
			asset_render_script: './assets/ui/valueLabel.js',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'text',
			asset_self_render: true,
			asset_render_script: './assets/ui/text.js',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: ASSET_RENDER_MODE_2D,
		});
	},
	
	/** setupTemplates - Creates the templates our game will use. {
		category:"method",
	} **/
	setupTemplates: function () {
		// Create our templates
		this.ige.templates.create({
			template_id: 'tableMap', // Template ID - must be unique
			template_contents: { // The template's contents
				map_tilesize:40, // The size in pixels of the map tiles
				map_use_dirty:false, // If dirty-rectangles should be used when rendering the map
				map_use_dirty2:true,
				map_dirty_grid:false, // Show the dirty rectangle grid? (for debugging)
				map_debug_dirty:false, // Show the dirty rectangle debug data? (for debugging)
				map_debug_entities:true, // Show entity bounding boxes and depth values? (for debugging)
				map_dirty_width:150, // The width of each dirty rectangle
				map_dirty_height:150, // The height of each dirty rectangle
				map_render_mode:MAP_RENDER_MODE_2D, // What render mode this map uses, isometric or 2d?
				map_render:true, // If the map should be rendered or not, used for skipping this map in rendering
				map_layers:[ // The map's layer array
					{ // Layer 0
						layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
						layer_type:LAYER_TYPE_HTML, // Is this DOM or CANVAS based?
						layer_entity_types: LAYER_BACKGROUNDS // What type of entities layer contains
					},
					{ // Layer 1
						layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
						layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
						layer_entity_types: LAYER_TILES, // What type of entities layer contains
						layer_draw_grid: false, // If we should draw a debug tile grid (debugging)
					},
					{ // Layer 2
						layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
						layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
						layer_entity_types: LAYER_SPRITES // What type of entities layer contains
					},
					{ // Layer 3
						layer_auto_mode:LAYER_AUTO_NONE,// Not currently used, always set to LAYER_AUTO_NONE
						layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
						layer_entity_types: LAYER_UI // What type of entities layer contains
					},
				],
				map_persist:PERSIST_DISABLED, // The map's persist setting
			}
		});
		
		this.ige.templates.create({
			template_id: 'tableViewport', // Template ID - must be unique
			template_contents: { // The template's contents
				viewport_tile_ratio: 1, // The ratio from map tilesize to tile height (0.5 = height = half the width)
				viewport_clipping: false, // Should we draw entities that are outside the viewing area?
				/*viewport_background_color:'#005aff',*/
				viewport_anchor_point: [0, 0], // HTML element's background-color
				viewport_autoSize: true, // Should this viewport auto-size to fill the parent element?
				viewport_container: { width: 800, height: 600 }, // The container element's initial dimensions
				viewport_locale: LOCALE_EVERYWHERE + LOCALE_DB, // The viewport's locale
				viewport_persist: PERSIST_DISABLED, // The viewport's persist setting
				panLayer:{ // The viewport's pan layer definition
					id: 'panLayer', // pan layer's ID
					padding: 0.0, // The amount of padding around the viewport to provide the element
					zStart: 0,
				},
			}
		});
		
		this.ige.templates.create({
			template_id: 'tableCamera', // Template ID - must be unique
			template_contents: { // The template's contents		
				camera_x: 0, // The camera's x co-ordinate
				camera_y: 0, // The camera's y co-ordinate
				camera_z: 0, // The camera's z co-ordinate
				camera_scale: 1, // The camera's scale
				camera_zClipping:{ // The plane in which entities are drawn along the z-axis
					near: 0, // Draw entities from z:0
					far: 1, // Draw entities to z:1
				},
				camera_persist: PERSIST_DISABLED, // Camera's persist setting
			}
		});

		this.ige.templates.create({
			template_id: 'tableEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_TILE, // The entity is a tile
				entity_layer: LAYER_TILES, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'table', // The asset this entity will render from
			}
		});
				
		this.ige.templates.create({
			template_id: 'cardEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'card', // The asset this entity will render from
			},
		});
		
		this.ige.templates.create({
			template_id: 'cardBackEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'cardBack', // The asset this entity will render from
			},
		});
		
		this.ige.templates.create({
			template_id: 'chipEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'chip', // The asset this entity will render from
			},
		});
		
		this.ige.templates.create({
			template_id: 'arrowEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'arrow', // The asset this entity will render from
			},
		});
		
		this.ige.templates.create({
			template_id: 'valueEntity', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_UI, // The entity is an object
				entity_layer: LAYER_UI, // The map layer this entity will be rendered on
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'valueLabel', // The asset this entity will render from
			},
		});
		
		this.ige.templates.create({
			template_id: 'blueButton', // Template ID - must be unique
			template_contents: { // The template's contents
				asset_id: 'button',
				asset_sheet_frame: 1,
				ui: {
					type: UI_TYPE_BUTTON,
					states: {
						up: {
							asset_sheet_frame: 1,
							entity_text: {
								origin: [0.5, 0.5],
							},
							emit_event:true,
						},
						down: {
							asset_sheet_frame: 2,
							entity_text: {
								origin: [0.52, 0.53],
							},
							emit_event:false,
						},
					},
					state: UI_STATE_UP,
				},
				entity_layer: LAYER_UI, // The map layer this entity will be rendered on
				entity_disabled: false,
			}
		});
		
		this.ige.templates.create({
			template_id: 'redButton', // Template ID - must be unique
			template_contents: { // The template's contents
				asset_id: 'button',
				asset_sheet_frame: 3,
				ui: {
					type: UI_TYPE_BUTTON,
					states: {
						up: {
							asset_sheet_frame: 3,
							entity_text: {
								origin: [0.5, 0.5],
							},
							emit_event:true,
						},
						down: {
							asset_sheet_frame: 4,
							entity_text: {
								origin: [0.52, 0.53],
							},
							emit_event:false,
						},
					},
					state: UI_STATE_UP,
				},
				entity_layer: LAYER_UI, // The map layer this entity will be rendered on
				entity_disabled: false,
			}
		});
	},
	
	/** setupScreens - Creates the screens our game will use. {
		category:"method",
	} **/
	setupScreens: function () {
		// Create login screen
		this.ige.screens.create({
			screen_id:'login', // The screen's ID - this must be unique
			screen_background_color:'#1f3036', // The background colour (HTML background-color property)
			screen_html: './html/login.html', // The html file to load as the screens HTML content
			screen_parent_id: 'mainView', // The id of the DOM element to append the screen element to
			screen_persist:PERSIST_DISABLED, // The screen's persist setting
		});
		
		// Create room screen
		this.ige.screens.create({
			screen_id:'roomListScreen', // The screen's ID - this must be unique
			screen_background_color:'#1f3036', // The background colour (HTML background-color property)
			screen_html: './html/roomListScreen.html', // The html file to load as the screens HTML content
			screen_parent_id: 'mainView', // The id of the DOM element to append the screen element to
			screen_persist:PERSIST_DISABLED, // The screen's persist setting
		});
	},
	 
	/** setupMaps - Creates the maps our game will use. {
		category:"method",
	} **/
	setupMaps: function () {
		// We don't need any maps at the moment, they will be created
		// when game tables are created and will only exist client-side
	},
	
	/** setupCameras - Creates the cameras our game will use. {
		category:"method",
	} **/
	setupCameras: function () {
		// We don't need any cams server-side, they are created client-side
		// only when a user joins a table
	},
	 
	/** setupViewports - Creates the viewports our game will use. {
		category:"method",
	} **/
	setupViewports: function () {
		// Viewports are not defined server-side since they will be created
		// when a user joins a room so we create and destroy them client-side
	},
	
	/** setupBackgrounds - Creates the backgrounds our game will use. {
		category:"method",
	} **/
	setupBackgrounds: function () {
		// No backgrounds so nothing to do here
	},	
	 
	/** setupEntities - Creates the entities our game will use. {
		category:"method",
	} **/
	setupEntities: function () {
		// No entities server-side
	},
	
	/** setupUi - Creates the UI our game will use. {
		category:"method",
	} **/
	setupUi: function () {
		// No UI server-side
	},
	
	/** setupRooms - Creates initial rooms. {
		category:"method",
	} **/
	setupRooms: function () {
		// Create a single room
		for (var i = 0; i < 1; i++) {
			this.ige.bjRooms.create({
				room_name:'BlackJack ' + (i + 1)
			});
		}
		/*
		this.ige.bjRooms.create({
			room_name:'BlackJack 2'
		});
		*/
	},
	
	/** _clientConnect - Called when a client connects. {
		category:"method",
		arguments:[{
			name:"sessionId",
			type:"string",
			desc:"The session id of the connected client.",
		}]
	} **/
	_clientConnect: function (sessionId) {
		// Send the client the asset list to load and wait for a response
		// Send all data
		this.ige.templates.netSendAll(sessionId);
		this.ige.assets.netSendAll(sessionId);
		
		// Send the initial screens
		this.ige.screens.netSendById(sessionId, 'login');
		this.ige.screens.netSendById(sessionId, 'roomListScreen');
		
		// Now wait until the client reports that it has loaded all assets
		this.ige.network.on('clientAllAssetsLoaded', this.bind(function (data, clientId) {
			this.ige.screens.setCurrent('login', clientId);
			this.ige.startClient(clientId);
		}), null, true); // Forth argument true means a one-shot event listener, fires then deletes
	},
	
	_clientDisconnect: function (sessionId) {
		this.ige.bjRoomsServer.clientRequestedTo_leaveRoom(null, sessionId); // Passing null leaves all rooms
		var user = this._users.bySessionId[sessionId];
		delete this._users.bySessionId[sessionId];
		
		if (user) {
			delete this._users.byUsername[user.username];
			delete user;
		}
	},
	/////////////////////////////
	// END OF SERVER METHODS   //
	/////////////////////////////
	
	//////////////////////////////////
	// START OF GAME FLOW METHODS   //
	//////////////////////////////////
	_auth: function (data, sessionId) {
		this.log('User auth received for username: ' + data.username);
		
		var user = {
			username:data.username,
			session_id:sessionId,
		}
		
		if (!this._users.bySessionId[sessionId] && !this._users.byUsername[user.username]) {
			// There is no user for this session id
			
			// Store the user under the new session
			this._users.bySessionId[sessionId] = user;
			this._users.byUsername[user.username] = user;
			
			// Tell the client their auth is accepted
			this.ige.network.send('auth', {status:'success'}, sessionId);
			
			// Sync the client with the current room data
			this.ige.bjRooms.netSendAll(sessionId);
			
			// Remote-switch the client's screen to the roomListScreen
			this.ige.screens.setCurrent('roomListScreen', sessionId);
		} else {
			// The user has already auth'd for this session, reject the auth
			this.ige.network.send('auth', {status:'failed'}, sessionId);
		}
	},
	////////////////////////////////
	// END OF GAME FLOW METHODS   //
	////////////////////////////////
	
});
/* CEXCLUDE */