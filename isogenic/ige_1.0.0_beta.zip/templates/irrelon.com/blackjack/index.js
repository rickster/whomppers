// Your game code goes that runs on both client AND server goes inside this class
Game = new IgeClass({
	ige: null, // Contains our engine instance
	client: null, // Contains our game client instance
	server: null, // Contains our game server instance
	version: '0.0.1', // The game version number
	
	init: function (engine, client, server) {
		this._className = 'Game';
		this.ige = engine;
		this.client = client;
		this.server = server;
		this.log('Game version ' + this.version);
	},
	
	///////////////////////////////
	// START OF REQUIRED METHODS //
	///////////////////////////////
	// This is called when the engine wants you to set all your network settings
	networkInit: function () {
		this.ige.network.useBison(false);
		this.ige.network.useManifest(true);
		this.ige.network.setProvider('socketio');
		this.ige.network.debug = false;
		
		if (this.ige.isServer) { // If the engine is running as a server...
			this.ige.network.providerInit(); // Initialise the network provider
			this.ige.network.start(); // Start networking
		}
		if (!this.ige.isServer) { // If the engine is running as a client...
			this.ige.network.setOptions({
				gameServer:'http://blackjack-io1.gamehost.isogenicengine.com:80', // Set the game server url
				reconnect: false, // Tell the client not to reconnect automatically
			});
			this.ige.network.useStats(true); // Tell the networking system to keep stats data for debug
			this.ige.network.providerInit(); // Initialise the network provider
		}
	},
	
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.engineHooks();
		}
		/* CEXCLUDE */
		if (!this.ige.isServer) {
			this.client.engineHooks();
		}
	},
	
	// This is called when the engine wants you to register all your network commands
	networkCommands: function () {
		this.ige.network.registerCommand('clientAllAssetsLoaded');
		this.ige.network.registerCommand('auth');
	},
	
	// This is called when the engine wants you to load all your modules
	modules: function () {
		// Create the editor instance
		//new IgeEditor(this.ige);
	},
	
	// This is called when the engine wants you to hook module events
	moduleHooks: function () {},
	
	// This is called when the engine wants you to load all your data
	data: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.server.data();
		}
		/* CEXCLUDE */
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		this.ige.setOption('logPerf', true);
		
		/* CEXCLUDE */
		if (this.ige.isServer) {
			// Create blackjack class server instance
			new BjRoomsServer(this.ige);
			new BjRooms(this.ige);
			new BjGamesServer(this.ige);
			new BjGames(this.ige);
			
			this.ige.bjRooms.ready();
			this.ige.bjGames.ready();
			
			this.server.ready();
		}
		/* CEXCLUDE */
		
		if (!this.ige.isServer) {
			// Create blackjack class client instance
			new BjRoomsClient(this.ige);
			new BjRooms(this.ige);
			new BjGamesClient(this.ige);
			new BjGames(this.ige);
			
			this.ige.bjRooms.ready();
			this.ige.bjGames.ready();
			
			this.client.ready();
		}
	},
	///////////////////////////////
	// END OF REQUIRED METHODS   //
	///////////////////////////////
	
});
