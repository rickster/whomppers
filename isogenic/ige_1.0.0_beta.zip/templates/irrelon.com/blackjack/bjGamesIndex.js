BjGames = new IgeClass({
	Extends: [IgeCollection, IgeItem, IgeNetworkItem, IgeEvents],
	
	init: function (engine) {
		// Set the class name so that log entries show where they come from
		// this should be the same as the name of the variable you are assigning
		// this new class to (see first line of code in this file)
		this._className = 'BjGames';
		this.collectionId = 'game';
		this.ige = engine;
		this.engine = engine;
		
		// Register ourselves as an engine property
		this.engine.bjGames = this;
		
		// Define some class variables
		this.byIndex = [];
		this.byId = [];
		this.byRoomId = [];
		
		this.suitNames = [
			'Diamonds',
			'Clubs',
			'Hearts',
			'Spades',
			'FaceDown',
		];
		
		this.cardNames = [
			'null',
			'Ace',
			'Two',
			'Three',
			'Four',
			'Five',
			'Six',
			'Seven',
			'Eight',
			'Nine',
			'Ten',
			'Jack',
			'Queen',
			'King'
		];
		
		this.cardValues = [
			'0',
			'1',
			'2',
			'3',
			'4',
			'5',
			'6',
			'7',
			'8',
			'9',
			'10',
			'10',
			'10',
			'10'
		];		
		
		this.states = new IgeEnum([
			'stopped', // The game is waiting for players
			'starting', // The game is counting down to start
			'started', // The game has started
			'ante', // The game is asking players for their bets
			'dealing', // The game is dealing cards to the players
			'action', // The game is processing player choices
			'dealer', // The game is processing player choices
			'resolving', // The game is resolving the result of the round
			'resetting', // The game is resetting
		]);
		
		// Check if we have a network
		if (this.engine._IgeNetwork) {
			// Call the networkInit method of this class
			this.networkInit();
		}
		
		/* CEXCLUDE */
		if (this.engine.isServer) {
			// Remove any non-persistent entries from the DB
			this.dbRemove({room_persist:false});
			
			// Load any rooms currently in the DB
			this.dbLoadAll();
		}
		/* CEXCLUDE */
		
		this.log('Init complete');
	},
	
	networkInit: function () {
		// Network CRUD Commands
		if (this.ige.isServer) {
			this.ige.network.registerCommand(
				'changedGameState' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'timedOut' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'shouldDecideBet' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'areReceivingDealComplete' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'shouldDecideAction' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'areReceivingNewCard' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'areReceivingHandResolve' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'areReceivingFundsChange' // The network command name
				// We don't want to execute code if receiving this command on the server
			);
			this.ige.network.registerCommand(
				'bet', // The network command name
				this.ige.bjGamesServer.bind(this.ige.bjGamesServer.clientRequestedTo_bet, true)// When receiving as server
			);
			this.ige.network.registerCommand(
				'hit', // The network command name
				this.ige.bjGamesServer.bind(this.ige.bjGamesServer.clientRequestedTo_hit, true)// When receiving as server
			);
			this.ige.network.registerCommand(
				'stand', // The network command name
				this.ige.bjGamesServer.bind(this.ige.bjGamesServer.clientRequestedTo_stand, true)// When receiving as server
			);
		}
		
		if (!this.ige.isServer) {
			this.ige.network.registerCommand(
				'changedGameState', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_changedGameState, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'timedOut', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_timedOut, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'shouldDecideBet', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_shouldDecideBet, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'areReceivingDealComplete', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_areReceivingDealComplete, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'shouldDecideAction', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_shouldDecideAction, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'areReceivingNewCard', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_areReceivingNewCard, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'areReceivingHandResolve', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_areReceivingHandResolve, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'areReceivingFundsChange', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_areReceivingFundsChange, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'bet', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_bet, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'hit', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_hit, true)// When receiving as client
			);
			this.ige.network.registerCommand(
				'stand', // The network command name
				this.ige.bjGamesClient.bind(this.ige.bjGamesClient.serverToldUsWe_stand, true)// When receiving as client
			);
		}
		
		return true;
	},
	
	ready: function () {
		/* CEXCLUDE */
		if (this.ige.isServer) {
			this.ige.bjGamesServer.ready();
		}
		/* CEXCLUDE */
		if (!this.ige.isServer) {
			this.ige.bjGamesClient.ready();
		}
	},
	
	/** _itemDefaults - Called by the IgeItem class which this class extends
	when creating a new item. Here you can define any object properties that
	are default across all items of this class. If this method returns false
	the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemDefaults: function (pItem) {
		this.ensureLocalExists(pItem);
		/* CEXCLUDE */
		if (this.engine.isServer) {
			this.ensurePersistExists(pItem);
			pItem.game_locale = LOCALE_SERVER_ONLY + LOCALE_DB; // Propagate everywhere and store in the DB
		}
		/* CEXCLUDE */
		this.ensureIdExists(pItem);
		
		// Setup the game arrays
		pItem.$local.$cardsInDeck = []; // Holds the current deck of cards in their current order
		pItem.$local.$cardsOnTable = []; // Holds the current cards on the table (out of the deck)
		pItem.$local.$cardsBySeat = []; // Holds the cards that each seat currently has
		pItem.$local.$dealerCards = []; // Holds the cards the dealer has
		pItem.$local.$betsBySeat = []; // Holds the bets that each seat currently has
		pItem.$local.$gameState = this.states.stopped; // Holds the current game state
		
		// Set to true to output network propagation debug
		// info as the item passes through the engine's networking stack
		pItem.propagate_trace = false;
		
		return true;
	},
	
	/** _itemIntegrity - Called by the IgeItem class which this class extends
	when creating a new item. Checks the integrity of an item before it is allowed
	to be created. Here you can define custom checks to ensure an item being 
	created conforms to the standard your class requires. If this method returns
	false the create action will be cancelled. {
		category:"method",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be checked.",
		}],
	} **/
	_itemIntegrity: function (pItem) {
		// Check that this item does not already exist
		if (this.byId[pItem[this.collectionId + '_id']]) {
			this.log('Attempted to create a game that already exists with id: ' + pItem[this.collectionId + '_id'], 'info');
			return false;
		}
		
		// Check that the item's room exists
		var room = this.engine.bjRooms.byId[pItem.room_id];
		if (!room) {
			this.log('Cannot create game because the room it is assigned to control does not exist!', 'warning', pItem);
			return false;
		}
		
		// No integrity checks failed so return true to continue processing this item
		return true;
	},
	
	/** _create - The private method that is called by 'this.create' and does
	the actual creation part. {
		category:"method",
		engine_ver:"1.0.0",
		return: {
			type:"bool",
			desc:"Returns false on failure or null for any other reason.",
		},
		arguments: [{
			type:"object",
			name:"entity",
			desc:"The item object to be created.",
		}],
	} **/
	_create: function (pItem) {
		// Emit beforeCreate event and check that no listening method
		// wanted us to cancel the create process (they can return true)
		// to cancel an event because of the if statement below
		if (!this.emit('beforeCreate', pItem)) {
			// Add seats to this room
			pItem.seats = [];
			
			// Add the item to the engine
			this.byIndex.push(pItem);
			this.byId[pItem[this.collectionId + '_id']] = pItem;
			this.byRoomId[pItem.room_id] = pItem;
			
			// Store the room this game belongs to
			pItem.$local.$room = this.engine.bjRooms.byId[pItem.room_id];
			
			// Emit an afterCreate event
			this.emit('afterCreate', pItem);
			
			// Check for a callback method and all it if exists
			if (typeof(pItem.$local.create_callback) == 'function') {
				pItem.$local.create_callback(pItem);
				pItem.$local.create_callback = null;
			}
			
			return pItem;
		} else {
			// Call the callback with no argument meaning there was a cancellation or error
			if (typeof(pItem.$local.update_callback) == 'function') {
				pItem.$local.create_callback();
				pItem.$local.create_callback = null;
			}
		}
	},
	
	/** _update - Updates the class collection item with the matching id
	specified in the updData parameter with all properties of the pData
	parameter. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or the updated item on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The object to receive updated property values.",
		}, {
			type:"object",
			name:"pData",
			desc:"The property values to apply to the pItem object.",
		}],
	} **/
	_update: function (pItem, pData) {
		// Grab the current item object
		var pItem = this.read(pItem);

		if (pItem) {
			// Emit the beforeUpdate event and halt if any listener returns the cancel flag
			if (!this.emit('beforeUpdate', pItem)) {
				// Update the current object with the new object's properties
				for (var i in pData) {
					pItem[i] = pData[i];
				}
				
				this.emit('afterUpdate', pItem);
				
				if (typeof(pItem.$local.update_callback) == 'function') {
					pItem.$local.update_callback(pItem);
					pItem.$local.update_callback = null;
				}
				
				return pItem;
			} else {
				// Call the callback with no argument meaning there was a cancellation or error
				if (typeof(pItem.$local.update_callback) == 'function') {
					pItem.$local.update_callback();
					pItem.$local.update_callback = null;
				}
			}
		} else {
			return false;
		}
		
	},
	
	/** _remove - Private method that removes the item identified by the passed
	id from the engine and removes any reference to it in the class lookup arrays. {
		category:"method",
		engine_ver:"0.1.2",
		return: {
			type:"bool",
			desc:"Returns false on failure or true on success.",
		},
		arguments: [{
			type:"object",
			name:"pItem",
			desc:"The item object to be removed.",
		}],
	} **/
	_remove: function (pItem) {
		var pItem = this.read(pItem);
		
		if (pItem) {
			if (!this.emit('beforeRemove', pItem)) {
				// Check if the pItem has a callback method and if so, save a
				// reference to it, then fire it after removal of the pItem
				var cbMethod = null;
				if (typeof pItem.$local.remove_callback == 'function') {
					cbMethod = pItem.$local.remove_callback;
				}
				
				// Remove it from all the arrays
				var arr1 = this.byIndex;
				
				// Remove the item from all the lookup arrays
				delete this.byId[pItem[this.collectionId + '_id']];
				delete this.byRoomId[pItem.room_id];
				var arr1Index = arr1.indexOf(pItem);
				arr1.splice(arr1Index, 1);
				
				// Check if there was a callback and fire it if exists
				if (typeof(cbMethod) == 'function') {
					cbMethod.apply(this);
				}
				
				this.emit('afterRemove', pItem)
				
				return true;
			} else {
				// The remove was cancelled by an event listener
				return false;
			}
		} else {
			return false;
		}
	},
	
	state: function (game, state) {
		if (typeof(state) != 'undefined') {
			game.$local.$gameState = state;
			if (this.ige.isServer)  {
				// Send a message to all users in the game room that the game state has changed
				this.ige.bjRoomsServer.sendToRoom(game.$local.$room, 'changedGameState', [game.$local.$room.room_id, state]);
			}
		}
		return game.$local.$gameState;
	},
	
	suitToName: function (suitId) {
		return this.suitNames[suitId];
	},
	
	numToName: function (cardId) {
		return this.cardNames[cardId];
	},
});