BjGamesServer = new IgeClass({
	Extends: IgeEvents,
	
	init: function (engine) {
		this._className = 'BjGamesServer';
		this.ige = engine;
		this.engine = engine;
		
		// Register ourselves as an engine property
		this.ige.bjGamesServer = this;
		
		// Set the flow of the game
		this.gameFlow = new IgeEnum([
			'stopped', // The game is waiting for players
			'starting', // The game has players and is going to start after a short pause
			'betting', // The game asking each player for their bet
			'dealing', // The game is dealing the initial round
			'action', // The game is asking each player to choose their action
			'dealer', // The game is processing player choices
			'resolving', // The game is resolving the result of the round
			'resetting' // The game is resetting for a new round
		]);
		
		// Betting round states
		this.bettingRoundStates = new IgeEnum([
			'stopped',
			'started',
			'completed'
		]);
		
		// Action round states
		this.actionRoundStates = new IgeEnum([
			'stopped',
			'started',
			'completed'
		]);
		
		// Set default action timeout speed
		this.options.timeOut = 50; // Set to 20 seconds
		
		this.log('Init complete');
	},
	
	ready: function () {
		
	},
	
	// Produce a new card from the deck
	getCard: function (pItem) {
		// Shuffle the deck with 10 iterations
		this.shuffleDeck(pItem, 10);
		
		// Take the top card
		var card = pItem.$local.$cardsInDeck.pop();
		
		// Add the card to the cards on the table array
		pItem.$local.$cardsOnTable.push(card);
		
		// Return the new card
		return card;
	},
	
	// Reset the deck so all cards are taken from the table and placed in the deck
	resetDeck: function (pItem) {
		pItem.$local.$cardsInDeck = [];
		pItem.$local.$cardsOnTable = [];
		
		// The card indexes will start at 1 (ace)
		// and go to 13 (king)
		for (var i = 1; i <= 13; i++) {
			// Loop the suits, 0 = diamonds, 1 = clubs, 2 = hearts, 3 = spades
			for (var suit = 0; suit < 4; suit++) {
				var card = {
					suit: suit,
					num: i
				}
				
				pItem.$local.$cardsInDeck.push(card);
			}
		}
	},
	
	// Shuffle the current deck of cards
	shuffleDeck: function (pItem, iterations) {
		//this.log('Shuffling deck...');
		var shuffled = null;
		
		for (var i = 1; i <= iterations; i++ ) {
			shuffled = [];
			
			// Shuffle and store in the shuffle array
			while (pItem.$local.$cardsInDeck.length) {
				var card = pItem.$local.$cardsInDeck.splice(Math.random() * pItem.$local.$cardsInDeck.length, 1)[0];
				shuffled.push(card);
			}
			
			// Move the shuffled cards back into the deck
			while (shuffled.length) {
				pItem.$local.$cardsInDeck.push(shuffled.pop());
			}
		}
		//this.log('Deck shuffled ' + iterations + ' time(s)');
		return;
	},
	
	// A user just sat down at the table, check if the game should start because of it
	shouldGameStart: function (game) {
		// Check if the game is in the stopped state
		if (this.ige.bjGames.state(game) == this.ige.bjGames.states.stopped) {
			// Set gamestate to starting
			this.ige.bjGames.state(game, this.ige.bjGames.states.starting);
			
			// We're currently waiting for players so start the game!
			setTimeout(this.bind(function () { this.startGame(game); }), 3000);
		}
	},
	
	// A user just stood up, check if the game should end because of it
	shouldGameStop: function (game) {
		if (this.ige.bjGames.state(game) > this.ige.bjGames.states.stopped) {
			// Check if all the seats are now all empty
			var room = game.$local.$room;
			for (var i = 0; i < 5; i++) {
				if (room.seats[i]) {
					// A seat is still occupied so don't end the game
					return;
				}
			}
			
			// The seats are all empty, reset the game
			this.stopGame(game);
			this.log('Ended game because no players are present');
		}
	},
	
	// Start the game
	startGame: function (game) {
		if (this.ige.bjGames.state(game) == this.ige.bjGames.states.starting) {
			// Set gamestate to started
			this.ige.bjGames.state(game, this.ige.bjGames.states.started);
			
			// Set the betting round state to stopped (it's initial state)
			game.$local.$bettingRoundState = this.bettingRoundStates.stopped;
			game.$local.$actionRoundState = this.actionRoundStates.stopped;
			
			// Set the current bets to blank
			game.$local.$bet = [];
			
			// Ask players for their bets
			this.startBettingRound(game);
		} else {
			this.log('Cannot start game because game state is not set to starting!', 'error', game);
		}
	},
	
	// Resets the game to a completely new / stopped state
	stopGame: function (game) {
		this.ige.bjGames.state(game, this.ige.bjGames.states.resetting);
		this.resetDeck(game);
		game.$local.$cardsBySeat = [];
		game.$local.$dealerCards = [];
		this.ige.bjGames.state(game, this.ige.bjGames.states.stopped);
		
		// Remove all the card entities
		/*var removeEntityArray = [];
		var roomEntities = this.ige.entities.byMapId['map_' + game.$local.$room.room_id];
		
		for (var entIndex = 0; entIndex < roomEntities.length; entIndex++) {
			var entity = roomEntities[entIndex];
			if (entity.template_id == 'cardEntity') {
				// Remove the card
				removeEntityArray.push(entity);
			}
		}
		
		this.ige.entities.remove(removeEntityArray);*/
		
		// Get the room
		var room = game.$local.$room;
	},
	
	startBettingRound: function (game) {
		this.log('Starting betting round...');
		var room = game.$local.$room;
		var seats = room.seats;
		
		switch (game.$local.$bettingRoundState) {
			case this.bettingRoundStates.stopped:
				this.log('Asking first player to bet...');
				// Find the first seat and inform room that it's that
				// players turn to bet (we tell everyone because then
				// the clients can display an indicator showing which
				// player is being waited on)
				var playerSeatId = this.ige.bjRoomsServer.getNextPlayerSeatId(room);
				if (playerSeatId > -1) {
					// Set the current state of the betting round to started
					game.$local.$bettingRoundState = this.bettingRoundStates.started;
					
					// Set the last player we asked for a bet from
					game.$local.$bettingRoundLastSeatId = playerSeatId;
					
					// Ask the player to bet including room id and the
					// session id of the player who should do their bet
					this.askClientTo_bet(game, playerSeatId);
				} else {
					this.log('Error, game asked to start betting round but no players in game!');
					this.stopGame(game);
				}
			break;
			
			case this.bettingRoundStates.started:
				var playerSeatId = this.ige.bjRoomsServer.getNextPlayerSeatId(room, game.$local.$bettingRoundLastSeatId);
				if (playerSeatId > -1) {
					this.log('Asking next player to bet...');
					// Set the current state of the betting round to started
					game.$local.$bettingRoundState = this.bettingRoundStates.started;
					
					// Set the last player we asked for a bet from
					game.$local.$bettingRoundLastSeatId = playerSeatId;
					
					// Ask the player to bet including room id and the
					// session id of the player who should do their bet
					this.askClientTo_bet(game, playerSeatId);
				} else {
					this.log('Betting round complete');
					// Set the betting round state to completed
					game.$local.$bettingRoundState = this.bettingRoundStates.completed;
					
					// There are no more players waiting to bet so
					// start the dealing round
					this.startDealingRound(game);
				}
			break;
		};
	},
	
	askClientTo_bet: function (game, seatId) {
		// Get the room we belong in
		var room = game.$local.$room;
		var seats = room.seats;
		
		// Tell the client apps that the betting round has started!
		this.engine.bjRoomsServer.sendToRoom(room, 'shouldDecideBet', [room.room_id, seatId, seats[seatId]]);
	},
	
	clientRequestedTo_bet: function (data, sessionId) {
		this.log('Received client bet');
		var roomId = data[0];
		var seatId = data[1];
		var bet = data[2];
		
		var room = this.ige.bjRooms.read(roomId);
		if (room) {
			// Get the game from the room
			var game = room.$local.$game;
			
			// Check that the player is occupying the room and seat... if not
			// they are probably trying to cheat, we should boot them!
			if (room.seats[seatId] == sessionId) {
				// The player is authorised to make this bet so accept it
				game.$local.$bet[seatId] = bet;
				
				// Create the bet chips entities
				this.askClientTo_displayBet(game, seatId);
				
				// Now move on to the next player to bet
				this.startBettingRound(game);
			} else {
				// The player is not authorised to make this bet
				this.log('Player attempted to bet for another player!', 'warning', data);
			}
		} else {
			// The room doesn't exist, is this a hack attempt?
			this.log('Player tried to bet in room that does not exist!', 'warning', data);
		}
	},
	
	askClientTo_displayBet: function (game, seatId) {
		// Get the room we belong in
		var room = game.$local.$room;
		var seats = room.seats;
		
		// Tell the client apps that a bet was placed
		this.engine.bjRoomsServer.sendToRoom(room, 'bet', [room.room_id, seatId, game.$local.$bet[seatId]]);
	},
	
	// Deal the starting hands
	startDealingRound: function (game) {
		if (this.ige.bjGames.state(game) == this.ige.bjGames.states.started) {
			// Set gamestate to dealing
			this.ige.bjGames.state(game, this.ige.bjGames.states.dealing);
			
			// Reset the deck
			this.resetDeck(game);
			
			// Shuffle the deck with 10 iterations
			this.shuffleDeck(game, 10);
			
			// Get the room we belong in
			var room = game.$local.$room;
			
			// Set the current deal seat to 0
			game.$local.$currentDealSeat = 0;
			
			// Deal the first round of cards
			this.dealFirstRound(game);
		} else {
			this.log('Cannot deal a round because the game state is not started!', 'error', game);
		}
	},
	
	dealFirstRound: function (game) {
		var room = game.$local.$room;
		if (room.seats[game.$local.$currentDealSeat] || game.$local.$currentDealSeat == 5) {
			this.genSeatCard(game, game.$local.$currentDealSeat);
		}
		
		game.$local.$currentDealSeat++;
		
		if (game.$local.$currentDealSeat <= 5) {
			setTimeout(this.bind(function () { this.dealFirstRound(game); }), 300);
		} else {
			// Now deal the second round
			game.$local.$currentDealSeat = 0;
			setTimeout(this.bind(function () { this.dealSecondRound(game); }), 300);
		}
	},
	
	dealSecondRound: function (game) {
		var room = game.$local.$room;
		if (room.seats[game.$local.$currentDealSeat] || game.$local.$currentDealSeat == 5) {
			this.genSeatCard(game, game.$local.$currentDealSeat);
		}
		
		game.$local.$currentDealSeat++;
		
		if (game.$local.$currentDealSeat < 5) {
			setTimeout(this.bind(function () { this.dealSecondRound(game); }), 300);
		} else {
			// Create the face-down dealer hole card
			//this.createCardEntity(room.room_id, 5, 1, {suit:'FaceDown', num:0});
			setTimeout(this.bind(function () { this.endDealRound(game); }), 300);
		}
	},
	
	endDealRound: function (game) {
		var room = game.$local.$room;
		
		// Tell the clients that the deal is complete
		this.engine.bjRoomsServer.sendToRoom(room, 'areReceivingDealComplete', [room.room_id]);
		
		// Now start the action round
		this.ige.bjGames.state(game, this.ige.bjGames.states.action);
		this.startActionRound(game);
	},
	
	createCardEntity: function (roomId, seatId, cardIndex, card) {
		return;
		var room = this.engine.bjRooms.read(roomId);
		
		// Check if the seat is not the dealer at seatId 5
		if (seatId != 5) {
			// Create the card on the table
			var cardX = -15 + (-(seatId - 2) * 240) + (cardIndex * 30);
			var cardY = 170 - (Math.abs((seatId - 2) * (25 * Math.abs(seatId - 2))));
			
			var rotAdd = 0;
			if (cardIndex == 0) { rotAdd = -5; }
			if (cardIndex == 1) { rotAdd = 5; }
			var cardRotation = ((seatId - 2) * 13) + rotAdd;
			
			this.engine.entities.create({
				template_id: 'cardEntity',
				entity_transform: {
					translate: [cardX, cardY, 0, false, false], // position
					scale: [1.0, 1.0, 1.0], // scale
					rotate: [cardRotation, 0.0, 0.0], // rotation
					opacity: [1.0, 1.0, 1.0], // opacity
					origin: [0.5, 0.5], // origin point (anchor)
					debug:false, // draw bounds and debug info
				},
				asset_sheet_frame: (card.num) + (13 * card.suit),
				map_id:'map_' + roomId,
			}, this.bind(function (cardEnt) {
				if (cardEnt) {
					// Now that the new card has been created, let's send it
					// to any connected clients in this room
					this.engine.bjRoomsServer.sendToRoom(room, 'entitysCreate', cardEnt);
				}
			}));
		} else {
			// The seat is the dealers
			if (card.num > 0) {
				// Place a dealer card
				// Create the card on the table
				var cardX = -15 + (cardIndex * 30);
				var cardY = -170;
				
				var rotAdd = 0;
				if (cardIndex == 0) { rotAdd = -5; }
				if (cardIndex == 1) { rotAdd = 5; }
				var cardRotation = rotAdd;
				
				this.engine.entities.create({
					template_id: 'cardEntity',
					entity_transform: {
						translate: [cardX, cardY, 0, false, false], // position
						scale: [1.0, 1.0, 1.0], // scale
						rotate: [cardRotation, 0.0, 0.0], // rotation
						opacity: [1.0, 1.0, 1.0], // opacity
						origin: [0.5, 0.5], // origin point (anchor)
						debug:false, // draw bounds and debug info
					},
					asset_sheet_frame: (card.num) + (13 * card.suit),
					map_id:'map_' + roomId,
				}, this.bind(function (cardEnt) {
					if (cardEnt) {
						// Now that the new card has been created, let's send it
						// to any connected clients in this room
						this.engine.bjRoomsServer.sendToRoom(room, 'entitysCreate', cardEnt);
					}
				}));
			} else {
				// This is the face-down card, so just create a face-down entity
				var cardX = -15 + (cardIndex * 30);
				var cardY = -170;
				
				var rotAdd = 0;
				if (cardIndex == 0) { rotAdd = -5; }
				if (cardIndex == 1) { rotAdd = 5; }
				var cardRotation = rotAdd;
				
				this.engine.entities.create({
					template_id: 'cardBackEntity',
					entity_id: 'dealerHoldCardBack_' + roomId,
					entity_transform: {
						translate: [cardX, cardY, 0, false, false], // position
						scale: [1.0, 1.0, 1.0], // scale
						rotate: [cardRotation, 0.0, 0.0], // rotation
						opacity: [1.0, 1.0, 1.0], // opacity
						origin: [0.5, 0.5], // origin point (anchor)
						debug:false, // draw bounds and debug info
					},
					map_id:'map_' + roomId,
				}, this.bind(function (cardEnt) {
					if (cardEnt) {
						// Now that the new card has been created, let's send it
						// to any connected clients in this room
						this.engine.bjRoomsServer.sendToRoom(room, 'entitysCreate', cardEnt);
					}
				}));
			}
		}
		
		this.log('Server sent us a card!');
	},
	
	startActionRound: function (game) {
		this.log('Starting action round...');
		var room = game.$local.$room;
		var seats = room.seats;
		
		switch (game.$local.$actionRoundState) {
			case this.actionRoundStates.stopped:
				this.log('Asking first player to take action...');
				// Find the first seat and inform room that it's that
				// players turn to take action (we tell everyone because
				// then the clients can display an indicator showing
				// which player is being waited on)
				var playerSeatId = this.ige.bjRoomsServer.getNextPlayerSeatId(room);
				if (playerSeatId > -1) {
					// Set the current state of the betting round to started
					game.$local.$actionRoundState = this.actionRoundStates.started;
					
					// Set the last player we asked for a bet from
					game.$local.$actionRoundLastSeatId = playerSeatId;
					
					// Check value of cards is still a blackjack
					var currentVals = this.cardsValue(game.$local.$cardsBySeat[playerSeatId]);
					var count1 = currentVals[0];
					var count2 = currentVals[1];
					
					if (count1 == 21 || count2 == 21) {
						// The player has 21, skip to the next seat
						this.log('Seat has 21, skipping control to next seat...');
						setTimeout(this.bind(function () { this.startActionRound(game); }), 50);
					} else {
						// Ask the player to bet including room id and the
						// session id of the player who should do their bet
						this.askClientTo_takeAction(game, playerSeatId);
					}
				} else {
					this.log('Error, game asked to start action round but no players in game!');
					this.stopGame(game);
					break;
				}
			break;
			
			case this.actionRoundStates.started:
				var playerSeatId = this.ige.bjRoomsServer.getNextPlayerSeatId(room, game.$local.$actionRoundLastSeatId);
				if (playerSeatId > -1) {
					this.log('Asking next player to take action...');
					// Set the current state of the betting round to started
					game.$local.$actionRoundState = this.actionRoundStates.started;
					
					// Set the last player we asked for a bet from
					game.$local.$actionRoundLastSeatId = playerSeatId;
					
					// Check value of cards is still a blackjack
					var currentVals = this.cardsValue(game.$local.$cardsBySeat[playerSeatId]);
					var count1 = currentVals[0];
					var count2 = currentVals[1];
					
					if (count1 == 21 || count2 == 21) {
						// The player has 21, skip to the next seat
						this.log('Seat has 21, skipping control to next seat...');
						setTimeout(this.bind(function () { this.startActionRound(game); }), 50);
					} else {
						// Ask the player to bet including room id and the
						// session id of the player who should do their bet
						this.askClientTo_takeAction(game, playerSeatId);
					}
				} else {
					this.log('Action round complete');
					// Set the betting round state to completed
					game.$local.$actionRoundState = this.actionRoundStates.completed;
					
					// There are no more players waiting to do anything so
					// do the dealer round
					this.startDealerRound(game);
				}
			break;
		};
	},
	
	askClientTo_takeAction: function (game, seatId) {
		// Get the room we belong in
		var room = game.$local.$room;
		var seats = room.seats;
		
		// Tell the client apps that the action round has started!
		this.engine.bjRoomsServer.sendToRoom(room, 'shouldDecideAction', [room.room_id, seatId, seats[seatId]]);
	},
	
	clientRequestedTo_hit: function (data, sessionId) {
		var roomId = data[0];
		var seatId = data[1];
		
		var room = this.ige.bjRooms.read(roomId);
		if (room) {
			// Get the game from the room
			var game = room.$local.$game;

			if (this.ige.bjGames.state(game) == this.ige.bjGames.states.action && game.$local.$actionRoundState == this.actionRoundStates.started) {
				this.log('Received client hit');
				
				// Check that the player is occupying the room and seat... if not
				// they are probably trying to cheat, we should boot them!
				if (room.seats[seatId] == sessionId) {
					// Generate and send a new card
					this.genSeatCard(game, seatId);
					
					// Check value of cards is still <= 21
					var currentVals = this.cardsValue(game.$local.$cardsBySeat[seatId]);
					var count1 = currentVals[0];
					var count2 = currentVals[1];
					
					this.log('Seat cards value is ' + count1 + ', ' + count2);
					
					if (count1 == 21 || count2 == 21) {
						// The player has 21, skip to the next seat
						this.log('Seat has 21, skipping control to next seat...');
						this.startActionRound(game);
					}
					
					if (count1 > 21 && count2 > 21) {
						// The player has bust, skip to the next seat
						this.log('Seat is bust, skipping control to next seat...');
						this.startActionRound(game);
					}
				} else {
					// The player is not authorised to make this bet
					this.log('Player attempted to hit for another player!', 'warning', data);
				}
			} else {
				// A hit was received but the action round is not operating, was this a hack attempt?
			}
		} else {
			// The room doesn't exist, is this a hack attempt?
			this.log('Player tried to hit in room that does not exist!', 'warning', data);
		}
	},
	
	clientRequestedTo_stand: function (data, sessionId) {
		var roomId = data[0];
		var seatId = data[1];
		
		var room = this.ige.bjRooms.read(roomId);
		if (room) {
			// Get the game from the room
			var game = room.$local.$game;
		
			if (this.ige.bjGames.state(game) == this.ige.bjGames.states.action && game.$local.$actionRoundState == this.actionRoundStates.started) {
				this.log('Received client stand');
				// Check that the player is occupying the room and seat... if not
				// they are probably trying to cheat, we should boot them!
				if (room.seats[seatId] == sessionId) {
					// The player is authorised to make action
					
					// Set as standing
					
					// Now move on to the next player to take action
					this.startActionRound(game);
				} else {
					// The player is not authorised to make this bet
					this.log('Player attempted to stand for another player!', 'warning', data);
				}
			} else {
				// A stand was received but the action round is not operating, was this a hack attempt?
			}
		} else {
			// The room doesn't exist, is this a hack attempt?
			this.log('Player tried to stand in room that does not exist!', 'warning', data);
		}
	},
	
	genSeatCard: function (game, seatIndex) {
		// Generate the dealer card and send it to clients
		var room = game.$local.$room;
		var card = this.getCard(game);
		game.$local.$cardsBySeat[seatIndex] = game.$local.$cardsBySeat[seatIndex] || [];
		game.$local.$cardsBySeat[seatIndex].push(card);
		this.log('Dealt ' + this.ige.bjGames.numToName(card.num) + ' of ' + this.ige.bjGames.suitToName(card.suit) + ' to seat ' + seatIndex);
		
		// Send it to the room
		this.engine.bjRoomsServer.sendToRoom(room, 'areReceivingNewCard', [room.room_id, seatIndex, card]);
		
		// Create the card entity
		//this.createCardEntity(room.room_id, seatIndex, game.$local.$cardsBySeat[seatIndex].length - 1, card);
	},
	
	cardsValue: function (cards) {
		var count1 = 0;
		var count2 = 0;
		
		for (var i in cards) {
			var card = cards[i];
			count1 += parseInt(this.ige.bjGames.cardValues[card.num]);
			
			if (card.num == 1) {
				count2 += 11;
			} else {
				count2 += parseInt(this.ige.bjGames.cardValues[card.num]);
			}
		}
		
		return [count1, count2];
	},
	
	startDealerRound: function (game) {
		if (this.ige.bjGames.state(game) == this.ige.bjGames.states.action) {
			var room = game.$local.$room;
			// Set the game state to dealer
			this.log('Starting dealer round...');
			this.ige.bjGames.state(game, this.ige.bjGames.states.dealer);
			
			this.newDealerCard(game);
		}
	},
	
	newDealerCard: function (game) {
		var dealerCardValues = this.cardsValue(game.$local.$cardsBySeat[5]);
		if (dealerCardValues[0] < 17 && (dealerCardValues[1] < 17 || dealerCardValues[1] > 21)) {
			this.genSeatCard(game, 5);
			setTimeout(this.bind(function () { this.newDealerCard(game); }), 300);
		} else {
			this.log('Dealer reached limit');
			this.startResolvingRound(game);
		}
	},
	
	startResolvingRound: function (game) {
		if (this.ige.bjGames.state(game) == this.ige.bjGames.states.dealer || this.ige.bjGames.state(game) == this.ige.bjGames.states.resolving) {
			var cardsBySeat = game.$local.$cardsBySeat;
			var room = game.$local.$room;
			
			// Set the game state to resolving
			this.log('Starting resolving round...');
			
			if (this.ige.bjGames.state(game) == this.ige.bjGames.states.dealer) {
				// Tell the room that we're switching to the resolving state
				this.ige.bjGames.state(game, this.ige.bjGames.states.resolving);
				
				// Reset the resolving round seat id
				delete game.$local.$resolvingRoundSeatId;
			}
			
			// Get dealer hand result
			var dealerHandResult = this.handResult(this.cardsValue(cardsBySeat[5]));
			var dealerBlackJack = this.isBlackJack(cardsBySeat[5]);
			
			var seatId = this.ige.bjRoomsServer.getNextPlayerSeatId(room, game.$local.$resolvingRoundSeatId);
			if (seatId > -1) {
				this.log('Resolving seat ' + seatId);
				game.$local.$resolvingRoundSeatId = seatId;
				var handBet = game.$local.$bet[seatId];
				var cards = cardsBySeat[seatId];
				var cardsValue = this.cardsValue(cards);
				
				var handResult = this.handResult(this.cardsValue(cardsBySeat[seatId]));
				var handBlackJack = false;
				var handWinnings = 0;
				var playerHandState = 0; // 0 = lost, 1 = won, 2 = push
				
				// Check if the hand went bust
				if (handResult[0]) {
					// The hand went bust
					this.log('Seat ' + seatId + ' went bust');
					playerHandState = 0;
				} else {
					// The hand did not go bust, is the dealer bust?
					handBlackJack = this.isBlackJack(cardsBySeat[seatId]);
					
					if (dealerHandResult[0]) {
						// The dealer is bust so this player hand won
						this.log('Dealer is bust, player hand wins');
						playerHandState = 1;
					} else {
						// The dealer is not bust, check who has the better hand
						if (handResult[1] > dealerHandResult[1]) {
							// The player hand is better than the dealer, the player hand wins
							this.log('Player hand is ' + handResult[1] + ' which wins against dealer ' + dealerHandResult[1]);
							playerHandState = 1;
						}
						
						if (handResult[1] < dealerHandResult[1]) {
							// The player hand is worse than the dealer, the player hand looses
							this.log('Player hand is ' + handResult[1] + ' which loses against dealer ' + dealerHandResult[1]);
							playerHandState = 0;
						}
						
						if (handResult[1] == dealerHandResult[1]) {
							// The player hand is the same value as the dealer, check if the hand is a blackjack
							this.log('Player hand is ' + handResult[1] + ' which equals dealer ' + dealerHandResult[1] + ', checking for BlackJack...');
							if (handBlackJack) {
								// The player hand is a BlackJack, check if the dealer is a BlackJack
								this.log('Player hand is a BlackJack, checking if dealer is a BlackJack...');
								if (dealerBlackJack) {
									// The dealer also has a BlackJack so the player hand is a push
									this.log('Player hand and dealer hand are both BlackJacks, hand is a push');
									playerHandState = 2;
								} else {
									// The dealer does not have a BlackJack so the player wins
									this.log('Player has BlackJack and dealer does not, player wins');
									playerHandState = 1;
								}
							} else {
								this.log('Player hand is not a BlackJack, checking if dealer has a BlackJack...');
								if (dealerBlackJack) {
									// Dealer has BlackJack and player does not, player loses
									this.log('Dealer has a BlackJack, player hand loses');
									playerHandState = 0;
								} else {
									// Neither player nor dealer have BlackJacks, hand is a push
									this.log('Player and dealer do not have BlackJacks, player hand is a push');
									playerHandState = 2;
								}
							}
						}
					}
				}
				
				// Now we know the player hand state, determine winnings etc
				if (playerHandState == 1) {
					// The player hand is a win so determine winnings
					if (handBlackJack) {
						// The player has a BlackJack so pay 3 for 2 (1.5 times original bet)
						handWinnings = handBet * 1.5;
					} else {
						// The player does not have a BlackJack so pay 1 for 1 (original bet)
						handWinnings = handBet;
					}
				}
				
				// Send final result to the clients
				var funds = 0;
				this.engine.bjRoomsServer.sendToRoom(room, 'areReceivingHandResolve', [room.room_id, seatId, playerHandState]);
				if (handWinnings) {
					// Update the client funds
					this.engine.bjRoomsServer.sendToRoom(room, 'areReceivingFundsChange', [room.room_id, seatId, funds]);
				}
				
				setTimeout(this.bind(function () { this.startResolvingRound(game); }), 300);
			} else {
				// Either no players exist or we've processed them all
				this.log('Resolving round complete, game over.');
			}
		}
	},
	
	handResult: function (cardsValue) {
		var bust = false;
		var hand = 0;
		
		if (cardsValue[0] > 21 && cardsValue[1] > 21) {
			// The hand went bust
			bust = true;
		} else {
			// The hand is not bust, work out the final hand value
			if (cardsValue[1] <= 21) {
				hand = cardsValue[1];
			} else {
				hand = cardsValue[0];
			}
		}
		
		return [bust, hand];
	},
	
	isBlackJack: function (cards) {
		if (cards) {
			if ((this.ige.bjGames.cardValues[cards[0].num] == 1 ||
				this.ige.bjGames.cardValues[cards[1].num] == 1) &&
				(this.ige.bjGames.cardValues[cards[0].num] == 10 ||
				this.ige.bjGames.cardValues[cards[1].num] == 10)) {
				// The player has a BlackJack!
				return true;
			} else {
				return false;
			}
		} else {
			// Cannot determine BlackJack
			this.log('Cannot determine blackjack because cards passed are undefined.', 'warning', cards);
		}
	},
	
});