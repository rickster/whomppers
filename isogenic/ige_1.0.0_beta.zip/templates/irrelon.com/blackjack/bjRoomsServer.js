BjRoomsServer = new IgeClass({
	ige: null, // Holds a reference to the engine instance
	
	init: function (engine) {
		this._className = 'BjRoomsServer';
		this.ige = engine;
		
		// Register ourself in the engine object
		this.ige.bjRoomsServer = this;
		
		this.log('Init complete');
	},
	
	ready: function () {
		
	},
	
	/** userIndex - Returns the index that the passed user object is occupying
	in the passed room's $local.$users array. {
		category:"method",
		return:{
			type:"integer",
			desc:"Returns the index that the user object is stored at inside the room.$local.$user array.",
		},
		arguments:[{
			name:"room",
			type:"object",
			desc:"The room to check against.",
		}, {
			name:"user",
			type:"object",
			desc:"The user to check for.",
		}],
	} **/
	userIndex: function (room, user) {
		return room.$local.$users.indexOf(user);
	},
	
	/** getNextPlayerSeatId - Gets the next player's seatId based on the room and
	current seat id passed. For instance, if the seatId passed is 1, the returned
	seatId will be the next seat occupied starting with seatId 2. If seatId is 
	ommitted then the method will check seatId zero first. {
		category:"method",
		return:{
			type:"integer",
			desc:"Returns the next occupied seat id or -1 if no other player exists.",
		},
		arguments:[{
			name:"room",
			type:"object",
			desc:"The room to check against.",
		}, {
			name:"seatId",
			type:"integer",
			desc:"The current seat have and we want to get the NEXT player from.",
		}],
	} **/
	getNextPlayerSeatId: function (room, seatId) {
		var fromSeatId = 0;
		if (typeof(seatId) != 'undefined') {
			fromSeatId = seatId + 1;
		}
		
		// Loop the seats and check for a player
		for (var i = fromSeatId; i < 5; i++) {
			if (room.seats[i]) {
				return i;
			}
		}
		
		return -1;
	},
	
	/** sendToRoom - Sends a network command and accompanying data to all users
	currently in a room. {
		category:"method",
		arguments:[{
			name:"room",
			type:"object",
			desc:"The room to send the network command to.",
		}, {
			name:"command",
			type:"string",
			desc:"The network command string.",
		}, {
			name:"data",
			type:"object",
			desc:"The data to send with the command.",
		}],
	} **/
	sendToRoom: function (room, command, data) {
		var clientArr = room.$local.$users;
		var clientCount = clientArr.length;
		
		while (clientCount--) {
			var client = clientArr[clientCount];
			this.ige.network.send(command, data, client.session_id);
		}
	},
	
	/** clientRequestedTo_joinRoom - Called when the server receives a request
	from a client to join a room. Checks if that is ok and sends a network
	response to the client. {
		category:"method",
		arguments:[{
			name:"data",
			type:"object",
			desc:"The data that the client sent us along with their request.",
		}, {
			name:"sessionId",
			type:"string",
			desc:"The session id of the client that sent the request.",
		}],
	} **/
	clientRequestedTo_joinRoom: function (data, sessionId) {
		// The client has requested to join a room, check for space and allow
		var room = this.ige.bjRooms.read(data.room_id);
		this.log('User has asked to join room: ' + data.room_id);
		
		if (room) {
			this.log('Room found');
			if (room.room_user_count < room.room_max_users) {
				this.log('Room is not full');
				// Grab the user from the server's _user object
				var user = this.ige.server._users.bySessionId[sessionId];
				
				// Add the user to the room
				room.$local.$users.push(user);
				room.room_user_count++;
				
				this.ige.bjRooms.update(room, {room_user_count:room.room_user_count});
				
				// Send the client all the relevant items
				/*this.ige.screens.netSendById(sessionId, 'playScreen_' + data.room_id);
				this.ige.maps.netSendById(sessionId, 'map_' + data.room_id);
				this.ige.cameras.netSendById(sessionId, 'camera_' + data.room_id);
				this.ige.viewports.netSendById(sessionId, 'viewport_' + data.room_id);
				
				// Send the entities
				var mapEnts = this.ige.entities.byMapId['map_' + data.room_id];
				for (var index = 0; index < mapEnts.length; index++) {
					this.ige.entities.netSendById(sessionId, mapEnts[index].entity_id);
				}*/
				
				// Tell the client they have joined the room
				this.log('Telling client to join room...');
				this.ige.network.send('joinRoom', room, sessionId);
				
				// Switch the client screen to the room
				//this.ige.screens.setCurrent('playScreen_' + data.room_id, sessionId);
				
				// Tell the client about any other players currently sitting in the room
				for (var i = 0; i < 5; i++) {
					if (room.seats[i]) {
						var user = this.ige.server._users.bySessionId[room.seats[i]];
						this.ige.network.send('sitDown', [this.ige.stripLocal(room), i, room.seats[i], user.username]);
					}
				}
			}
		}
	},
	
	/** clientRequestedTo_leaveRoom - Called when the server receives a request
	from a client to leave a room. Checks if that is ok and sends a network
	response to the client. {
		category:"method",
		arguments:[{
			name:"data",
			type:"object",
			desc:"The data that the client sent us along with their request.",
		}, {
			name:"sessionId",
			type:"string",
			desc:"The session id of the client that sent the request.",
		}],
	} **/
	clientRequestedTo_leaveRoom: function (data, sessionId) {
		// The client has requested to leave a room
		var room = null;
		
		if (data) {
			room = this.ige.bjRooms.read(data.room_id);
		}
		
		if (room) {
			var user = this.ige.server._users.bySessionId[sessionId];
			var userIndex = room.$local.$users.indexOf(user);
			if (userIndex > -1) {
				// Remove user from any seats they were occupying
				for (var i in room.seats) {
					// Check if this user is in the seat
					if (room.seats[i] == sessionId) {
						// Stand up from this seat
						this.clientRequestedTo_standUp([room.room_id, i], sessionId);
					}
				}
				
				// Remove the user from the room
				room.$local.$users.splice(userIndex, 1);
				room.room_user_count--;
				
				this.ige.bjRooms.update(room, {room_user_count:room.room_user_count});
				
				// Tell the user they have left the room
				this.ige.network.send('leaveRoom', room, sessionId);
			} else {
				// The user doesn't exist in this room!!
			}
		} else {
			// No room was passed so leave all rooms
			this.log('User leaving all rooms...');
			var roomArr = this.ige.bjRooms.byIndex;
			var roomCount = roomArr.length;
			
			while (roomCount--) {
				var room = roomArr[roomCount];
				this.clientRequestedTo_leaveRoom({room_id:room.room_id}, sessionId);
			}
		}
	},
	
	/** clientRequestedTo_sitDown - Called when the server receives a request
	from a client to sit down at a game in a room. Checks if that is ok and sends
	a network response to the client. {
		category:"method",
		arguments:[{
			name:"data",
			type:"object",
			desc:"The data that the client sent us along with their request.",
		}, {
			name:"sessionId",
			type:"string",
			desc:"The session id of the client that sent the request.",
		}],
	} **/
	clientRequestedTo_sitDown: function (data, sessionId) {
		// The client has requested to sit at a table, check for space and allow
		// Do some sanity checks
		
		// Do we have a seat id?
		if (typeof(data.seat_id) == 'undefined') { return; }
		// Do we have a room id?
		if (typeof(data.room_id) == 'undefined') { return; }
		// Is the seat id valid?
		if (data.seat_id > 4 || data.seat_id < 0) { return; }
		// Get the user and room objects
		var room = this.ige.bjRooms.read(data.room_id);
		var user = this.ige.server._users.bySessionId[sessionId];
		// Do we have a room and user?
		if (!room || !user) { return; }
		// Is the user actually in this room?
		if (this.userIndex(room, user) == -1) { return; }
		// Is the seat actually available?
		if (room.seats[data.seat_id]) { return; }

		// OK, we're good to go!
		this.log('User has asked to sit at seat ' + data.seat_id + ' in room: ' + data.room_id);
		// Add the user to the seat
		room.seats[data.seat_id] = sessionId;
		room.$local.$sitting[data.seat_id] = user;
		room.room_sitting_count++;
		
		// Update our room and propagate changes over the network
		this.ige.bjRooms.update(room, {seats:room.seats});
		
		// Tell the user they have sat down successfully
		this.log('Telling all clients watching table that the user has sat down...');
		this.sendToRoom(room, 'sitDown', [this.ige.stripLocal(room), data.seat_id, sessionId, user.username]);
		
		// Inform the game controller that a user has just sat down
		this.ige.bjGamesServer.shouldGameStart(room.$local.$game);
	},
	
	/** clientRequestedTo_standUp - Called when the server receives a request
	from a client to stand up from a game in a room. Checks if that is ok and sends
	a network response to the client. {
		category:"method",
		arguments:[{
			name:"data",
			type:"object",
			desc:"The data that the client sent us along with their request.",
		}, {
			name:"sessionId",
			type:"string",
			desc:"The session id of the client that sent the request.",
		}],
	} **/
	clientRequestedTo_standUp: function (data, sessionId) {
		var roomId = data[0];
		var seatId = data[1];
		var room = this.ige.bjRooms.read(roomId);
		var user = this.ige.server._users.bySessionId[sessionId];
		
		this.log('Player standing up from room ' + room.room_id + ' at seat id ' + seatId);
		
		// Send message to the room that the user has stood up
		this.sendToRoom(room, 'standUp', [this.ige.stripLocal(room), seatId, sessionId, user.username]);
		
		// Need to write rest of this
		delete room.seats[seatId];
		delete room.$local.$sitting[seatId];
		room.room_sitting_count--;
		
		// Update our room and propagate changes over the network
		this.ige.bjRooms.update(room, {seats:room.seats});
		
		// Check if the user standing up means the game should end
		this.ige.bjGamesServer.shouldGameStop(room.$local.$game);
	},
});