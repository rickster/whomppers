// Your client-specific code goes in this class
GameClient = new IgeClass({
	ige: null, // Holds a reference to the engine instance
	
	init: function (engine) {
		this._className = 'GameClient';
		this.ige = engine;
	},
	
	///////////////////////////////
	// START OF REQUIRED METHODS //
	///////////////////////////////
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		this.ige.network.on('networkProviderUp', this.bind(this._netStarted));
		this.ige.assets.on('allAssetsLoaded', this.bind(this._allAssetsLoaded));
		this.ige.network.on('auth', this.bind(this._auth));
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		this.ige.network.setStreamRenderLatency(160);
		this.ige.assets.setOption('delayProcess', true); // Only load asset images once all assets have been created
		this.ige.network.start();
	},
	///////////////////////////////
	// END OF REQUIRED METHODS   //
	///////////////////////////////
	
	_netStarted: function () {
		// Sync time between the server and the client
		// First, sync immediately with 3 samples to check the real sync score
		// then schedule sync requests every 10 seconds (10000 milliseconds)
		//this.ige.time.netSyncStart(0, 3);
		//this.ige.time.netSyncStart(1000, 0, true);
	},
	
	/** _allAssetsLoaded - The client has loaded all assets so tell the server. {
		category:"method",
	} **/
	_allAssetsLoaded: function () {
		// Send a message to the server that we have loaded all the assets
		this.log('All assets loaded, telling server...');
		this.ige.network.send('clientAllAssetsLoaded');
	},
	
	/** auth - Requests an authorisation from the server with the given
	username and password arguments. {
		category:"method",
		arguments:[{
			name:"username",
			type:"string",
			desc:"The username to auth with.",
		}, {
			name:"password",
			type:"string",
			desc:"The password to auth with",
		}]
	} **/
	auth: function (username) {
		window.ige.network.send('auth', {username:username});
		return false;
	},
	
	/** _auth - Called when the server sends us a response to our auth request. {
		category:"method",
		arguments:[{
			name:"data",
			type:"object",
			desc:"The response object from the server.",
		}]
	} **/
	_auth: function (data) {
		this.log('Auth command received');
		switch (data.status) {
			case 'success':
				$('#roomList').show();
				$('#joining').hide();
				this.log('Server auth successful!');
			break;
			case 'failed':
				this.log('Server auth failed!');
				alert('Please choose a different username!');
			break;
			case 'replaced':
				this.log('We have been signed out because we signed in at another computer / device!');
				this.ige.bjRooms.removeAll();
			break;
		}
	},
});