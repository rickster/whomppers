/* CEXCLUDE */
// Your server-specific code goes in this class
GameServer = new IgeClass({
	ige: null, // Holds the engine instance
	
	init: function (engine) {
		this._className = 'GameServer';
		this.ige = engine;
	},
	
	///////////////////////////////
	// START OF REQUIRED METHODS //
	///////////////////////////////
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		this.ige.network.on('clientConnect', this.bind(this._clientConnect));
	},
	
	// This is called when the engine wants you to load all your modules
	modules: function () {},
	
	// This is called when the engine wants you to hook module events
	moduleHooks: function () {},
	
	// This is called when the engine wants you to load all your data
	data: function () {
		this.ige.loadData({
			'templates':{},
			'screens':{},
			'animations':{},
			'assets':{},
			'users':{},
			'entities':{}
		});
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		this.setupWorld(this.bind(function () { // Call our setupWorld() method and pass a callback
			this.log('World setup complete... starting engine...');
			this.ige.network.allowConnections(true);
			this.ige.network.setStreamInterval(80);
			this.ige.network.startStream();
			this.ige.start();
			
			// Start some impulses to simulate physics on the server
			this.doImpulse();
		}));
	},
	///////////////////////////////
	// END OF REQUIRED METHODS   //
	///////////////////////////////
	
	/** setupWorld - Creates all the world items that the engine will use
	to render our scene. {
		category:"method",
		arguments: [{
			name:"callback",
			type:"function",
			desc:"The callback method to execute when the setupWorld() method has completed.",
		}],
	} **/
	setupWorld: function (callback) {
		this.ige.assets.on('allAssetsLoaded', this.bind(function () {
			// The assets have finished loading so create the world!
			this.setupTemplates();
			this.setupScreens();
			this.setupMaps();
			this.setupCameras();
			this.setupViewports();
			this.setupEntities();
			
			// Create a new box2d class instance - it automatically registers itself
			// with the engine
			new IgeBox2d(this.ige);
			
			// Set the world gravity vector
			this.ige.box2d.setGravity(0, 0);
			
			// Create the physics world
			this.ige.box2d.createWorld();
			this.ige.box2d.processExistingEntities();
			this.ige.box2d.start();
			
			// Now we've done everything, call the callback method
			callback();
		}));
	 
		// Create our assets
		this.ige.assets.create({
			asset_id: 'dirt1',
			asset_image_url: './assets/tiles/dirt1.png',
			asset_anchor_points: [[0, 0]],
			asset_render_mode: RENDER_MODE_2D,
		});
		
		this.ige.assets.create({
			asset_id: 'pucks',
			asset_image_url: './assets/sprites/pucks.png',
			asset_sheet_enabled: true,
			asset_sheet_width: 3, // There are three frames in the sprite sheet
			asset_sheet_height: 1,
			asset_anchor_points: [ [ 0, 0 ] ],
			asset_render_mode: RENDER_MODE_2D,
			asset_locale: LOCALE_EVERYWHERE,
			asset_persist: PERSIST_DISABLED
		});
	},
	
	/** setupTemplates - Creates the templates our game will use. {
		category:"method",
	} **/
	setupTemplates: function () {
		// Create our dirt wall template
		this.ige.templates.create({
			template_id: 'dirt1', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_TILE, // The entity is an object
				entity_layer: LAYER_TILES, // The map layer this entity will be rendered on
				entity_transform: {
					scaleTarget:[1, 1, 1, true],
				},
				map_block: MAP_BLOCK_CHECK, // The entity's blocking mode
				entity_locale: LOCALE_EVERYWHERE, // The locale the entity exists in
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				asset_id: 'dirt1', // The asset this entity will render from
				map_id: 'testMap1', // The map the entity exists on
				box2d: {
					trace: true,
					fixtureDef: [{
						density: 1.0,
						friction: 0.5,
						restitution: 0.2,
						shapeDef: {
							rect: {}
						}
					}],
					bodyDef: {
						static: {
							angle: 0.0,
							linearDamping: 0.0,
							angularDamping: 0.1,
							allowSleep: true,
							isSleeping: false,
							bullet: false,
						}
					}
				}
			},
		});
		
		// Create a bouncy ball template
		this.ige.templates.create({
			template_id: 'puck', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				entity_transform: {
					scaleTarget:[20, 20, 0, false],
				},
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_locale: LOCALE_EVERYWHERE, // The locale the entity exists in
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				entity_net_mode: NET_MODE_FREE_MOTION, // The entity will move freely around the world, optimise for it
				asset_id: 'pucks', // The asset this entity will render from
				asset_sheet_frame: 2, // We want to render from frame 1 of the sprite sheet
				map_id: 'testMap1', // The map the entity exists on
				box2d: {
					trace: true,
					fixtureDef: [{
						density: 1.0,
						friction: 0.1,
						restitution: 0.0,
						shapeDef: {
							circle: {
								radius: 10, // Set the radius to half the width
							}
						}
					}],
					bodyDef: {
						dynamic: { // This is a moving dynamic body
							angle: 0.0,
							linearDamping: 0.0,
							angularDamping: 0.0,
							allowSleep: true,
							isSleeping: false,
							bullet: false,
						}
					}
				}
			},
		});
		
		// Create a bouncy ball template
		this.ige.templates.create({
			template_id: 'ball', // Template ID - must be unique
			template_contents: { // The template's contents
				entity_type: ENTITY_TYPE_SPRITE, // The entity is an object
				entity_layer: LAYER_SPRITES, // The map layer this entity will be rendered on
				entity_transform: {
					scaleTarget:[20, 20, 0, false],
				},
				map_block: MAP_NOBLOCK_NOCHECK, // The entity's blocking mode
				entity_locale: LOCALE_EVERYWHERE, // The locale the entity exists in
				entity_persist: PERSIST_DISABLED, // The entity persist setting
				entity_net_mode: NET_MODE_FREE_MOTION, // The entity will move freely around the world, optimise for it
				asset_id: 'pucks', // The asset this entity will render from
				asset_sheet_frame: 1, // We want to render from frame 1 of the sprite sheet
				map_id: 'testMap1', // The map the entity exists on
				box2d: {
					trace: true,
					fixtureDef: [{
						density: 1.0,
						friction: 0.5,
						restitution: 0.2,
						shapeDef: {
							circle: {
								radius: 10, // Set the radius to half the width
							}
						}
					}],
					bodyDef: {
						dynamic: { // This is a moving dynamic body
							angle: 0.0,
							linearDamping: 0.0,
							angularDamping: 0.1,
							allowSleep: true,
							isSleeping: false,
							isBullet: false,
						}
					}
				}
			},
		});
	},
	 
	/** setupScreens - Creates the screens our game will use. {
		category:"method",
	} **/
	setupScreens: function () {
		// Create map screen
		this.ige.screens.create({
			screen_id:'mapView', // The screen's ID - this must be unique
			screen_background_color:'#000', // The background colour (HTML background-color property)
			screen_html: '', // The html file to load as the screens HTML content
			screen_parent_id: 'mainView', // The id of the DOM element to append the screen element to
			screen_persist:PERSIST_DISABLED, // The screen's persist setting
		});
	},
	 
	/** setupMaps - Creates the maps our game will use. {
		category:"method",
	} **/
	setupMaps: function () {
		this.ige.maps.create({
			map_id:'testMap1', // The map's ID - must be unique
			map_tilesize:40, // The size in pixels of the map tiles
			map_use_dirty2:false, // If dirty-rectangles should be used when rendering the map
			map_dirty_grid:false, // Show the dirty rectangle grid? (for debugging)
			map_debug_dirty:false, // Show the dirty rectangle debug data? (for debugging)
			map_debug_entities:false, // Show entity bounding boxes and depth values? (for debugging)
			map_dirty_width:40, // The width of each dirty rectangle
			map_dirty_height:40, // The height of each dirty rectangle
			map_render_mode: RENDER_MODE_2D, // What render mode this map uses, isometric or 2d?
			map_render:true, // If the map should be rendered or not, used for skipping this map in rendering
			map_layers:[ // The map's layer array
				{ // Layer 0
					layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
					layer_type:LAYER_TYPE_HTML, // Is this DOM or CANVAS based?
					layer_entity_types: LAYER_BACKGROUNDS // What type of entities layer contains
				},
				{ // Layer 1
					layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
					layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
					layer_entity_types: LAYER_TILES, // What type of entities layer contains
					layer_draw_grid: false, // If we should draw a debug tile grid (debugging)
				},
				{ // Layer 2
					layer_auto_mode:LAYER_AUTO_NONE, // Not currently used, always set to LAYER_AUTO_NONE
					layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
					layer_entity_types: LAYER_SPRITES // What type of entities layer contains
				},
				{ // Layer 3
					layer_auto_mode:LAYER_AUTO_NONE,// Not currently used, always set to LAYER_AUTO_NONE
					layer_type:LAYER_TYPE_AUTO, // Is this DOM or CANVAS based?
					layer_entity_types: LAYER_UI // What type of entities layer contains
				},
			],
			map_persist:PERSIST_DISABLED, // The map's persist setting
		});
	},
	 
	/** setupCameras - Creates the cameras our game will use. {
		category:"method",
	} **/
	setupCameras: function () {
		// Create camera
		this.ige.cameras.create({
			camera_id:'mainCam', // Camera ID - must be unique
			camera_x: 20, // The camera's x co-ordinate
			camera_y: 20, // The camera's y co-ordinate
			camera_z: 0, // The camera's z co-ordinate
			camera_scale: 1, // The camera's scale
			camera_zClipping:{ // The plane in which entities are drawn along the z-axis
				near: 0, // Draw entities from z:0
				far: 1, // Draw entities to z:1
			},
			camera_persist: PERSIST_DISABLED, // Camera's persist setting
		});
	},
	 
	/** setupViewports - Creates the viewports our game will use. {
		category:"method",
	} **/
	setupViewports: function () {
		// Create viewport
		this.ige.viewports.create({
			viewport_id: 'mainVp', // Viewport ID - must be unique
			viewport_tile_ratio: 1, // The ratio from map tilesize to tile height (0.5 = height = half the width)
			viewport_clipping: true, // Should we draw entities that are outside the viewing area?
			/*viewport_background_color:'#005aff',*/ // HTML element's background-color
			viewport_anchor_point: [0, 0], 
			viewport_autoSize: true, // Should this viewport auto-size to fill the parent element?
			viewport_container: { width: 800, height: 600 }, // The container element's initial dimensions
			viewport_locale: LOCALE_EVERYWHERE + LOCALE_DB, // The viewport's locale
			viewport_persist: PERSIST_DISABLED, // The viewport's persist setting
			panLayer:{ // The viewport's pan layer definition
				id: 'panLayer', // pan layer's ID
				padding: 0.0, // The amount of padding around the viewport to provide the element
				zStart: 0,
			},
			screen_id: 'mapView', // The screen this viewport belongs to
			map_id: 'testMap1', // The map this viewport reads it's entity data from
			camera_id: 'mainCam', // The camera this viewport uses to determine map draw position
		});
	},
	 
	/** setupEntities - Creates the entities our game will use. {
		category:"method",
	} **/
	setupEntities: function () {
		var maxX = 7;
		var maxY = 5;
		var maxXmo = maxX - 1;
		var maxYmo = maxY - 1;
		
		for (var x = -maxX; x <= maxX; x++) {
			for (var y = -maxY; y <= maxY; y++) {
				if (x == -maxX || y == -maxY || x == maxX || y == maxY) {
					this.ige.entities.create({
						template_id: 'dirt1',
						entity_transform:{
							translate:[x, y, 0, false, true]
						}
					});
				}
			}
		}
		
		// Create a bouncing ball entity
		for (var k = 0; k < 8; k++ ){
			this.ige.entities.create({
				template_id: 'puck',
				entity_transform:{
					translate:[
						Math.floor(Math.random() * (maxXmo * 2)) - maxXmo,
						Math.floor(Math.random() * (maxYmo * 2)) - maxYmo,
						0,
						false,
						true
					]
				}
			});
		}
		
		// Create some more balls
		for (var k = 0; k < 8; k++ ){
			this.ige.entities.create({
				template_id: 'ball',
				entity_transform:{
					translate:[
						Math.floor(Math.random() * (maxXmo * 2)) - maxXmo,
						Math.floor(Math.random() * (maxYmo * 2)) - maxYmo,
						0,
						false,
						true
					]
				}
			});
		}
	},
	
	_clientConnect: function (sessionId) {
		// Send all data
		this.ige.templates.netSendAll(sessionId);
		this.ige.assets.netSendAll(sessionId);
		this.ige.cameras.netSendAll(sessionId);
		this.ige.animations.netSendAll(sessionId);
		this.ige.screens.netSendAll(sessionId);
		this.ige.maps.netSendAll(sessionId);
		this.ige.viewports.netSendAll(sessionId);
		this.ige.backgrounds.netSendAll(sessionId);
		this.ige.entities.netSendAll(sessionId);
		this.ige.screens.setCurrent('mapView', sessionId);
		this.ige.startClient(sessionId);
	},
	
	doImpulse: function () {
		var entArray = this.ige.entities.byIndex;
		var count = entArray.length;
		
		while (count--) {
			var entity = entArray[count];
			
			if (entity.template_id == 'puck') {
				var _body = entity.$local.$box2d._body;
				var degrees = Math.random() * 360;
				var power = 5;
				
				// Apply some impulse
				_body.ApplyImpulse(
					new this.ige.box2d.box2d.b2Vec2(
						Math.cos(degrees * (Math.PI / 180)) * power,
						Math.sin(degrees * (Math.PI / 180)) * power
					),
					_body.GetWorldCenter()
				);
			}
		}
		
		setTimeout(this.bind(this.doImpulse), 100);
	},
});
/* CEXCLUDE */