// Your client-specific code goes in this class
GameClient = new IgeClass({
	ige: null, // Holds a reference to the engine instance
	
	init: function (engine) {
		this._className = 'GameClient';
		this.ige = engine;
	},
	
	///////////////////////////////
	// START OF REQUIRED METHODS //
	///////////////////////////////
	// This is called when the engine wants you to hook engine events
	engineHooks: function () {
		this.ige.network.on('networkProviderUp', this.bind(this._netStarted));
	},
	
	// This is called when the engine is ready to use
	ready: function () {
		this.log('Client ready, connecting to server...');
		this.ige.network.setStreamRenderLatency(160); // Set to 100 ms rendering latency
		this.ige.network.start();
	},
	///////////////////////////////
	// END OF REQUIRED METHODS   //
	///////////////////////////////
	
	_netStarted: function () {
		// Sync time between the server and the client
		// First, sync immediately with 3 samples to check the real sync score
		// then schedule sync requests every 10 seconds (10000 milliseconds)
		this.ige.time.netSyncStart(0, 3);
		this.ige.time.netSyncStart(1000, 0, true);
	},
});