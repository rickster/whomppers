routerTable = {};
routerTable['dev.isocity.co.uk'] = { host:'localhost', port:7001, errorRedirect:'http://www.isogenicengine.com/demo/isocity-maintenance/' };
routerTable['dev-io1.isocity.co.uk'] = { host:'localhost', port:9001 };